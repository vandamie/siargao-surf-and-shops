<?php
class User
{
  private $db;

  function __construct($DB_con)
  {
    $this->db = $DB_con;
  }

  public function signup($fname,$lname,$uname,$umail,$upass)
  {
   try
   {
     $new_password = password_hash($upass, PASSWORD_DEFAULT);

     $stmt = $this->db->prepare("INSERT INTO users(user_name,user_email,user_pass) 
       VALUES(:uname, :umail, :upass)");

     $stmt->bindparam(":uname", $uname);
     $stmt->bindparam(":umail", $umail);
     $stmt->bindparam(":upass", $new_password);            
     $stmt->execute(); 

     return $stmt; 
   }
   catch(PDOException $e)
   {
     echo $e->getMessage();
   }    
 }
 
 public function signin($username,$userpass)
 {

   try
   {
    $stmt = $this->db->prepare("SELECT jud_username, jud_password FROM judges_account 
      WHERE jud_username=:username OR jud_password=:userpass");
    $stmt->execute(array(':username'=>$username, ':userpass'=>$userpass));
    $userRow=$stmt->fetch(PDO::FETCH_ASSOC);

    $userpass = md5($userpass);

    if($stmt->rowCount() > 0)
    {
      if(password_verify($userpass, $userRow['jud_password']))
      {
        $_SESSION['user_session'] = $userRow['jud_acc_id'];
                //return true;
        echo "success";
      }
      else
      {
                //return false;
        echo "error";
      }
    }
  }
  catch(PDOException $e)
  {
   echo $e->getMessage();
 }
}



/*** starting the session ***/
public function get_session(){
  return $_SESSION['login'];
}
/*** end the session ***/
public function user_logout() {
  $_SESSION['login'] = FALSE;
  unset($_SESSION);
  session_destroy();
}
}
?>