<?php 
// Report all errors
error_reporting(E_ALL);
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
require_once ("admin-sisaph-login/include/db-con.php"); // connection to database.
$user = new User();
ob_start();
$uid = $_SESSION['id'];
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];

date_default_timezone_set('Asia/Manila');
$todays_date = date("M-D-Y, h:i:sa");

// fetch records
$result1 = @mysqli_query($conn, "SELECT * FROM news_article") or die("Error: " . mysqli_error($con));

// delete records
if(isset($_POST['chk_id']))
{
  $arr = $_POST['chk_id'];
  foreach ($arr as $id) {
    @mysqli_query($conn,"DELETE FROM news_article WHERE newsart_id = " . $id);
  }
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <title></title>
  </head>
  <body> 
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>   
    <script>
      swal({
        title: "Deleted Successfully!!!",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          location.reload();
        }
});
</script>

<?php
}


$query = "SELECT * FROM news_article";
$result2 =mysqli_query($conn,$query);
$nr = mysqli_num_rows($result2); // Get total of Num rows from the database query

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $sql1 = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$todays_date' WHERE id = '$user_status'";
  mysqli_query($conn,$sql1);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $sql2 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$todays_date' WHERE id = '$user_status'";
  mysqli_query($conn,$sql2);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 86400)) {  //3600 = 3600 * 24 = 86,400 minutes = 1 day, so it will sign out after 1 day 
  session_destroy();
  session_unset();
  $sql3 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$todays_date' WHERE id = '$user_status'";
  mysqli_query($conn,$sql3);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
} 


//////saving article data
$image="";
if (isset($_REQUEST['sub_add'])){  // $_POST['save'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$adding = $user->article_add($title,$category,$details,$image,$editor);
if ($adding) {
            // Adding success
 ?>
 <!doctype html>
 <html lang="en">
 <head>
  <title></title>
  <!-- Sweet Alert -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body> 
  <script>
    swal({
      title: "Success.",
      icon: "success",
      button: "Proceed",
    }).then(function(isConfirm) {
      if (isConfirm) {
        location.reload();
      }
    });
  </script>

  <?php
} else {
            // Adding failed

  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <title></title>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  </head>
  <body> 
    <script>
      swal({
        title: "Failed.",
        icon: "warning",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          location.reload();
        }
      });
    </script>

    <?php
  }
}
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association News Article">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
  <title>SISA PH News Article</title>
</head>
<body class="bod">
  <?php include("admin-sisaph-nav.php"); ?>
  
  <div class="content">
    <div class="btn-toolbar mb-2 mb-md-0">
      <h5>News Article</h5>&nbsp;&nbsp;&nbsp;
      <div class="btn-group mr-2">
        <button type="button" class="btn btn-sm btn-outline-secondary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">See All Article</button>
      </div>
      
      
      <div class="container">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label>Write Title:</label>
            <input type="text" name="title" placeholder="Write The News Title" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Select Category:</label>
            <select type="text" name="category" class="form-control" required>
              <option value="">--Select One-</option>
              <option value="Cloud 9 Master">Cloud 9 Master</option>
              <option value="Airborne">Airborne</option>
              <option value="Mens Open Shorboard">Mens Open Shorboard</option>
              <option value="Womens Open Shorboard">Womens Open Shorboard</option>
              <option value="Mens Open Longboard">Mens Open Longboard</option>
              <option value="Womens Open Shorboard">Womens Open Shorboard</option>
              <option value="Grommet">Grommet</option>
            </select>
          </div>

          <div class="form-group">
            <label>Write Details:</label>
            <textarea class="form-control" rows="10" name="details" required>Write something here...</textarea>
          </div>

          <div class="form-group">
            <label>Upload Image:</label>
            <input type="file" name="image" class="form-control" required>
          </div>
          
          <div class="form-group">
            <input type="hidden" name="editor" class="form-control" value="<?php echo $user->get_user_name($user_name); ?>" required>
          </div>

          <button type="submit" name="sub_add" class="btn btn-primary">Add</button>
        </form>
      </div>



      <!-- All Article -->
      <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">All News Article</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

              <p>Total Article: <?php echo $nr; ?></p>

              <form method="post" id="delete_form">
               <div class="table-responsive row justify-content"> 
                <table class="table table-bordered table-striped table-hover">
                  <thead>
                    <tr>
                      <th><input id="chk_all" name="chk_all" type="checkbox"  /></th>
                      <th>Title</th>
                      <th>Category</th>
                      <th>Details</th>
                      <th>Image</th>
                      <th>Editor</th>
                      <th>Date Published</th>
                      <th>Date Updated</th>
                      <th>Edit Button</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    if ($nr != 0) {
                      while($row = mysqli_fetch_assoc($result1)) { 
                        ?>
                        <tr>
                          <td><input name="chk_id[]" type="checkbox" class='chkbox' value="<?php echo $row['newsart_id']; ?>"/></td>
                          <td><?php echo $row['newsart_title']; ?></td>
                          <td><?php echo $row['newsart_category']; ?></td>
                          <td><?php echo substr($row['newsart_details'],0,50); ?></td>
                          <td><?php echo $row['newsart_image']; ?></td>
                          <td><?php echo $row['newsart_editor']; ?></td>
                          <td><?php echo $row['date_time_published']; ?></td>
                          <td><?php echo $row['date_time_updated']; ?></td>
                          <?php echo "<td><a class='btn btn-primary' href=\"edit_news_article.php?id=$row[newsart_id]\" onClick=\"return confirm('Are you sure, do you want to edit?')\">Edit</a></td>"; ?>
                        </tr>
                        <?php 
                      }
                    }else{
                      ?>
                      <tr>
                        <td colspan="9"><center>No Records at all.</center></td>
                      </tr>
                      <?php   
                    }
                    ?>
                  </tbody>
                </table>
              </div>
              <input id="submit" name="submit" type="submit" id="sub" class="btn btn-danger" value="Delete Selected Row(s)" />
            </form>

          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div> 


    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script>
    <!-- To avoid resubmession -->
    <script>
      if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
      }
    </script>

<!--/* NicEdit - Micro Inline WYSIWYG 
  * Copyright 2007-2008 Brian Kirchoff -->
  <script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
  <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>

  <!-- checked all boxes to delete rows-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('#chk_all').click(function(){
        if(this.checked)
          $(".chkbox").prop("checked", true);
        else
          $(".chkbox").prop("checked", false);
      });
    });

//Ask permession to confirm delete rows
$(document).ready(function(){
  $('#delete_form').submit(function(e){
    if(!confirm("Confirm Delete?")){
      e.preventDefault();
    }
  });
});
</script>						


</div>


<!-- FOOTER -->
<?php include("admin-sisaph-footer.php"); ?>

</body>
</html>
<?php 
mysqli_close($conn);
ob_end_flush();
?>