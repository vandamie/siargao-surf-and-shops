<?php 
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
require_once('admin-sisaph-login/include/functions.php');  // PHP functions file
$user = new User();
ob_start();
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];


date_default_timezone_set('Asia/Manila');
$todays_date = date("M-D-Y, h:i:sa");

$page_id = 2;
$month= date("M");
$day= date("D");
$year= date("Y");
$time= date("h:i:s a");
    $visitor_ip = $_SERVER['REMOTE_ADDR']; // stores IP address of visitor in variable
    add_view($con, $visitor_ip, $page_id,$month, $day, $year, $time);
	  $total_page_views = total_views($con, $page_id); // Returns total views of this page



if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $mysqli = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
  $sql = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($mysqli,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $mysqli = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($mysqli,$sql);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();
  $mysqli = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($mysqli,$sql);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
} 
ob_end_flush();
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops, Dashboard">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png"/>
  <!-- Website Title -->
  <title>SSAS PH Dashboard</title>
  <style>
    span.a {
      display: inline; /* the default for span */
      width: auto;
      height: auto;
      padding: 25px 25px 25px 25px;
      border: 1px solid blue;  
      background-color: #4682B4; 
      text-align: center;
    }

    span.d {
      display: inline-block; /* the default for span */
      width: auto;
      height: auto;
      padding: 30px 30px 30px 30px;
      border: 1px solid blue;  
      background-color: #4682B4; 
      font-size: 50px;
      text-align: center; 
    }

    span.b {
      display: block;
      padding: 15px 5px 15px 5px;
    }			

    span.c {
      display: block;
      width: 120px;
      height: 150px;
      padding: 0px 10px 0px 10px;
      border: 1px solid blue;    
      text-align: center; 
    }
  </style>
</head>
<body class="bod">
  <?php include("admin-sisaph-nav.php"); ?>

  <div class="content">
    <div class="btn-toolbar mb-2 mb-md-0">
      <h5>SSAS Dashboard</h5>&nbsp;&nbsp;&nbsp;
      <div class="btn-group mr-2">
        <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#">Sales</button>
      </div>

      <div class="btn-group mr-2">
        <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
        <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
      </div>
      <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
        <span data-feather="calendar"></span>
        This week
      </button>
    </div>


    <!-- Modal Settings-->
    <div class="modal fade" id="sett" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Admin Settings</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            ...
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary">Save changes</button>
          </div>
        </div>
      </div>
    </div>

    <div class="main" style="background-image: url('./assets/img/cloud-9-header.jpg');">
     <div class="content">     

       <h5>Total Website Views:</h5>
       <div class="c">
         <span class="d">
           <?php
	$total_website_views = total_views($con); // Returns total website views
	echo '<h3>'.$total_website_views.'</h3>';
	?>
</span>


<br>
<h5>Total Page Views:</h5>
<br>
<span class="a" id="d1">
  	    <?php // count specific page views
        $query_p1 = "SELECT total_views FROM pages WHERE id=1";
        $result_p1 = mysqli_query($con, $query_p1);

        $query_p2 = "SELECT total_views FROM pages WHERE id=2";
        $result_p2 = mysqli_query($con, $query_p2);

        if(mysqli_num_rows($result_p1) > 0)
        {
         while($row = mysqli_fetch_array($result_p1))
         {
          if($row['total_views'] === null)
          {
           return 0;
         }
         else
          {?>

            Frontend page: <p style="display:inline; font-size:18px;  padding: 25px 25px 25px 25px;"><?php echo $row['total_views']; ?></p>

          <?php } 
        }
      }
      else
      {
       return "No records found!";
     } 


     if(mysqli_num_rows($result_p2) > 0)
     {
       while($row = mysqli_fetch_array($result_p2))
       {
        if($row['total_views'] === null)
        {
         return 0;
       }
       else
        {?>

          Backend page: <p style="display:inline; font-size:18px;  padding: 25px 25px 25px 25px;"><?php echo $row['total_views']; ?></p>

        <?php } 
      }
    }
    else
    {
     return "No records found!";
   } ?>

 </span>

</div>
</div>

<br><br><br>


<script>
  /* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
  var dropdown = document.getElementsByClassName("dropdown-btn");
  var i;

  for (i = 0; i < dropdown.length; i++) {
    dropdown[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var dropdownContent = this.nextElementSibling;
      if (dropdownContent.style.display === "block") {
        dropdownContent.style.display = "none";
      } else {
        dropdownContent.style.display = "block";
      }
    });
  }
</script>
</div>

<?php include("footer.php"); ?>
</body>
</html>
