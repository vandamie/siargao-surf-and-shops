<?php
include "admin-login-register/include/db_config.php";
class Validation 
{
        protected $db;
	    public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
}
	public function check_empty($data, $fields)
	{
		$msg = null;
		foreach ($fields as $value) {
			if (empty($data[$value])) {
				$msg .= "$value field empty <br />";
			}
		} 
		return $msg;
	}
	
	public function is_user_password_valid($user_password)
	{
		$user_password = trim($_POST['user_password']);
	    //if (FILTER_SANITIZE_STRING("/^[_a-z0-9-+]+(\.[_a-z0-9-+]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $user_password)) {
		if (filter_var ($user_password, FILTER_SANITIZE_STRING) && strlen($user_password) > 8 ){	
				return true;  
			}
			return false;
		}


		public function is_user_email_valid($user_email)
		{
		//if (FILTER_VALIDATE_EMAIL("/^[_a-z0-9-+]+(\.[_a-z0-9-+]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $user_email)) {
			if (filter_var($user_email, FILTER_VALIDATE_EMAIL)) {	
				return true;  
			}
			return false;
		}

		/*** for registration process ***/

	public function add_user($user_name, $user_password, $user_email){
         $user_password = md5($user_password);
			//checking if the username AND email is available in db
		$query = "SELECT * FROM admin_personnel WHERE user_email='$user_email' OR user_name='$user_name' ";
        
		$result = $this->db->query($query) or die($this->db->error);

		$count_row = $result->num_rows;

			//if the username is not in db then insert to the table

		if($count_row == 0){
			return true;
		}else{

			return false;}
			
			
		}


       

}
	
	?>
