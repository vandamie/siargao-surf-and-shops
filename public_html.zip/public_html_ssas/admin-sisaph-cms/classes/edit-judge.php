<?php
error_reporting(E_ALL);
require_once("db_config.php");
class judge{
	protected $db;
	public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
	}

/*** for judge one editing process for judge name on the form ***/

 public function edit_judge($ju_name,$ju_password){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");  
$get_id = $_REQUEST['ju_id'];
$password = $ju_password = md5($_POST['ju_password']);
    

    
            $query = "UPDATE judges_account SET ju_name ='$ju_name', ju_password='$password'  WHERE ju_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

    return true;


}


	/*** starting the session ***/
	    public function get_session(){
	    	return $_SESSION['login'];
	    }


	    public function user_logout() {
	    	$_SESSION['login'] = FALSE;
	    	unset($_SESSION);
	    	session_destroy();
	    }


}

?>