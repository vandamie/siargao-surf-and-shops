<?php
include_once 'DbConfig.php'; // database connection

class Crud extends DbConfig // calling crud class and database class
{
	public function __construct()
	{
		parent::__construct();
	}
	    // function for confirmation if database was connected or not
	public function getData($query)
	{		
		$result = $this->connection->query($query);
		
		if ($result == false) {
			return false;
		} 
		
		$rows = array();
		
		while ($row = $result->fetch_assoc()) {
			$rows[] = $row;
		}
		
		return $rows;
	}
	     // function for execution database connection	
	public function execute($query) 
	{
		$result = $this->connection->query($query);
		
		if ($result == false) {
			echo 'Error: cannot execute the command';
			return false;
		} else {
			return true;
		}		
	}
	
	    // function for upcoming event data
	public function upcoming_ev($id, $table) 
	{ 
		$query = "UPDATE $table SET ev_status='Upcoming' WHERE event_id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot change id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	// function for postponed event data
	public function postponed_ev($id, $table) 
	{ 
		$query = "UPDATE $table SET ev_status='Postponed' WHERE event_id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot change id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	// function for complete event data
	public function complete_ev($id, $table) 
	{ 
		$query = "UPDATE $table SET ev_status='Completed' WHERE event_id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot change id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	    // function for delete data
	public function delete($id, $table) 
	{ 
		$query = "DELETE FROM $table WHERE id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot delete id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
           // function for approved_admin_personnel
		public function approved($active, $table) 
	{ 
		$query = "UPDATE $table SET user_active='Yes' WHERE id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot approved user ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	       // function for approved_judges
		public function approved_judges($active, $table) 
	{ 
		$query = "UPDATE $table SET ju_active='Yes' WHERE judge_id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot approved judge ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	// function for approved_customers
		public function approved_customers($active, $table) 
	{ 
		$query = "UPDATE $table SET cus_active='Yes' WHERE customer_id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot approved customer ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
           // function for disapproved_admin_personnel
	public function disapproved($active, $table) 
	{ 
		$query = "UPDATE $table SET user_active='No' WHERE id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot disapproved user ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	      // function for disapproved_judges
	public function disapproved_judges($active, $table) 
	{ 
		$query = "UPDATE $table SET ju_active='No' WHERE judge_id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot disapproved judge ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	
	
	     // function for disapproved_judges
	public function disapproved_customers($active, $table) 
	{ 
		$query = "UPDATE $table SET cus_active='No' WHERE customer_id = $active";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot disapproved judge ' . $active . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	 
         // function for primary
	public function primary($type, $table) 
	{ 
		$query = "UPDATE $table SET user_type='Primary' WHERE id = $type";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot make primary user ' . $type . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
           // function for secondary
	public function secondary($type, $table) 
	{ 
		$query = "UPDATE $table SET user_type='Secondary' WHERE id = $type";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot make secondary user ' . $type . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
      // function for user
	public function user($type, $table) 
	{ 
		$query = "UPDATE $table SET user_type='User' WHERE id = $type";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot make a user ' . $type . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}
	   // accepting all data format
	public function escape_string($value)
	{
		return $this->connection->real_escape_string($value);
	}
}
?>
