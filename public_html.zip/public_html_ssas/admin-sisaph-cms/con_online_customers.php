<?php

$conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$result = mysqli_query($conn,"select count(*) FROM customers WHERE cus_status='Online' AND customer_id = customer_id");
$off = mysqli_fetch_array($result);

?>