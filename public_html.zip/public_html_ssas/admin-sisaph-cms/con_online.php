<?php

$con = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$result = mysqli_query($con,"select count(*) FROM admin_personnel WHERE user_status='Online' AND id = id");
$on = mysqli_fetch_array($result);

?>