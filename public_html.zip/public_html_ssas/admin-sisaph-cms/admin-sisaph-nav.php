<style type="text/css">
  }
  @media screen and (min-width: 700px) {
    body.bod{
      font-size: 15px;
      margin: 0;
      font-family: Verdana;
    }
  }

  @media screen and (max-width: 700px) {
    body.bod{
      font-size: 14px;
      margin: 0;
      font-family: Verdana;
    }
  }

.navtop{
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
  padding: 0px 20px 0px 0px;
  font-size: 14px;
  z-index:2;
}


/********** sidebar down menu ********/

/* Fixed sidenav, full height */
.sidenav {
  height: 100%;
  width: auto;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding: 90px 2px 2px 2px;
}

/* Style the sidenav links and the dropdown button */
.sidenav a, .dropdown-btn {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 14px;
  color: #818181;
  display: block;
  border: none;
  background: none;
  width:auto;
  text-align: left;
  cursor: pointer;
  outline: none;
}

/* On mouse-over */
.sidenav a:hover, .dropdown-btn:hover {
  color: #f1f1f1;
}

/* Main content */
.main {
  margin-left: 185px; /* Same as the width of the sidenav */
  font-size: 14px; /* Increased text to enable scrolling */
  padding: 60px 10px;
  width: 100%;
  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

  /* Needed to position the navbar */
  position: relative;
}

.content{
  padding: 70px 5px 40px 220px;
  border-radius: 10px;
  width:auto;
  overflow: scroll;
}

/* Add an active class to the active dropdown button */
.active {
  background-color: #3e8e41;
  color: white;
}

/* Dropdown container (hidden by default). Optional: add a lighter background color and some left padding to change the design of the dropdown content */
.dropdown-container {
  display: none;
  background-color: #262626;
  padding-left: 8px;
}

/* Optional: Style the caret down icon */
.fa-caret-down {
  float: right;
  padding-right: 8px;
}

/* Some media queries for responsiveness */
@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 14px;}
}

/*************hover drop down****************/

/* Style The Dropdown Button */
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 10px;
  font-size: 14px;
  border: none;
  cursor: pointer;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
  float: right;
  padding: 5px 4px 4px 4px;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #8FBC8F}

/* Show the dropdown menu on hover */
.dropdown:hover .dropdown-content {
  display: block;
}

/* Change the background color of the dropdown button when the dropdown content is shown */
.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}

/********footer ******/

.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  background-color:#333;
  color: white;
  text-align: center;
  z-index: 2;
}

.column {
  float: left;
  width: 33.33%;
}
</style>
  <div class="navtop">
    <font style="float: left;color:white; padding: 4px 4px 4px 20px;"><img src="../sisaph-users/sisa-images/ssas-logo.png" width="45" height="45" style="border-radius: 32px;">&nbsp;SISA PH Admin</font>
    <div class="dropdown">
      <button class="dropbtn"><font style="color:blue;"><?php $user->get_user_status($user_status); ?></font>&nbsp;<i class="fa fa-fw fa-user"></i><?php $user->get_user_name($user_name); ?></button>
      <div class="dropdown-content">
        <a type="button" data-bs-toggle="modal" data-bs-target="#noti"><i class="fa fa-fw fa-bell"></i>Notification</a>
        <a type="button" data-bs-toggle="modal" data-bs-target="#sett"><i class="fa fa-fw fa-gear"></i>Settings</a>
        <a href="?q=logout" onclick="return confirm('Are you sure, do you want to logout?')"><i class="fa fa-sign-out"></i> Logout</a>
      </div>
    </div>
  </div>

    <div class="sidenav">
      <a href="index.php"><i class="fa fa-fw fa-eye"></i>Dashboard</a>
      <a href="admin-sisaph-personnel.php"><i class="fa fa-fw fa-users"></i>Admin Accounts</a>
      <a href="admin-sisaph-events.php"><i class="fa fa-fw fa-info"></i>SISA Events</a>
      <a href="admin-sisaph-rankings.php"><i class="fa fa-fw fa-info"></i>SISA Rankings</a>
      <a href="admin-judges-record.php"><i class="fa fa-fw fa-users"></i>Judges Account</a>
      <a href="admin-sisaph-customers.php"><i class="fa fa-fw fa-users"></i>Customers Account</a>
      <button class="dropdown-btn"><i class="fa fa-fw fa-folder"></i>SISA PH Contents 
        <i class="fa fa-caret-down"></i>
      </button>
      <div class="dropdown-container">
        <a href="admin-sisaph-news-article.php"><i class="fa fa-fw fa-home"></i>News Article</a>
      </div>
      <a href="#"><i class="fa fa-fw fa-envelope"></i>CS Messages</a>
    </div>