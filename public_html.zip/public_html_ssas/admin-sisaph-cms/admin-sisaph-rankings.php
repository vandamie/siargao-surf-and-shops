<?php 
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
$user = new User();
ob_start();
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");
$today = strtotime($todays_date);

$conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$query = "SELECT * FROM sisaph_rankings";
$result =mysqli_query($conn,$query);
$nr = mysqli_num_rows($result); // Get total of Num rows from the database query

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $sql = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
  header("admin-sisaph-login/location:index.php");
}else {
  $_SESSION['user_name'] = time();
} 
ob_end_flush();
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Events">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
  <title>SISA PH Rankings</title>
</head>
<body class="bod">
<?php include("admin-sisaph-nav.php"); ?>
  
<div class="content">
      <div class="btn-toolbar mb-2 mb-md-0">
          <h5>Events</h5>&nbsp;&nbsp;&nbsp;
          <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#add-ranking">Add New Ranking</button>
          </div>
        <div class="btn-group mr-2">
        <font class="btn btn-sm btn-outline-secondary">Total of Ranks: <?php echo $nr; ?></font>
      </div>
      
      <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
          <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
        </div>
        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
          <span data-feather="calendar"></span>
          This week
        </button>
      </div>

    <!-- Modal Adding Event -->
    <div class="modal fade" id="add-ranking" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add New Ranking</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form action="" method="POST">
              <div class="form-group">
               <span id="error_message" class="text-danger"></span>  
               <span id="success_message" class="text-success"></span>
               <input type="text" class="form-control" name="r_number" placeholder="Write the rank number"  required>
               <input type="text" class="form-control" name="r_name" placeholder="Write the name"  required>
               <input type="text" class="form-control" name="r_points" placeholder="Write the points"  required>
               <input type="text" class="form-control" name="r_earnings" placeholder="Write the earnings"  required>
               <input type="text" class="form-control" name="r_leag" placeholder="Write the league"  required>
               <select type="text" class="form-control" name="r_division"  required>
                <option value="">--Select Year--</option>
            <option value="Men's Shortboard">Men's Shortboard</option>
            <option value="Women's Shortboard">Women's Shortboard</option>
            <option value="Junior Shortboard">Junior Shortboard</option>
            <option value="Grommet Women Shortboard">Grommet Women Shortboard</option>
            <option value="Grommet Men Shortboar">Grommet Men Shortboard</option>
            <option value="Men's Longboard">Men's Longboard</option>
            <option value="Women's Longboard">Women's Longboard</option>   
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="add-submit" class="btn btn-success">Save changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  <div class="table-responsive row justify-content"> 
    <table class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
           <th>Rank Id</th>
           <th>Rank</th>
           <th>Name</th>
           <th>Points</th>
          <th>Earnings</th>
          <th>League</th>
          <th>Event Division</th>
          <th>Event Year</th>
          <th>Button Edit</th>
        </tr>
      </thead>
      <?php  
        if(mysqli_num_rows($result) != 0){ // if open bracket    
          while($res = mysqli_fetch_array($result)){
            $id=$res['rank_id'];
            ?>
            <tbody>
             <tr>
              <td><?php echo urlencode(base64_encode($res["rank_id"])); ?></td>
              <td><?php echo $res["r_number"]; ?></td>
              <td><?php echo $res["r_name"]; ?></td>
              <td><?php echo $res["r_points"]; ?></td>
              <td><?php echo $res["r_earnings"]; ?></td>
              <td><?php echo $res["r_name_leag"]; ?></td>
              <td><?php echo $res["r_division"]; ?></td>
              <td><?php echo $res["r_year"]; ?></td>
              <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#rank<?php echo $id; ?>">
                Edit
              </button></td>

              <!-- Modal Edit Event-->
              <div class="modal fade" id="rank<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Edit Rankings</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo '?rank_id='.$id; ?>" method="POST" name="">
                        <div class="form-group">
                          <input type="text" class="form-control" name="r_number" value="<?php echo $res["r_number"]; ?>" required>
                          <small  class="form-text text-muted">Write the rank number do you want.</small>
                          <input type="text" class="form-control" name="r_name" value="<?php echo $res["r_name"]; ?>" required>
                          <small  class="form-text text-muted">Write the name do you want.</small>
                          <input type="text" class="form-control" name="r_points" value="<?php echo $res["r_points"]; ?>" required>
                          <small  class="form-text text-muted">Write the points do you want.</small>
                          <input type="text" class="form-control" name="r_earnings"  value="<?php echo $res["r_earnings"]; ?>" required>
                          <small  class="form-text text-muted">Write the earnings do you want.</small>
                          <input type="text" class="form-control" name="r_leag" value="<?php echo $res["r_name_leag"]; ?>" required>
                          <small  class="form-text text-muted">Write the event leag do you want.</small>
                          <input type="text" class="form-control" name="r_division" value="<?php echo $res["r_division"]; ?>" required>
                          <small  class="form-text text-muted">Write the division do you want.</small>
                          <input type="text" class="form-control" name="r_year" value="<?php echo $res["r_year"]; ?>" required>
                          <small  class="form-text text-muted">Write the year do you want.</small>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" name="edit-rank" class="btn btn-success">Save changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div> 
              </tr>
              <?php
            }
          }else{
            ?>
            <tr>
             <td colspan="13"><center><p>No Records</p></center></td>
           </tr>
         <?php }// esle if statement close bracket ?>
       </tbody>
     </table>
   </div>
</div>
<!-- FOOTER -->
<?php include("admin-sisaph-footer.php"); ?>

<?php      
//---------------Submit event_edit-----------------------------------------------------------///

if (isset($_POST['edit-rank'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_rank = $user->edit_rank($r_number,$r_name,$r_points,$r_earnings,$r_leag, $r_division);
if ($edit_rank) {
            // Saving event success
 ?> 
 <!-------------SWAL FOR UPDATE------------------>
 <script>
  swal({
    title: "The ranking has change successfully!!!",
    icon: "success",
    button: "ok",
  });
window.location='cms-rankings.php'</script>

<?php  
} else {
  // Saving scores failed
  ?>

  <script>
    swal({
      title: "Not a valid data.",
      icon: "error",
      button: "ok",
    });
  </script>

  <?php 
}
}
?>

<?php    
if (isset($_POST['add-submit'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$add_rank = $user->add_rank($r_number,$r_name,$r_points,$r_earnings,$r_leag, $r_division);
if ($add_rank) {
            // Saving event success
 ?> 
 <!-------------SWAL FOR UPDATE------------------>
 <script>
  swal({
    title: "Adding new rank successfully!!!",
    icon: "success",
    button: "ok",
  });
window.location='cms-rankings.php'</script>

<?php  
} else {
  // Saving scores failed
  ?>

  <script>
    swal({
      title: "Not a valid data.",
      icon: "error",
      button: "ok",
    });
  </script>

  <?php 
}
}
?>

</body>
</html>