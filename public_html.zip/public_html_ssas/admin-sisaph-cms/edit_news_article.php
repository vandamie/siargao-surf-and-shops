<?php 
// Report all errors
error_reporting(E_ALL);
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
require_once ("admin-sisaph-login/include/db-con.php"); // class of functions of User.
$user = new User();
include_once("classes/Crud.php");
$crud = new Crud();

ob_start();
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];

date_default_timezone_set('Asia/Manila');
$todays_date = date("M.D,Y, h:i:s a");
$today = strtotime($todays_date);


//getting id from url
$id = $_GET['id'];
//selecting data associated with this particular id
$article = "SELECT * FROM news_article WHERE newsart_id = $id";
 $data = mysqli_query($conn,$article);
while($res = mysqli_fetch_array($data)) {
	$title = $res['newsart_title'];
	$details = $res['newsart_details'];
	$editor = $res['newsart_editor'];
}


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $sql1 = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql1);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $sql2 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql2);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();
  $sql3 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql3);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
} 


//Updating Records
$image="";
if (isset($_REQUEST['sub_edit'])){  // $_POST['save'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$updating = $user->article_edit($id,$title,$category,$details,$image,$editor);
if ($updating) {
            // Adding success
   ?>
 <!doctype html>
 <html lang="en">
 <head>
  <title></title>
  <!-- Sweet Alert -->
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body> 
  <script>
    swal({
      title: "Success.",
      icon: "success",
      button: "Proceed",
    }).then(function(isConfirm) {
      if (isConfirm) {
        window.location='admin-sisaph-news-article.php';
      }
    });
  </script>
</body>
</html>
  <?php
} else {
            // Adding failed

  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <title></title>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
  </head>
  <body> 
    <script>
      swal({
        title: "Failed.",
        icon: "warning",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='admin-sisaph-news-article.php';
        }
      });
    </script>
 </body>
 </html>
    <?php
  }
}
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association News Article">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
  <title>SISA PH Edit News Article</title>
</head>
<body class="bod">
  <?php include("admin-sisaph-nav.php"); ?>
  
  
  <div class="content">
    <div class="btn-toolbar mb-2 mb-md-0">
      <h5>Edit News Article</h5>
      
      <div class="container">
        <form  method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label>Write Title:</label>
            <input type="text" name="title" value="<?php echo $title; ?>" placeholder="Write The News Title" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Select Category:</label>
            <select type="text" name="category" class="form-control" required>
              <option value="">--Select One-</option>
              <option value="Cloud 9 Master">Cloud 9 Master</option>
              <option value="Airborne">Airborne</option>
              <option value="Mens Open Shorboard">Mens Open Shorboard</option>
              <option value="Womens Open Shorboard">Womens Open Shorboard</option>
              <option value="Mens Open Longboard">Mens Open Longboard</option>
              <option value="Womens Open Shorboard">Womens Open Shorboard</option>
              <option value="Grommet">Grommet</option>
            </select>
          </div>

          <div class="form-group">
            <label>Write Details:</label>
            <textarea class="form-control" rows="10" name="details" required><?php echo $details; ?></textarea>
          </div>

          <div class="form-group">
            <label>Upload Image:</label>
            <input type="file" name="image" class="form-control" required>
          </div>
          
          <div class="form-group">
            <input type="hidden" name="editor" value="<?php echo $editor; ?>" class="form-control" required>
            <td><input type="hidden" name="id" value="<?php echo $_GET['id'];?>"></td>
          </div>

          <button type="submit" name="sub_edit" class="btn btn-primary">Save Changes</button>
        </form>
      </div>


      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script>
      <script>
        if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
        }
      </script>

      <script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
      <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>



    </div>


    <!-- FOOTER -->
    <?php include("admin-sisaph-footer.php"); ?>

  </body>
  </html>
  <?php 
  mysqli_close($conn);
  ob_end_flush();
  ?>