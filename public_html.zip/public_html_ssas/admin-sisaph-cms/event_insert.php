 <?php  
 //insert.php  
 $connect = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");  
 if(isset($_POST["ev_name"]))  
 {    
 	if(is_string($_POST["ev_name"]) && is_string($_POST["ev_month"]) && is_string($_POST["ev_day"]) && is_numeric($_POST["ev_year"]) && is_string($_POST["ev_address"]) && is_string($_POST["ev_status"])){
      //date_default_timezone_set('Asia/Manila');
      $ev_name = mysqli_real_escape_string($connect, $_POST["ev_name"]);  
      $ev_month = mysqli_real_escape_string($connect, $_POST["ev_month"]);  
      $ev_day = mysqli_real_escape_string($connect, $_POST["ev_day"]);
      $ev_year = mysqli_real_escape_string($connect, $_POST["ev_year"]);  
      $ev_address = mysqli_real_escape_string($connect, $_POST["ev_address"]);
      $ev_class = mysqli_real_escape_string($connect, $_POST["ev_class"]);
      $ev_status = mysqli_real_escape_string($connect, $_POST["ev_status"]); 
      $ad_name = mysqli_real_escape_string($connect, $_POST["ad_name"]);  
	
$sql = "INSERT INTO sisa_events SET ev_name='$ev_name', ev_month='$ev_month', ev_day='$ev_day', ev_year='$ev_year', ev_address='$ev_address', ev_class='$ev_class', ev_status='$ev_status', ad_name='$ad_name' "; 

      mysqli_query($connect, $sql); 
        
           echo 'alert("Event was Saved.")';
      }else{

        
           echo 'alert("Event was not Saved.")'; 
      }  
 }  
 ?>  