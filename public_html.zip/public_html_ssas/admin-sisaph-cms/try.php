<?php 
// Report all errors
error_reporting(E_ALL);
//session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
require_once ("admin-sisaph-login/include/db-con.php"); // connection to database.
$user = new User();
ob_start();
//$user_name = $_SESSION['id'];
//$user_status = $_SESSION['id'];

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");
$today = strtotime($todays_date);


// delete records
if(isset($_POST['chk_id']))
{
  $arr = $_POST['chk_id'];
  foreach ($arr as $id) {
    @mysqli_query($conn,"DELETE FROM news_article WHERE newsart_id = " . $id);
  }
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <title></title>
  </head>
  <body> 
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>   
    <script>
      swal({
        title: "Deleted Successfully!!!",
        icon: "success",
        button: "ok",
         //buttons: [
        //'NO',
        //'YES'
        //],
      }).then(function(isConfirm) {
        if (isConfirm) {
          location.reload();
        } else {
    //if no clicked => do something else
  }
});
</script>

<?php
}


$query = "SELECT * FROM news_article";
$result2 =mysqli_query($conn,$query);
$nr = mysqli_num_rows($result2); // Get total of Num rows from the database query

/*
if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $sql1 = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql1);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $sql2 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql2);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();
  $sql3 = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql3);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
} 
*/

//////saving article data
if (isset($_POST['save'])){  // $_POST['save'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$upload_images = $user->article_image($title,$category,$details,$img,$author);
if ($upload_images) {
            // Saving Images Success
    //echo "<script>alert('Image has save successfully!!!'); window.location='/admin-sisaph-cms/try.php'</script>";
} else {
            // Saving Images score Failed
 //echo "<script>alert('Not a valid image.'); window.location='/admin-sisaph-cms/try.php'</script>";
}
}

ob_end_flush();
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association News Article">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
  <title>SISA PH News Article</title>
</head>
<body class="bod">
  <?php // include("admin-sisaph-nav.php"); ?>
  
  <div class="content">
    <div class="btn-toolbar mb-2 mb-md-0">
      <h5>News Article</h5>&nbsp;&nbsp;&nbsp;
      <div class="btn-group mr-2">
        <button type="button" class="btn btn-sm btn-outline-secondary"  data-bs-toggle="modal" data-bs-target="#staticBackdrop">See All Article</button>
      </div>
      
      
      <div class="container">
        <form method="POST" enctype="multipart/form-data">
          <div class="form-group">
            <label>Write Title:</label>
            <input type="text" name="title" placeholder="Write The News Title" class="form-control" required>
          </div>

          <div class="form-group">
            <label>Select Category:</label>
            <select type="text" name="category" class="form-control" required>
              <option value="">Select One-</option>
              <option value="Present Event">Present Event</option>
              <option value="Pasted Event">Pasted Event</option>
            </select>
          </div>

          <div class="form-group">
            <label>Write Details:</label>
            <textarea class="form-control" rows="10" name="details" required>Write something here...</textarea>
          </div>

          <div class="form-group">
            <label>Upload Image:</label>
            <input type="file" name="img" class="form-control" required>
          </div>
          
          <div class="form-group">
            <label>Write Author:</label>
            <input type="text" name="author" class="form-control" required>
          </div>
          <button type="submit" name="save" class="btn btn-primary">Save</button>
          <br><br>
          <div class="form-group">

           
          </div>
        </form>
      </div>



      <!-- All Article -->
      <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">All News Article</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Total Article: <?php echo $nr; ?></p>

              <form method="post" id="delete_form">
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th><input id="chk_all" name="chk_all" type="checkbox"  /></th>
                      <th>Title</th>
                      <th>Category</th>
                      <th>Details</th>
                      <th>Image</th>
                      <th>Author</th>
                      <th>Date</th>
                      <th>Edit Button</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php while($row = mysqli_fetch_assoc($result1)) { ?>
                      <tr>
                        <td><input name="chk_id[]" type="checkbox" class='chkbox' value="<?php echo $row['newsart_id']; ?>"/></td>
                        <td><?php echo $row['newsart_title']; ?></td>
                        <td><?php echo $row['newsart_category']; ?></td>
                        <td><?php echo $row['newsart_details']; ?></td>
                        <td><?php echo $row['newsart_image']; ?></td>
                        <td><?php echo $row['newsart_author']; ?></td>
                        <td><?php echo $row['newsart_date']; ?></td>
                        <?php echo "<td><a class='btn btn-primary' href=\"edit_news_article.php?id=$row[newsart_id]\" onClick=\"return confirm('Are you sure, do you want to edit?')\">Edit</a></td>"; ?>
                      </tr>
                    <?php } ?>
                  </tbody>
                </table>
                <input id="submit" name="submit" type="submit" id="sub" class="btn btn-danger" value="Delete Selected Row(s)" />
              </form>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div> 

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"></script>
      <script>
        if ( window.history.replaceState ) {
          window.history.replaceState( null, null, window.location.href );
        }
      </script>

      <script src="http://js.nicedit.com/nicEdit-latest.js" type="text/javascript"></script>
      <script type="text/javascript">bkLib.onDomLoaded(nicEditors.allTextAreas);</script>

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script type="text/javascript">
        $(document).ready(function(){
          $('#chk_all').click(function(){
            if(this.checked)
              $(".chkbox").prop("checked", true);
            else
              $(".chkbox").prop("checked", false);
          });
        });

        $(document).ready(function(){
          $('#delete_form').submit(function(e){
            if(!confirm("Confirm Delete?")){
              e.preventDefault();
            }
          });
        });
      </script>						


    </div>


    <!-- FOOTER -->
    <?php// include("admin-sisaph-footer.php"); ?>

  </body>
  </html>