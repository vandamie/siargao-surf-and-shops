<?php
//including the database connection file
include_once("classes/Crud.php");

$crud = new Crud();

//getting id of the data from url
$type = $crud->escape_string($_GET['id']);
$result = $crud->upcoming_ev($type, 'sisa_events');

if ($result) {
	//redirecting to the display page
	header("Location:cms_sisaph_events.php");
}
?>

