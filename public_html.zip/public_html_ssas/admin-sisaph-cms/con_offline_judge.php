<?php

//$conn = mysqli_connect("localhost","id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
$conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$result = mysqli_query($conn,"select count(*) FROM judges_account WHERE ju_status='Offline' AND judge_id = judge_id");
$off = mysqli_fetch_array($result);

?>