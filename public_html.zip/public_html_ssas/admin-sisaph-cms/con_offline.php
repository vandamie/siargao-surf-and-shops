<?php

$conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$result = mysqli_query($conn,"select count(*) FROM admin_personnel WHERE user_status='Offline' AND id = id");
$off = mysqli_fetch_array($result);

?>