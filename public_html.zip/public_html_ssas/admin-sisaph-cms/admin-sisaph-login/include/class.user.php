<?php 
include "db_config.php";
class User{
	protected $db;
	public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
	}

	/*** for registration process for admin***/
	public function reg_admin($ad_name,$ad_password,$ad_email){
			//echo "k";
		date_default_timezone_set('Asia/Manila');
		$todays_date = date("M-D-Y h:i:s a");
		$ad_name = filter_var($_REQUEST['ad_name'],FILTER_SANITIZE_STRING);
		$ad_password = md5($ad_password);

			//checking if the username or email is available in db
		$query = "SELECT * FROM admin_personnel WHERE user_name='$ad_name' OR user_email='$ad_email' LIMIT 1";

		$result = $this->db->query($query) or die($this->db->error);

		$count_row = $result->num_rows;

			//if the username is not in db then insert to the table

		if($count_row == 0){
			$query = "INSERT INTO admin_personnel SET 
			user_name='$ad_name', 
			user_password='$ad_password', 
			user_email='$ad_email', 
			time_in='null', 
			time_out='null', 
			date_registered='$todays_date', 
			user_active='No', 
			user_status='Offline', 
			user_type='Secondary' 
			";

			$result = $this->db->query($query) or die($this->db->error);

			return true;
		}else{

			return false;}

			
		}


		/*** for registration process for judges ***/
		public function reg_judge($j_uname,$j_upass){
			//echo "k";
			date_default_timezone_set('Asia/Manila');
			$todays_date = date("M-D-Y h:i:s a");
			$ju_name = filter_var($_REQUEST['j_uname'],FILTER_SANITIZE_STRING);
			$ju_pass = md5($ju_pass);

			//checking if the username or email is available in db
			$query = "SELECT * FROM judges_account WHERE ju_name='$j_uname' LIMIT 1";

			$result = $this->db->query($query) or die($this->db->error);

			$count_row = $result->num_rows;

			//if the username is not in db then insert to the table

			if($count_row == 0){
				$query = "INSERT INTO judges_account SET 
				ju_name ='$j_uname', 
				ju_password ='$j_upass', 
				ju_approval ='Yes', 
				time_in = 'null';
				time_out = 'null';
				ju_status ='Offline',
				date_registered='$todays_date' 
				";

				$result = $this->db->query($query) or die($this->db->error);

				return true;
			}else{

				return false;}


			}


			/*** for login process ***/
			public function check_login($user_name, $user_password){
				$user_name = filter_var($_REQUEST['user_name'],FILTER_SANITIZE_STRING);
				$user_password = md5($user_password);
			//$user_password = $user_password;

				$query = "SELECT id FROM admin_personnel WHERE user_name='$user_name' AND user_password='$user_password' AND user_active ='Yes' AND user_type ='Primary' OR user_name='$user_name' AND user_password='$user_password' AND user_active ='Yes' AND user_type ='Secondary' LIMIT 1"; 

				$result = $this->db->query($query) or die($this->db->error);


				$user_data = $result->fetch_array(MYSQLI_ASSOC);
				$count_row = $result->num_rows;

				if ($count_row == 1 ) {
	            $_SESSION['login'] = true; // this login var will use for the session thing
	            $_SESSION['id'] = $user_data['id'];
	            return true;
	        }else{

	        	return false;
	        }

	    }


	    /*** for displaying username  ***/
	    public function get_user_id($uid){
	    	$query = "SELECT id FROM admin_personnel WHERE id = $uid";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['id'];

	    }
	    /*** for displaying username  ***/
	    public function get_user_name($user_name){
	    	$query = "SELECT user_name FROM admin_personnel WHERE id = $user_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['user_name'];

	    }

	    /*** for displaying user profile image ***/
	    public function get_user_profile($user_profile){
	    	$query = "SELECT user_profile FROM admin_personnel WHERE id = $user_profile";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['user_profile'];

	    }
	    /*** for displaying user status ***/
	    public function get_user_status($user_status){
	    	$query = "SELECT user_status FROM admin_personnel WHERE id = $user_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['user_status'];

	    }
	    
	    
	    /*** for judge one editing process for judge name on the form ***/

	    public function edit_judge($ju_name,$ju_password,$ju_active,$ju_status){

	    	date_default_timezone_set('Asia/Manila');
	    	$todays_date = date("M. d, Y, h:i:s a");  
	    	$get_id = $_REQUEST['judge_id'];
	    	$password =md5($ju_password);


	    	$query = "UPDATE judges_account SET ju_name ='$ju_name', ju_password='$password' WHERE judge_id = '$get_id' ";
	    	$result = $this->db->query($query) or die($this->db->error); 

	    	return true;

	    }


	    /*** for adding event process ***/

	    public function add_event($ev_name,$ev_month,$ev_year,$ev_address,$ev_class,$ev_status,$ad_name){
	    	$ev_name = filter_var($_REQUEST["ev_name"],FILTER_SANITIZE_STRING); 
	    	$ev_month = filter_var($_REQUEST["ev_month"],FILTER_SANITIZE_STRING);  
	    	$ev_day = filter_var($_REQUEST["ev_day"],FILTER_SANITIZE_STRING);
	    	$ev_year = filter_var($_REQUEST["ev_year"],FILTER_SANITIZE_STRING);  
	    	$ev_address = filter_var($_REQUEST["ev_address"],FILTER_SANITIZE_STRING);
	    	$ev_class = filter_var($_REQUEST["ev_class"],FILTER_SANITIZE_STRING);
	    	$ev_status = filter_var($_REQUEST["ev_status"],FILTER_SANITIZE_STRING); 
	    	$ad_name = filter_var($_REQUEST["ad_name"],FILTER_SANITIZE_STRING);
	    	date_default_timezone_set('Asia/Manila');
	    	$todays_date = date("M. d, Y, h:i:s a"); 


	    	if(is_string($_REQUEST["ev_name"]) && is_string($_REQUEST["ev_month"]) && is_string($_REQUEST["ev_day"]) && is_numeric($_REQUEST["ev_year"]) && is_string($_REQUEST["ev_address"]) && is_string($_REQUEST["ev_status"])){

	    		$query = "INSERT INTO sisa_events SET 
	    		ev_name='$ev_name', 
	    		ev_month='$ev_month',
	    		ev_day='$ev_day', 
	    		ev_year='$ev_year', 
	    		ev_address='$ev_address', 
	    		ev_class='$ev_class', 
	    		ev_status='$ev_status', 
	    		ad_name='$ad_name',
	    		date_time_added='$todays_date',
	    		date_time_edited='none'
	    		"; 

	    		$result = $this->db->query($query) or die($this->db->error);

	    		return true;
	    	}else{

	    		return false;}


	    	}

	    	/*** for edit event process ***/

	    	public function edit_event($ev_name,$ev_month,$ev_year,$ev_address,$ev_class,$ev_status,$ad_name){
	    		$ev_name = filter_var($_REQUEST["ev_name"],FILTER_SANITIZE_STRING); 
	    		$ev_month = filter_var($_REQUEST["ev_month"],FILTER_SANITIZE_STRING);  
	    		$ev_day = filter_var($_REQUEST["ev_day"],FILTER_SANITIZE_STRING);
	    		$ev_year = filter_var($_REQUEST["ev_year"],FILTER_SANITIZE_STRING);  
	    		$ev_address = filter_var($_REQUEST["ev_address"],FILTER_SANITIZE_STRING);
	    		$ev_class = filter_var($_REQUEST["ev_class"],FILTER_SANITIZE_STRING);
	    		$ev_status = filter_var($_REQUEST["ev_status"],FILTER_SANITIZE_STRING); 
	    		$ad_name = filter_var($_REQUEST["ad_name"],FILTER_SANITIZE_STRING);
	    		$get_id = filter_var($_REQUEST['event_id'],FILTER_SANITIZE_STRING);
	    		date_default_timezone_set('Asia/Manila');
	    		$todays_date = date("M. d, Y, h:i:s a");    

	    		if(is_string($_REQUEST["ev_name"]) && is_string($_REQUEST["ev_month"]) && is_string($_REQUEST["ev_day"]) && is_numeric($_REQUEST["ev_year"]) && is_string($_REQUEST["ev_address"]) && is_string($_REQUEST["ev_status"])){

	    			$query = "UPDATE sisa_events SET 
	    			ev_name='$ev_name', 
	    			ev_month='$ev_month', 
	    			ev_day='$ev_day', 
	    			ev_year='$ev_year',
	    			ev_address='$ev_address', 
	    			ev_class='$ev_class', 
	    			ev_status='$ev_status', 
	    			ad_name='$ad_name',
	    			date_time_updated='$todays_date' 
	    			WHERE event_id = '$get_id'"; 

	    			$result = $this->db->query($query) or die($this->db->error);

	    			return true;
	    		}else{

	    			return false;
	    		}


	    	}


	    	/*** for adding ranking process ***/

	    	public function add_rank($r_number,$r_name,$r_points,$r_earnings,$r_leag, $r_division){
	    		$r_number =  filter_var($_REQUEST["r_number"],FILTER_SANITIZE_STRING);  
	    		$r_name = filter_var($_REQUEST["r_name"],FILTER_SANITIZE_STRING); 
	    		$r_points =  filter_var($_REQUEST["r_points"],FILTER_SANITIZE_STRING);
	    		$r_earningd = filter_var($_REQUEST["r_earnings"],FILTER_SANITIZE_STRING);
	    		$r_leag =  filter_var($_REQUEST["r_leag"],FILTER_SANITIZE_STRING);
	    		$r_division = filter_var(addslashes($_REQUEST["r_division"]),FILTER_SANITIZE_STRING);
	    		date_default_timezone_set('Asia/Manila');
	    		$r_year = date("Y"); 


	    		if( is_string($_REQUEST["r_name"])){

	    			$query = "INSERT INTO sisaph_rankings SET r_number='$r_number', r_name='$r_name', r_points='$r_points', r_earnings='$r_earnings',r_name_leag='$r_leag',r_division='$r_division', r_year='$r_year' "; 

	    			$result = $this->db->query($query) or die($this->db->error);

	    			return true;
	    		}else{

	    			return false;}


	    		}

	    		/*** for edit ranking process ***/

	    		public function edit_rank($r_number,$r_name,$r_points,$r_earnings,$r_leag, $r_division){
	    			$r_number =  filter_var($_REQUEST["r_number"],FILTER_SANITIZE_STRING); 
	    			$r_name = filter_var($_REQUEST["r_name"],FILTER_SANITIZE_STRING);  
	    			$r_points =  filter_var($_REQUEST["r_points"],FILTER_SANITIZE_STRING);
	    			$r_earningd = filter_var($_REQUEST["r_earnings"],FILTER_SANITIZE_STRING);
	    			$r_leag =  filter_var($_REQUEST["r_leag"],FILTER_SANITIZE_STRING);
	    			$r_division = filter_var(addslashes($_REQUEST["r_division"]),FILTER_SANITIZE_STRING);
	    			date_default_timezone_set('Asia/Manila');
	    			$r_year = date("Y"); 
	    			$get_id = filter_var($_REQUEST['rank_id'],FILTER_SANITIZE_STRING);  

	    			if(is_string($_REQUEST["r_name"])){

	    				$query = "UPDATE sisaph_rankings SET r_number='$r_number', r_name='$r_name', r_points='$r_points', r_earnings='$r_earnings', r_name_leag='$r_leag',r_division='$r_division',r_year='$r_year' WHERE rank_id = '$get_id' "; 

	    				$result = $this->db->query($query) or die($this->db->error);

	    				return true;
	    			}else{

	    				return false;}


	    			}


	    			/*** for uploading article process for adding ***/

	    			public function article_add($title,$category,$details,$image,$editor){
	    				date_default_timezone_set('Asia/Manila');  
	    				$title = htmlspecialchars($_REQUEST['title']); 
	    				$category = htmlspecialchars($_REQUEST['category']);
	    				$details = htmlspecialchars($_REQUEST['details']);
	    				$image = $_FILES['image'];
	    				$imgFile1 = $_FILES['image']['name'];
	    				$tmp_dir1 = $_FILES['image']['tmp_name'];
	    				$imgSize1 = $_FILES['image']['size'];
	    				$editor = htmlspecialchars($_REQUEST['editor']);
	    				$date = date('M.d,Y, h:m:s a');
	    	

// make a note of the directory that will recieve the uploaded file 
	    				//$upload_dir = '/storage/ssd1/742/14326742/public_html/admin-sisaph-cms/images/';
	    				$upload_dir = 'images/'; 

   $imgExt1 = strtolower(pathinfo($imgFile1,PATHINFO_EXTENSION)); // get image extension

   // valid image extensions
   $valid_extensions1 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

   // rename uploading image
   $img = rand(1000,1000000).".".$imgExt1;

   // allow valid image file formats
   if(in_array($imgExt1, $valid_extensions1)){
   // Check file size '5MB'
   	if($imgSize1 < 5000000){

   		move_uploaded_file($tmp_dir1,$upload_dir.$img);
   		$query = "INSERT INTO news_article SET newsart_title='$title', newsart_category='$category', newsart_details='$details', newsart_image='$img', newsart_editor='$editor',date_time_published='$date', date_time_updated ='none' ";
   		$result = $this->db->query($query) or die($this->db->error);
   		return true;

   	}else{
      //Sorry, your file is too large.        
   		return false;
   	}

   }else{
   //Sorry, only JPG, JPEG, PNG & GIF files are allowed.       
   	return false;  
   }

}


/*** for uploading article process for edit ***/
public function article_edit($id,$title,$category,$details,$image,$editor){
	date_default_timezone_set('Asia/Manila');  
	$title = htmlspecialchars($_REQUEST['title']); 
	$category = htmlspecialchars($_REQUEST['category']);
	$details = htmlspecialchars($_REQUEST['details']);
	$image = $_FILES['image'];
	$imgFile1 = $_FILES['image']['name'];
	$tmp_dir1 = $_FILES['image']['tmp_name'];
	$imgSize1 = $_FILES['image']['size'];
	$editor = htmlspecialchars($_REQUEST['editor']);
	$date = date('M.d,Y, h:m:s a');
	$id = $_REQUEST['id'];

// make a note of the directory that will recieve the uploaded file 
	    				//$upload_dir = '/storage/ssd1/742/14326742/public_html/admin-sisaph-cms/images/';
	$upload_dir = 'images/'; 

   $imgExt1 = strtolower(pathinfo($imgFile1,PATHINFO_EXTENSION)); // get image extension

   // valid image extensions
   $valid_extensions1 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions

   // rename uploading image
   $img = rand(1000,1000000).".".$imgExt1;

   // allow valid image file formats
   if(in_array($imgExt1, $valid_extensions1)){
   // Check file size '5MB'
   	if($imgSize1 < 5000000){

   		move_uploaded_file($tmp_dir1,$upload_dir.$img);
   		$query = "UPDATE news_article SET newsart_title='$title', newsart_category='$category', newsart_details='$details', newsart_image='$img', newsart_editor='$editor', date_time_updated ='$date' WHERE newsart_id=$id LIMIT 1";
   		$result = $this->db->query($query) or die($this->db->error);
   		return true;

   	}else{
      //Sorry, your file is too large.        
   		return false;
   	}

   }else{
   //Sorry, only JPG, JPEG, PNG & GIF files are allowed.       
   	return false;  
   }

}



/*** starting the session ***/
public function get_session(){
	return $_SESSION['login'];
}

public function user_logout() {
	$_SESSION['login'] = FALSE;
	unset($_SESSION);
	session_destroy();
}



}


?>