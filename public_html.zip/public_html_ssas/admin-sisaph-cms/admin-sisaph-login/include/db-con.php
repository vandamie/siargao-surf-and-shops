 <?php
  $conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms")or die("Error: " . mysqli_error($conn));
  ?>