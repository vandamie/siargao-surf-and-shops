<?php 
session_start();
error_reporting(E_ALL);
require_once ("include/class.user.php");//connection to database and public functions
$user = new User();//connection to public User function

if (isset($_REQUEST['submit'])) {  // posting data after submit button.
    // session start means you are setting the name of user to next page after click login.
  extract($_REQUEST); //extracting all data  from database.   
  $login = $user->check_login($user_name, $user_password); // calling function verification process.

  if ($login) {
	        // login Success
    ?>
<!doctype html>
<html lang="en">
<head>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<title></title>
</head>
<body> 
    <script>
      swal({
  title: "You have been login successfully.",
  icon: "success",
  button: "Proceed",
         }).then(function(isConfirm) {
    if (isConfirm) {
      window.location='../admin-sisaph-customers.php'
    } 
});
</script>
</body>
</html>
<?php
  } else {
          // Login Failed
    ?>
<!doctype html>
<html lang="en">
<head>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
<title></title>
</head>
<body>    
    <script>
      swal({
  title: "Wrong username or password or your account is need for the admin approval.",
  icon: "warning",
  button: "okay",
         }).then(function(isConfirm) {
    if (isConfirm) {
     location.reload();
    } 
});
</script>
</body>
</html>
<?php
  }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="description" content="Siargao Surf and Shops Administrator">
   <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
    <!-- SISA PH TAB ICON -->
    <link rel="icon"  type="image" href="/sisaph-users/sisa-images/ssas-logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="/sisaph-users/sisa-css/sisaph-login.css" rel="stylesheet">

    <title>SISA PH Admin Log In Page</title>
<style>
@media screen and (min-width: 601px) {
  body.bod {
    font-size: 15px;
  }
}

@media screen and (max-width: 600px) {
  body.bod {
    font-size: 14px;
  }
}

/* Create four equal columns */
.column {
  flex: 25%;
  padding: 5px 5px 5px 5px;
  max-width: 380px;
  margin: auto;
  background-color:#DCDCDC;
  border-radius:15px;
}
</style>
  </head>
  <body class="bod"><br><br>
  <div class="column">      
  <form method="POST" name="login" class="form-login">
 <center><img class="mb-2 rounded-circle" src="./images/ssas-logo.png" alt="logo" width="50" height="50"></center>
  <center><h4 class="h3 mb-3 font-weight-normal">SSAS Administrator</h4></center>
  <center><h5 class="h5 mb-5 font-weight-normal">Log In</h5></center>
  <label for="inputEmail" class="sr-only">User Name</label>
    <center><i class="fa fa-user"></i></center>
  <input type="text" name="user_name" class="form-control" placeholder="Enter User Name" required autofocus>
    <label for="inputEmail" class="sr-only">Password</label>
    <center><i class="fa fa-key"></i></center>
  <input type="password" name="user_password" class="form-control" placeholder="Enter Password" required autofocus>
  <input type="submit" class="btn btn-lg btn-primary btn-block" name="submit" value="Submit">
  <center><p class="mt-5 mb-3 ">&copy; 2020-2021</p></center>
</form>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
            <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
  </body>
</html>
