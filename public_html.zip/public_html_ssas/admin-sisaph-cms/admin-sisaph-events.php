<?php 
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
$user = new User();
ob_start();
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");
$today = strtotime($todays_date);

$conn = mysqli_connect("localhost","root", "", "id14326742_admin_cms");
$query = "SELECT * FROM sisa_events";
$result =mysqli_query($conn,$query);
$nr = mysqli_num_rows($result); // Get total of Num rows from the database query

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{
  $sql = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:admin-sisaph-login/index.php");
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($conn,$sql);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
}

 //---------------Submit Button ---------------///

if (isset($_REQUEST['sub-add-event'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$adding = $user->add_event($ev_name,$ev_month,$ev_year,$ev_address,$ev_class,$ev_status,$ad_name);
if ($adding) {
            // Saving judge name Success
  echo "<script>alert('New event have been added successfully!!!'); window.location='admin-sisaph-events.php'</script>";
} else {
            // Saving judge name Failed
 echo "<script>alert('Failed to add new event. Please try again.'); window.location='admin-sisaph-events.php'</script>";
}
}
 //---------------Submit Edit Event ---------------///

if (isset($_REQUEST['sub-edit-event'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$edit = $user->edit_event($ev_name,$ev_month,$ev_year,$ev_address,$ev_class,$ev_status,$ad_name);
if ($edit) {
            // Saving judge name Success
  echo "<script>alert('The event have been edited successfully!!!'); window.location='admin-sisaph-events.php'</script>";
} else {
            // Saving judge name Failed
 echo "<script>alert('Failed to edit the event. Please try again.'); window.location='admin-sisaph-events.php'</script>";
}
}
ob_end_flush();
?>

<!doctype html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Events">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
  <title>SISA PH Events</title>
</head>
<body class="bod">
<?php include("admin-sisaph-nav.php"); ?>
  
<div class="content">
      <div class="btn-toolbar mb-2 mb-md-0">
          <h5>Events</h5>&nbsp;&nbsp;&nbsp;
          <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#add-event">Add New Event</button>
          </div>
        <div class="btn-group mr-2">
        <font class="btn btn-sm btn-outline-secondary">Total of Events: <?php echo $nr; ?></font>
      </div>
      
      <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
          <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
        </div>
        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
          <span data-feather="calendar"></span>
          This week
        </button>
      </div>

    <!-- Modal Adding Event -->
    <div class="modal fade" id="add-event" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Add New Event</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST">
              <div class="form-group">
               <span id="error_message" class="text-danger"></span>  
               <span id="success_message" class="text-success"></span>
               <input type="text" class="form-control" name="ev_name" placeholder="Write the event name"  required>
               <select type="text" class="form-control" name="ev_month" id="ev_month" required>
                <option value="">--Select Year--</option>
                <option value="January">January</option>
                <option value="February">February</option>  
                <option value="March">March</option>  
                <option value="April">April</option>  
                <option value="May">May</option>  
                <option value="June">June</option>  
                <option value="July">July</option>  
                <option value="August">August</option>  
                <option value="September">September</option>  
                <option value="October">October</option>  
                <option value="November">November</option>  
                <option value="December">December</option>    
              </select>
              <label class="text-muted">Choose the months.</label>
              <input type="text" class="form-control" name="ev_day" placeholder="Write the event day from start to end, Exa: 5-6" required>
              <input type="text" class="form-control" name="ev_year" placeholder="Write the event year"  required>
              <input type="text" class="form-control" name="ev_address" placeholder="Write the event address" required>
              <input type="text" class="form-control" name="ev_class" placeholder="Write the event classification" required>
              <select type="text" class="form-control" name="ev_status" id="ev_status" required>
                <option value="">--Select Status--</option>
                <option value="Upcoming">Upcoming</option>
                <option value="Postponed">Postponed</option>  
                <option value="Completed">Completed</option>     
              </select>
              <label class="text-muted">Choose the event status.</label>
              <input type="hidden" class="form-control" name="ad_name" value="<?php echo $user->get_user_name($user_name); ?>" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="sub-add-event" class="btn btn-success">Add</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  
  <div class="table-responsive row justify-content"> 
    <table class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
          <th>Event Id</th>
          <th>Event Name</th>
          <th>Event Month</th>
          <th>Event Day</th>
          <th>Event Year</th>
          <th>Event Address</th>
          <th>Event Class</th>
          <th>Event Status</th>
          <th>Admin Name</th>
          <th>Date and Time Added</th>
          <th>Date and Time Edited</th>
          <th>Button Edit</th>
          <th>Button Upcoming/Postponed</th>
          <th>Button Completed</th>
        </tr>
      </thead>
      <?php  
        if(mysqli_num_rows($result) != 0){ // if open bracket    
          while($res = mysqli_fetch_array($result)){
            $id=$res['event_id'];
            ?>
            <tbody>
             <tr>
              <td><?php echo urlencode(base64_encode($res["event_id"])); ?></td>
              <td><?php echo $res["ev_name"]; ?></td>
              <td><?php echo $res["ev_month"]; ?></td>
              <td><?php echo $res["ev_day"]; ?></td>
              <td><?php echo $res["ev_year"]; ?></td>
              <td><?php echo $res["ev_address"]; ?></td>
              <td><?php echo $res["ev_class"]; ?></td>
              <td><?php echo $res["ev_status"]; ?></td>
              <td><?php echo $res["ad_name"]; ?></td>
              <td><?php echo $res["date_time_added"]; ?></td>
              <td><?php echo $res["date_time_edited"]; ?></td>
              <td><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#event<?php echo $id; ?>">
                Edit
              </button></td>
              
              <!-- Modal Edit Event-->
              <div class="modal fade" id="event<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title" id="exampleModalLabel">Edit Judge Account</h5>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                      </button>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo '?event_id='.$id; ?>" method="POST" name="">
                        <div class="form-group">
                          <input type="text" class="form-control" name="ev_name" value="<?php echo $res["ev_name"]; ?>" required>
                          <small  class="form-text text-muted">Write the event name do you want.</small>
                          <input type="text" class="form-control" name="ev_month" value="<?php echo $res["ev_month"]; ?>" required>
                          <small  class="form-text text-muted">Write the event month do you want.</small>
                          <input type="text" class="form-control" name="ev_day" value="<?php echo $res["ev_day"]; ?>" required>
                          <small  class="form-text text-muted">Write the event day do you want.</small>
                          <input type="text" class="form-control" name="ev_year"  value="<?php echo $res["ev_year"]; ?>" required>
                          <small  class="form-text text-muted">Write the event year do you want.</small>
                          <input type="text" class="form-control" name="ev_address" value="<?php echo $res["ev_address"]; ?>" required>
                          <small  class="form-text text-muted">Write the event address do you want.</small>
                          <input type="text" class="form-control" name="ev_class" value="<?php echo $res["ev_class"]; ?>" required>
                          <small  class="form-text text-muted">Write the event class do you want.</small>
                          <input type="text" class="form-control" name="ev_status"  value="<?php echo $res["ev_status"]; ?>" required>
                          <small class="form-text text-muted">Write the event status do you want.</small>
                          <input type="hidden" class="form-control" name="ad_name" value="<?php $user->get_user_name($user_name); ?>" required>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                          <button type="submit" name="sub-edit-event" class="btn btn-success">Save Changes</button>
                        </div>
                      </form>
                    </div>
                  </div>
                </div> 
                <?php echo "<td><a class='btn btn-warning' href=\"upcoming_ev.php?id=$res[event_id]\" onClick=\"return confirm('Are you sure do you want to change into Upcoming?')\">Upcoming</a> <a class='btn btn-success' href=\"postponed_ev.php?id=$res[event_id]\" onClick=\"return confirm('Are you sure do you want to change into Postponed')\">Postponed</a></td>"; ?>
                <?php echo "<td><a class='btn btn-primary' href=\"completed_ev.php?id=$res[event_id]\" onClick=\"return confirm('Are you sure do you want to change into Completed')\">Completed</a></td>"; ?>
              </tr>
              <?php
            }
          }else{
            ?>
            <tr>
             <td colspan="13"><center><p>No Records</p></center></td>
           </tr>
         <?php }// esle if statement close bracket ?>
       </tbody>
     </table>
   </div>
</div>
<!-- FOOTER -->
<?php include("admin-sisaph-footer.php"); ?>

</body>
</html>