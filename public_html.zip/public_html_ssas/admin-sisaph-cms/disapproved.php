<?php
//including the database connection file
include_once("classes/Crud.php");

$crud = new Crud();

//getting id of the data from url
$active = $crud->escape_string($_GET['id']);

//deleting the row from table
//$result = $crud->execute("DELETE FROM admin_personnel WHERE id=$active");
$result = $crud->disapproved($active, 'admin_personnel');

if ($result) {
	//redirecting to the display page (admin-sisaph-personnel.php in our case)
	header("Location:admin-sisaph-personnel.php");
}
?>

