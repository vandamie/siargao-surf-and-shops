<?php

$con = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
$result = mysqli_query($con,"select count(*) FROM judges_account WHERE ju_status='Online' AND judge_id = judge_id");
$on = mysqli_fetch_array($result);

?>