<?php 
session_start();
require_once ("admin-sisaph-login/include/class.user.php"); // class of functions of User.
$user = new User();
ob_start();
$user_name = $_SESSION['id'];
$user_status = $_SESSION['id'];
$connect = mysqli_connect("localhost","root", "", "id14326742_admin_cms");

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");
$today = strtotime($todays_date);


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:admin-sisaph-login/index.php");
}else{

  $sql = "UPDATE admin_personnel SET user_status = 'Online', time_in = '$today' WHERE id = '$user_status'";
  mysqli_query($connect,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:ndex.php");

  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($connect,$sql);
  session_destroy();
  session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] > 900)) { 
  session_destroy();
  session_unset();

  $sql = "UPDATE admin_personnel SET user_status = 'Offline', time_out = '$today' WHERE id = '$user_status'";
  mysqli_query($connect,$sql);
  header("location:admin-sisaph-login/index.php");
}else {
  $_SESSION['user_name'] = time();
} 

//---------------Submit Button ---------------///

if (isset($_REQUEST['submit'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$admin = $user->reg_admin($ad_name,$ad_password,$ad_email);
if ($admin) {
            // Saving judge name Success
    echo "<script>alert('New admin has added successfully!!!'); window.location='admin-sisaph-personnel.php'</script>";
} else {
            // Saving judge name Failed
 echo "<script>alert('Failed to add new admin user.'); window.location='admin-sisaph-personnel.php'</script>";
}
}

ob_end_flush();
?>

<?php
//database and class connection
require_once("classes/Crud.php");
require_once("con_online.php");
require_once("con_offline.php");


 // pagination connection of database and pages when you click
$query = "SELECT * FROM admin_personnel order by id DESC";
$result = mysqli_query($connect, $query);

?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Administrator">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <!-- Load an icon library -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Website Icon -->
  <link rel="icon" type="image/x-icon" href="images/ssas-logo.png" />
  <!-- Website Title -->
    <title>SISA PH Administrator</title>
</head>
<body class="bod">
<?php include("admin-sisaph-nav.php"); ?>
     
<div class="content">
      <div class="btn-toolbar mb-2 mb-md-0">
          <h5>Administrator</h5>&nbsp;&nbsp;&nbsp;
          <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary" data-toggle="modal" data-target="#admin">Add New Administrator</button>
          </div>

      <div class="btn-group mr-2">
          <button type="button" class="btn btn-sm btn-outline-secondary">Share</button>
          <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
        </div>
        <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
          <span data-feather="calendar"></span>
          This week
        </button>
      </div>
         

<!-- Modal Header Title -->
<div class="modal fade" id="admin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Administrator</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form method="post">
  <div class="form-group">
    <input type="text" class="form-control" name="ad_name" placeholder="Username" aria-describedby="admin name" required>
    <small id="judgeHelp" class="form-text text-muted">Write the username do you want.</small>
    <input type="password" class="form-control" name="ad_password" placeholder="Password" aria-describedby="admin password" required>
    <small id="judgeHelp" class="form-text text-muted">Write atleast 8 character.</small>
    <input type="email" class="form-control" name="ad_email" placeholder="Email" aria-describedby="admin email" required>
    <small id="judgeHelp" class="form-text text-muted">Write the active email.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="submit" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>


      
     <?php
              $online = $on[0];
              ?>
              <h6>Total of Online = <font style='color:blue;'><?php echo $online; ?></font></h6>
               <?php
               mysqli_close($con);
               ?> 

               <?php
              $offline = $off[0];
              ?>
              <h6>Total of Offline = <font style='color:red;'><?php echo $offline; ?></font></h6>
              <?php
              mysqli_close($conn);
              ?>

    <div class="table-responsive row justify-content"> 
    <table class="table table-bordered table-striped table-hover">
          <thead>
            <tr>
              <th>Admin Id</th>
              <th>User Name</th>
              <th>Password</th>
              <th>Email</th>
              <th>Time In</th>
              <th>Time Out</th>
              <th>Admin Approval</th>
              <th>Admin Status</th>
              <th>Admin Type</th>
              <th>Button Update</th>
              <th>Button Approval</th>
              <th>Button Type</th>
            </tr>
          </thead>
          <?php 
          
          while($res = mysqli_fetch_array($result)) 
            if($res["user_status"] !='Online' ){ // if open bracket
          { // while open bracket
           ?>
           <tbody>
           <tr>
              <td><?php echo urlencode(base64_encode($res["id"])); ?></td>
              <td><?php echo $res["user_name"]; ?></td>
              <td><?php echo $res["user_password"]; ?></td>
              <td><?php echo $res["user_email"]; ?></td>
              <td><?php echo $res["time_in"]; ?></td>
              <td><?php echo $res["time_out"]; ?></td>
              <td><?php echo $res["user_active"]; ?></td>
              <td style="color:red;"><?php echo $res["user_status"]; ?></td>
              <td><?php echo $res["user_type"]; ?></td>
             <?php echo "<td id='outer'> <a class='btn btn-danger' href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>"; ?>
               <?php echo "<td id='outer'><a class='btn btn-warning' href=\"disapproved.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to disapproved?')\">Disapproved</a> <a class='btn btn-success' href=\"approved.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to approved?')\">Approved</a></td>"; ?>
                <?php echo "<td id='outer'><a class='btn btn-primary' href=\"primary.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to make this as primary user?')\">Primary</a> <a class='btn btn-secondary' href=\"secondary.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to make this as secondary user?')\">Secondary</a> </td>"; ?>
          </tr>
          <?php
      } // while loop close bracket
    }else{
      ?>

          <tr>
               <td><?php echo $res["id"]; ?></td>
              <td><?php echo $res["user_name"]; ?></td>
              <td><?php echo $res["user_password"]; ?></td>
              <td><?php echo $res["user_email"]; ?></td>
              <td><?php echo $res["time_in"]; ?></td>
              <td><?php echo $res["time_out"]; ?></td>
              <td><?php echo $res["user_active"]; ?></td>
              <td style="color:blue;"><?php echo $res["user_status"]; ?></td>
              <td><?php echo $res["user_type"]; ?></td>
             <?php echo "<td id='outer'> <a class='btn btn-danger' href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>"; ?>
               <?php echo "<td id='outer'><a class='btn btn-warning' href=\"disapproved.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to disapproved?')\">Disapproved</a> <a class='btn btn-success' href=\"approved.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to approved?')\">Approved</a></td>"; ?>
                <?php echo "<td id='outer'><a class='btn btn-primary' href=\"primary.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to make this as primary user?')\">Primary</a> <a class='btn btn-secondary' href=\"secondary.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to make this as secondary user?')\">Secondary</a> </td>"; ?>
          </tr>


    <?php } // esle if statement close bracket ?>
    </tbody>
    </table>
     </div>
    

  
<!----- javascript of search ingine------>
   <script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</div>

<?php include("admin-sisaph-footer.php"); ?>
</body>
</html>