-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 09, 2021 at 07:53 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id14326742_admin_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_personnel`
--

CREATE TABLE `admin_personnel` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_in` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_out` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_active` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin_personnel`
--

INSERT INTO `admin_personnel` (`id`, `user_name`, `user_password`, `user_email`, `time_in`, `time_out`, `user_active`, `user_status`, `user_type`) VALUES
(1, 'van', '957d2fa52c19a5aff4ccf5d9a959adab', 'van@gmail.com', '1613357393', '1613291075', 'Yes', 'Online', 'Primary'),
(4, 'aike', 'bdb38d01d0a17952b21d20f40c248a82', 'aike@gmail.com', '1596803533', '1596803533', 'No', 'Offline', 'Primary');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `cus_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cus_password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cus_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `q_sec1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sec_ans1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `q_sec2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `sec_ans2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_in` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `time_out` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cus_active` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cus_status` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cus_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `cus_name`, `cus_password`, `cus_email`, `q_sec1`, `sec_ans1`, `q_sec2`, `sec_ans2`, `time_in`, `time_out`, `cus_active`, `cus_status`, `cus_type`) VALUES
(17, 'van', '957d2fa52c19a5aff4ccf5d9a959adab', 'van@gmail.com', 'Who is you favorite actor?', 'van', 'What is your favorite sports?', 'boxing', '21-02-25,08:15:24pm', '21-02-25,08:15:24pm', 'Yes', 'Offline', 'User'),
(18, 'ron', '45798f269709550d6f6e1d2cf4b7d485', 'ron@gmail.com', 'What is your dream job?', 'rone', 'What is your dream job?', 'rone', '21-01-31,01:41:18am', '21-01-31,01:41:18am', 'Yes', 'Offline', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `customer_message`
--

CREATE TABLE `customer_message` (
  `cu_id` int(11) NOT NULL,
  `cu_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cu_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `cu_subject` text COLLATE utf8_unicode_ci NOT NULL,
  `cu_message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cu_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer_message`
--

INSERT INTO `customer_message` (`cu_id`, `cu_name`, `cu_email`, `cu_subject`, `cu_message`, `cu_date_time`) VALUES
(1, 'Van Espa', 'vandamie.espadero@gmail.com', 'I want you be my husband. toinks!', 'I want you now my love.', '20-12-27,01:56:10am'),
(2, 'Van Espa', 'vandamie.espadero@gmail.com', 'I want you be my husband. toinks!', 'I love you.', '20-12-27,02:06:12am'),
(3, 'Van Espa', 'vandamie.espadero@gmail.com', 'I want you be my husband. toinks!', 'I love you.', '20-12-27,02:17:39am'),
(4, 'Van Espa', 'vandamie.espadero@gmail.com', 'I want you be my husband. ', 'hello.', '20-12-27,03:38:26am'),
(5, 'Van', 'vandamie.espadero@icloud.com', 'Van', 'Van', '21-01-29,05:21:10am'),
(6, 'van', 'vandamie.espadero@gmail.com', 'van', 'van', '21-01-29,05:30:13am'),
(7, 'van', 'vandamie.espadero@gmail.com', 'van', 'van', '21-01-29,05:31:48am');

-- --------------------------------------------------------

--
-- Table structure for table `data_link`
--

CREATE TABLE `data_link` (
  `link_id` int(11) NOT NULL,
  `link_div1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link_div2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link_div3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link_div4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `link_div5` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_link`
--

INSERT INTO `data_link` (`link_id`, `link_div1`, `link_div2`, `link_div3`, `link_div4`, `link_div5`, `date_time`) VALUES
(1, 'Men\'s Open', 'Women\'s Open', 'Grommet', 'Airborne', 'Master\'s', 'Oct. 31, 2020, 12:17:25 am');

-- --------------------------------------------------------

--
-- Table structure for table `data_monitoring`
--

CREATE TABLE `data_monitoring` (
  `dm_id` int(11) NOT NULL,
  `judge_names` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `actions` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dm_wave` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dm_at1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dm_at2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dm_at3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `dm_at4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `score1` double(10,2) NOT NULL,
  `score2` double(10,2) NOT NULL,
  `score3` double(10,2) NOT NULL,
  `score4` double(10,2) NOT NULL,
  `cur_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `data_monitoring`
--

INSERT INTO `data_monitoring` (`dm_id`, `judge_names`, `actions`, `dm_wave`, `dm_at1`, `dm_at2`, `dm_at3`, `dm_at4`, `score1`, `score2`, `score3`, `score4`, `cur_time`) VALUES
(1, 'Amay', 'was gave scores', '1', 'Lebron', 'Durant', 'Curry', 'Wade', 10.00, 8.00, 9.00, 7.00, 'Oct. 31, 2020, 06:42:29 pm'),
(2, 'Amay', 'was gave scores', '2', 'Lebron', 'Durant', 'Curry', '-', 0.00, 3.00, 0.00, 0.00, 'Oct. 31, 2020, 06:44:52 pm'),
(3, 'Amay', 'was deleted his/her scores', '2', 'Lebron', 'Durant', 'Curry', '-', 0.00, 3.00, 0.00, 0.00, 'Nov. 05, 2020, 02:36:38 pm'),
(4, 'Amay', 'was deleted his/her scores', '1', 'Lebron', 'Durant', 'Curry', 'Wade', 10.00, 8.00, 9.00, 7.00, 'Nov. 05, 2020, 02:36:53 pm'),
(5, 'Amay', 'was gave scores', '1', 'Lebron', 'Durant', 'Curry', '-', 10.00, 8.50, 3.20, 0.00, 'Nov. 06, 2020, 10:48:42 am'),
(6, 'Judge5', 'was gave scores', '1', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 0.00, 0.00, 2.50, 0.00, 'Nov. 20, 2020, 10:59:07 pm'),
(7, 'Amay', 'was deleted his/her scores', '1', 'Lebron', 'Durant', 'Curry', '-', 10.00, 8.50, 3.20, 0.00, 'Nov. 22, 2020, 08:30:02 pm'),
(8, 'Amay', 'was gave scores', '1', 'Lebron', 'Durant', 'Curry', 'Jordan', 1.00, 3.00, 0.00, 0.00, 'Nov. 22, 2020, 09:25:02 pm'),
(9, 'Amay', 'was gave scores', '2', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 3.90, 0.00, 0.00, 0.00, 'Dec. 14, 2020, 11:37:15 am'),
(10, 'Amay', 'was deleted his/her scores', '2', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 3.90, 0.00, 0.00, 0.00, 'Feb. 09, 2021, 12:11:37 pm'),
(11, 'Amay', 'was gave scores', '2', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 0.00, 0.00, 4.00, 0.00, 'Feb. 09, 2021, 12:11:50 pm');

-- --------------------------------------------------------

--
-- Table structure for table `judges_account`
--

CREATE TABLE `judges_account` (
  `judge_id` int(11) NOT NULL,
  `ju_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ju_password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ju_active` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ju_status` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_time` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `judges_account`
--

INSERT INTO `judges_account` (`judge_id`, `ju_name`, `ju_password`, `ju_active`, `ju_status`, `date_time`) VALUES
(1, 'judge1', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Online', 'Jan. 16, 2021, 05:35:11 pm'),
(2, 'judge2', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Offline', 'Sep. 19, 2020, 01:58:26 pm'),
(3, 'judge3', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Offline', 'Sep. 19, 2020, 02:00:20 pm'),
(4, 'judge4', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Offline', 'Sep. 19, 2020, 02:06:33 pm'),
(5, 'judge5', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Offline', 'Sep. 19, 2020, 02:09:39 pm'),
(6, 'hjudge', '9b9d451c14ee44d4d8da4dc284c1bcc6', 'Yes', 'Offline', 'Sep. 19, 2020, 02:11:54 pm');

-- --------------------------------------------------------

--
-- Table structure for table `judges_data_form`
--

CREATE TABLE `judges_data_form` (
  `form_id` int(11) NOT NULL,
  `logo` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bg_img` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_title` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ju_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_date` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_division` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_stage` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_heat` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_col_one` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_col_two` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_col_three` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_col_four` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_img_one` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_img_two` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_img_three` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_img_four` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_one` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_two` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_three` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at_four` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_time` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `judges_data_form`
--

INSERT INTO `judges_data_form` (`form_id`, `logo`, `bg_img`, `event_title`, `ju_name`, `event_date`, `at_division`, `at_stage`, `at_heat`, `at_col_one`, `at_col_two`, `at_col_three`, `at_col_four`, `at_img_one`, `at_img_two`, `at_img_three`, `at_img_four`, `at_one`, `at_two`, `at_three`, `at_four`, `date_time`) VALUES
(1, '196476.jpg', '572174.jpg', 'Cloud 9 Master', 'Amay', 'January 4, 2022', 'Men\'s Open', 'Quarterfinals', 'Heat 1', 'red', 'blue', 'yellow', 'white', '2122.jpg', '808498.jpg', '176428.jpg', '533068.jpg', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '21-01-16 05:38:33pm'),
(2, 'sisa-logo.jpg', 'cloud-9.jpg', 'Cloud Nine Masters', 'Atty. MANTILLA ', 'January 4, 2022', 'Men\'s Open', 'Round 1', 'Heat 7', 'Red', 'Blue ', 'White', '-', '577108.png', '140536.png', '91336.png', '822976.png', 'Filipe Toledo', 'Kelly Slater ', 'Matt Banting', '-', '20-10-31 06:35:22pm'),
(3, 'sisa-logo.jpg', 'cloud-9.jpg', 'Cloud Nine Masters', 'Judge3', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', 'none', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 'January 4, 2022'),
(4, 'sisa-logo.jpg', 'cloud-9.jpg', 'Cloud Nine Masters', 'Judge4', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', 'none', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 'January 4, 2022'),
(5, 'sisa-logo.jpg', 'cloud-9.jpg', 'Cloud Nine Masters', 'Judge5', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', 'none', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 'January 4, 2022');

-- --------------------------------------------------------

--
-- Table structure for table `judge_five`
--

CREATE TABLE `judge_five` (
  `jsb_id` int(11) NOT NULL,
  `wavec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at1` double(10,2) NOT NULL,
  `at2` double(10,2) NOT NULL,
  `at3` double(10,2) NOT NULL,
  `at4` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_five`
--

INSERT INTO `judge_five` (`jsb_id`, `wavec`, `at_n1`, `at_n2`, `at_n3`, `at_n4`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(148, '1', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 0.00, 0.00, 2.50, 0.00, 'Nov. 20, 2020, 10:59:07 pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_four`
--

CREATE TABLE `judge_four` (
  `jsb_id` int(11) NOT NULL,
  `wavec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at1` double(10,2) NOT NULL,
  `at2` double(10,2) NOT NULL,
  `at3` double(10,2) NOT NULL,
  `at4` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `judge_one`
--

CREATE TABLE `judge_one` (
  `jsb_id` int(11) NOT NULL,
  `wavec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at1` double(10,2) NOT NULL,
  `at2` double(10,2) NOT NULL,
  `at3` double(10,2) NOT NULL,
  `at4` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_one`
--

INSERT INTO `judge_one` (`jsb_id`, `wavec`, `at_n1`, `at_n2`, `at_n3`, `at_n4`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(23, '1', 'Lebron', 'Durant', 'Curry', 'Jordan', 1.00, 3.00, 0.00, 0.00, 'Nov. 22, 2020, 09:25:02 pm'),
(25, '2', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 0.00, 0.00, 4.00, 0.00, 'Feb. 09, 2021, 12:11:50 pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_three`
--

CREATE TABLE `judge_three` (
  `jsb_id` int(11) NOT NULL,
  `wavec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at1` double(10,2) NOT NULL,
  `at2` double(10,2) NOT NULL,
  `at3` double(10,2) NOT NULL,
  `at4` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `judge_two`
--

CREATE TABLE `judge_two` (
  `jsb_id` int(11) NOT NULL,
  `wavec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at_n4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `at1` double(10,2) NOT NULL,
  `at2` double(10,2) NOT NULL,
  `at3` double(10,2) NOT NULL,
  `at4` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `news_article`
--

CREATE TABLE `news_article` (
  `newsart_id` int(11) NOT NULL,
  `newsart_title` text COLLATE utf8_unicode_ci NOT NULL,
  `newsart_category` text COLLATE utf8_unicode_ci NOT NULL,
  `newsart_details` longtext COLLATE utf8_unicode_ci NOT NULL,
  `newsart_image` longblob NOT NULL,
  `newsart_author` text COLLATE utf8_unicode_ci NOT NULL,
  `newsart_date` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `news_article`
--

INSERT INTO `news_article` (`newsart_id`, `newsart_title`, `newsart_category`, `newsart_details`, `newsart_image`, `newsart_author`, `newsart_date`) VALUES
(62, 'van', 'Present Event', '&lt;div style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 1rem;&quot;&gt;&lt;b&gt;&lt;br&gt;&lt;/b&gt;&lt;/span&gt;&lt;/div&gt;&lt;div style=&quot;text-align: center;&quot;&gt;&lt;b&gt;&lt;font face=&quot;comic sans ms&quot; size=&quot;5&quot;&gt;Header&lt;/font&gt;&lt;span style=&quot;font-size: 1rem;&quot;&gt;&amp;nbsp;&lt;/span&gt;&lt;/b&gt;&lt;/div&gt;&lt;blockquote style=&quot;margin: 0 0 0 40px; border: none; padding: 0px;&quot;&gt;&lt;div style=&quot;text-align: left;&quot;&gt;&lt;span style=&quot;font-size: 1rem;&quot;&gt;&lt;b&gt;Lets go surfing today, waves are so sick!!!&lt;/b&gt;&lt;/span&gt;&lt;/div&gt;&lt;/blockquote&gt;', 0x3438393331302e6a7067, 'Van', 'Feb.14,2021');

-- --------------------------------------------------------

--
-- Table structure for table `organize_event`
--

CREATE TABLE `organize_event` (
  `og_id` int(11) NOT NULL,
  `og_date` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_division` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_stage` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_heat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_jc1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_jc2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_jc3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_jc4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_at1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_at2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_at3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `og_at4` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `organize_event`
--

INSERT INTO `organize_event` (`og_id`, `og_date`, `og_division`, `og_stage`, `og_heat`, `og_jc1`, `og_jc2`, `og_jc3`, `og_jc4`, `og_at1`, `og_at2`, `og_at3`, `og_at4`) VALUES
(1, 'Sep. 09, 2020', 'Men\'s Open', 'Quarterfinal', 'Heat 1', 'green', 'blue', 'yellow', 'white', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.'),
(2, 'Sep. 10, 2020', 'Men\'s Open', 'Final', '--', 'red', 'blue', 'yellow', 'orange', 'Manit Alcala', 'Alice Aurora', '--', '--'),
(3, 'Sep. 11, 2020', 'Grommet', 'Quarterfinal', 'Heat 1', 'red', 'blue', 'orange', 'pink', 'Kai kai Alcala', 'James Aurora', 'Maclyn Oraliza', 'James Gaffud'),
(4, 'Sep. 12, 2020', 'Airborne', 'Final', '-', 'red', 'purple', '-', '-', 'Philmar Alipayo', 'Edito Alcala Jr.', '--', '--'),
(5, 'Sep. 09, 2020', 'Men\'s Open', 'Final', '-', 'red', 'blue', 'yellow', 'white', 'SADAM', 'AMAY', '-', '-'),
(6, 'Sep. 09, 2020', 'Men\'s Open', 'Quarterfinal', 'Heat 1', 'red', 'blue', 'yellow', 'brown', 'Philmar Alipayo', 'Manit Alcala', 'Kai kai Alcala', 'James Gaffud'),
(7, 'Sep. 09, 2020', 'Men\'s Open', 'Quarterfinal', 'Heat 1', 'red', 'blue', 'yellow', 'pink', 'Philmar Alipayo', 'PJ Alipayo', 'Maclyn Oraliza', 'James Gaffud'),
(8, 'Sep. 09, 2020', 'Women\'s Open', 'Quarterfinal', 'Heat 1', 'blue', 'blue', 'yellow', 'pink', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `total_views` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `total_views`) VALUES
(1, 21),
(2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `page_views`
--

CREATE TABLE `page_views` (
  `visitor_ip` varchar(255) NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `month` varchar(100) NOT NULL,
  `day` varchar(100) NOT NULL,
  `year` varchar(100) NOT NULL,
  `time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_views`
--

INSERT INTO `page_views` (`visitor_ip`, `page_id`, `month`, `day`, `year`, `time`) VALUES
('110.54.227.24', 1, 'Jan', 'Sat', '2021', '04:45:35 am'),
('110.54.227.24', 2, 'Jan', 'Sat', '2021', '05:06:58 am'),
('109.66.33.149', 1, 'Jan', 'Sun', '2021', '12:44:57 am'),
('110.54.216.140', 1, 'Jan', 'Sun', '2021', '12:33:29 pm'),
('110.54.172.206', 1, 'Jan', 'Mon', '2021', '03:51:27 pm'),
('110.54.205.52', 1, 'Jan', 'Mon', '2021', '07:57:54 pm'),
('110.54.200.250', 1, 'Jan', 'Thu', '2021', '03:05:42 am'),
('110.54.173.76', 1, 'Jan', 'Thu', '2021', '06:13:55 pm'),
('110.54.170.148', 1, 'Jan', 'Fri', '2021', '05:29:45 am'),
('110.54.207.219', 1, 'Jan', 'Sun', '2021', '08:10:38 pm'),
('110.54.219.58', 1, 'Jan', 'Thu', '2021', '04:01:17 pm'),
('110.54.205.37', 1, 'Jan', 'Thu', '2021', '06:52:16 pm'),
('110.54.205.37', 2, 'Jan', 'Thu', '2021', '07:00:47 pm'),
('110.54.216.189', 1, 'Jan', 'Sun', '2021', '05:49:02 pm'),
('110.54.216.189', 2, 'Jan', 'Sun', '2021', '05:50:04 pm'),
('79.176.35.166', 2, 'Jan', 'Sun', '2021', '05:51:38 pm'),
('110.54.174.122', 1, 'Jan', 'Sun', '2021', '10:06:04 pm'),
('110.54.174.122', 1, 'Jan', 'Mon', '2021', '03:15:12 am'),
('110.54.174.122', 1, 'Jan', 'Mon', '2021', '03:23:17 am'),
('110.54.174.122', 1, 'Jan', 'Mon', '2021', '03:29:15 am'),
('110.54.216.79', 2, 'Jan', 'Mon', '2021', '06:05:21 am'),
('110.54.216.79', 1, 'Jan', 'Mon', '2021', '06:16:16 am'),
('110.54.168.234', 1, 'Jan', 'Mon', '2021', '01:02:53 pm'),
('110.54.168.234', 1, 'Jan', 'Mon', '2021', '01:26:23 pm'),
('110.54.168.234', 1, 'Jan', 'Mon', '2021', '01:30:05 pm'),
('110.54.168.234', 1, 'Jan', 'Mon', '2021', '01:30:19 pm');

-- --------------------------------------------------------

--
-- Table structure for table `sisaph_event_results`
--

CREATE TABLE `sisaph_event_results` (
  `fs_id` int(11) NOT NULL,
  `p1` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p2` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p3` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p4` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `division` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heat` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at1` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at2` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at3` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `at4` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `final1` double(10,2) NOT NULL,
  `final2` double(10,2) NOT NULL,
  `final3` double(10,2) NOT NULL,
  `final4` double(10,2) NOT NULL,
  `date_time` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sisaph_event_results`
--

INSERT INTO `sisaph_event_results` (`fs_id`, `p1`, `p2`, `p3`, `p4`, `division`, `stage`, `heat`, `at1`, `at2`, `at3`, `at4`, `final1`, `final2`, `final3`, `final4`, `date_time`) VALUES
(22, '943472.png', '886520.png', '975267.png', '246797.png', 'Men\'s Open', 'Quarterfinals', 'Heat 1', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 1.25, 1.10, 1.10, 1.10, 'Oct. 13, 2020 10:32:07am'),
(21, '943472.png', '886520.png', '975267.png', '246797.png', 'Men\'s Open', 'Quarterfinals', 'Heat 1', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 1.25, 1.10, 1.10, 1.10, 'Oct. 13, 2020 10:31:34am');

-- --------------------------------------------------------

--
-- Table structure for table `sisaph_rankings`
--

CREATE TABLE `sisaph_rankings` (
  `rank_id` int(11) NOT NULL,
  `r_number` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_points` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_earnings` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_name_leag` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_division` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `r_year` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sisaph_rankings`
--

INSERT INTO `sisaph_rankings` (`rank_id`, `r_number`, `r_name`, `r_points`, `r_earnings`, `r_name_leag`, `r_division`, `r_year`) VALUES
(1, '1', 'John Mark Tokong', '250', '₱110,000.00', 'Cloud 9 Master', 'Men\'s Shortboard', '2021'),
(2, '2', 'Edito Alcala Jr', '300', '₱108,000.00', 'Cloud 9 Master', 'Men\'s Shortboard', '2021'),
(3, '3', 'Philmar Alipayo', '175', '₱43,000.00', 'Cloud 9 Master', 'Men\'s Shortboard', '2021'),
(4, '4', 'Eduardo Alciso', '125', '₱23,000.00', 'Cloud 9 Master', 'Men\'s Shortboard', '2021'),
(5, '5', 'Kent Brian Solloso', '125', '₱16,000.00', 'Cloud 9 Master', 'Men\'s Shortboard', '2021'),
(6, '1', 'Nilbie Blancada', '75', '₱38,000.00', 'Cloud 9 Master', 'Women\'s Shortboard', '2021'),
(7, '2', 'Jolina Longos', '200', '₱26,000.00', 'Cloud 9 Master', 'Women\'s Shortboard', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `sisaph_scores`
--

CREATE TABLE `sisaph_scores` (
  `total_id` int(11) NOT NULL,
  `colors` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `athletes` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scores` double(10,2) NOT NULL,
  `event_date_time` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sisaph_scores`
--

INSERT INTO `sisaph_scores` (`total_id`, `colors`, `athletes`, `scores`, `event_date_time`) VALUES
(1, 'red', 'Philmar Alipayo', 1.00, 'Feb. 09, 2021, 12:11:50 pm'),
(2, 'blue', 'PJ Alipayo', 3.00, 'Feb. 09, 2021, 12:11:50 pm'),
(3, 'yellow', 'Loloy Espejon', 2.50, 'Feb. 09, 2021, 12:11:50 pm'),
(4, 'white', 'Edito Alcala Jr.', 0.00, 'Feb. 09, 2021, 12:11:50 pm');

-- --------------------------------------------------------

--
-- Table structure for table `sisa_events`
--

CREATE TABLE `sisa_events` (
  `event_id` int(11) NOT NULL,
  `ev_name` text NOT NULL,
  `ev_month` varchar(100) NOT NULL,
  `ev_day` varchar(100) NOT NULL,
  `ev_year` varchar(100) NOT NULL,
  `ev_address` longtext NOT NULL,
  `ev_class` longtext NOT NULL,
  `ev_status` varchar(100) NOT NULL,
  `ad_name` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sisa_events`
--

INSERT INTO `sisa_events` (`event_id`, `ev_name`, `ev_month`, `ev_day`, `ev_year`, `ev_address`, `ev_class`, `ev_status`, `ad_name`) VALUES
(2, 'Cloud 9 Master', 'February', '6-15', '2021', 'Barangay 2, General Luna, Surigao del Norte', 'Men\'s Open, Women\'s Open, Airborne, Grommet', 'Postponed', 'van'),
(15, 'Cloud 9 Master', 'January', '1-6', '2021', 'Barangay 2, General Luna, Surigao del Norte', 'Men\'s Open, Women\'s Open, Airborne, Grommet', 'Postponed', 'van');

-- --------------------------------------------------------

--
-- Table structure for table `upnext`
--

CREATE TABLE `upnext` (
  `un_id` int(11) NOT NULL,
  `un_date` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_division` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_stage` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_heat` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_jc1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_jc2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_jc3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_jc4` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_at1` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_at2` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_at3` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `un_at4` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `upnext`
--

INSERT INTO `upnext` (`un_id`, `un_date`, `un_division`, `un_stage`, `un_heat`, `un_jc1`, `un_jc2`, `un_jc3`, `un_jc4`, `un_at1`, `un_at2`, `un_at3`, `un_at4`) VALUES
(1, 'Oct. 30, 2020', 'Men\'s Open', 'Quarterfinal', 'Heat 1', 'red', 'blue', 'yellow', 'green', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_personnel`
--
ALTER TABLE `admin_personnel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_message`
--
ALTER TABLE `customer_message`
  ADD PRIMARY KEY (`cu_id`);

--
-- Indexes for table `data_link`
--
ALTER TABLE `data_link`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `data_monitoring`
--
ALTER TABLE `data_monitoring`
  ADD PRIMARY KEY (`dm_id`);

--
-- Indexes for table `judges_account`
--
ALTER TABLE `judges_account`
  ADD PRIMARY KEY (`judge_id`);

--
-- Indexes for table `judges_data_form`
--
ALTER TABLE `judges_data_form`
  ADD PRIMARY KEY (`form_id`);

--
-- Indexes for table `judge_five`
--
ALTER TABLE `judge_five`
  ADD PRIMARY KEY (`jsb_id`);

--
-- Indexes for table `judge_four`
--
ALTER TABLE `judge_four`
  ADD PRIMARY KEY (`jsb_id`);

--
-- Indexes for table `judge_one`
--
ALTER TABLE `judge_one`
  ADD PRIMARY KEY (`jsb_id`);

--
-- Indexes for table `judge_three`
--
ALTER TABLE `judge_three`
  ADD PRIMARY KEY (`jsb_id`);

--
-- Indexes for table `judge_two`
--
ALTER TABLE `judge_two`
  ADD PRIMARY KEY (`jsb_id`);

--
-- Indexes for table `news_article`
--
ALTER TABLE `news_article`
  ADD PRIMARY KEY (`newsart_id`);

--
-- Indexes for table `organize_event`
--
ALTER TABLE `organize_event`
  ADD PRIMARY KEY (`og_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_views`
--
ALTER TABLE `page_views`
  ADD KEY `page_id` (`page_id`);

--
-- Indexes for table `sisaph_event_results`
--
ALTER TABLE `sisaph_event_results`
  ADD PRIMARY KEY (`fs_id`);

--
-- Indexes for table `sisaph_rankings`
--
ALTER TABLE `sisaph_rankings`
  ADD PRIMARY KEY (`rank_id`);

--
-- Indexes for table `sisaph_scores`
--
ALTER TABLE `sisaph_scores`
  ADD PRIMARY KEY (`total_id`);

--
-- Indexes for table `sisa_events`
--
ALTER TABLE `sisa_events`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `upnext`
--
ALTER TABLE `upnext`
  ADD PRIMARY KEY (`un_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_personnel`
--
ALTER TABLE `admin_personnel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `customer_message`
--
ALTER TABLE `customer_message`
  MODIFY `cu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `data_link`
--
ALTER TABLE `data_link`
  MODIFY `link_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_monitoring`
--
ALTER TABLE `data_monitoring`
  MODIFY `dm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `judges_account`
--
ALTER TABLE `judges_account`
  MODIFY `judge_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `judges_data_form`
--
ALTER TABLE `judges_data_form`
  MODIFY `form_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `judge_five`
--
ALTER TABLE `judge_five`
  MODIFY `jsb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=149;

--
-- AUTO_INCREMENT for table `judge_four`
--
ALTER TABLE `judge_four`
  MODIFY `jsb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=147;

--
-- AUTO_INCREMENT for table `judge_one`
--
ALTER TABLE `judge_one`
  MODIFY `jsb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `judge_three`
--
ALTER TABLE `judge_three`
  MODIFY `jsb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=148;

--
-- AUTO_INCREMENT for table `judge_two`
--
ALTER TABLE `judge_two`
  MODIFY `jsb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `news_article`
--
ALTER TABLE `news_article`
  MODIFY `newsart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `organize_event`
--
ALTER TABLE `organize_event`
  MODIFY `og_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sisaph_event_results`
--
ALTER TABLE `sisaph_event_results`
  MODIFY `fs_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sisaph_rankings`
--
ALTER TABLE `sisaph_rankings`
  MODIFY `rank_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `sisaph_scores`
--
ALTER TABLE `sisaph_scores`
  MODIFY `total_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sisa_events`
--
ALTER TABLE `sisa_events`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `upnext`
--
ALTER TABLE `upnext`
  MODIFY `un_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `page_views`
--
ALTER TABLE `page_views`
  ADD CONSTRAINT `page_views_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
