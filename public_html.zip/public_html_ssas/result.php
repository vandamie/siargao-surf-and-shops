<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
<title>Getting VALUES FORM Results</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<?php
$details="";
if(isset($_REQUEST['submit'])){
$details="<center><br><b>Your Account Details</b><br>"
."User ID: ". $_REQUEST['id']."<br>"
 ."User Name: ". $_REQUEST['username']."<br>"
 ."Email: ". $_REQUEST['email']."</center>";
printf($details);
}
?>
</body>
</html>