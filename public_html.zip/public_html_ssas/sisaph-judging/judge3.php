<?php 
ob_start();
session_start();
require_once("include/crud.php");
require_once ("include/class.judge.php"); // class of functions of User.
require_once ("include/database-con.php"); // class of functions of database connection.
$user = new judge();
$crud = new crud();

//user status and username session
$judge_username = $_SESSION['ju_name'];
$judge_status = $_SESSION['ju_name'];

//event form session
$event_title = $_SESSION['ju_name'];
$judge_name = $_SESSION['ju_name'];
$division = $_SESSION['ju_name'];
$date = $_SESSION['ju_name'];
$at_stage = $_SESSION['ju_name'];
$at_heat = $_SESSION['ju_name'];

$col_one = $_SESSION['ju_name'];
$col_two = $_SESSION['ju_name'];
$col_three = $_SESSION['ju_name'];
$col_four = $_SESSION['ju_name'];

$img_one = $_SESSION['ju_name'];
$img_two = $_SESSION['ju_name'];
$img_three = $_SESSION['ju_name'];
$img_four = $_SESSION['ju_name'];

$name_one = $_SESSION['ju_name'];
$name_two = $_SESSION['ju_name'];
$name_three = $_SESSION['ju_name'];
$name_four = $_SESSION['ju_name'];

$tol_one = $_SESSION['ju_name'];
$tol_two = $_SESSION['ju_name'];
$tol_three = $_SESSION['ju_name'];
$tol_four = $_SESSION['ju_name'];

$bgimg =$_SESSION['ju_name'];
$logo = $_SESSION['ju_name'];

$form = $_SESSION['ju_name'];


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:index.php");
}else{
  $sql = "UPDATE judges_account SET ju_status = 'Online' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:index.php");
  $sql = "UPDATE judges_account SET ju_status = 'Offline' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
  session_destroy();
  session_unset();
}







//---------------Submit logo_update-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['logo'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
$j1logo1 ="";
extract($_POST);
$edit_logo = $user->edit_logo($j1logo1);
if ($edit_logo) {
            // Saving logo Success
    echo "<script>alert('Logo has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving logo Failed
 echo "<script>alert('Not a valid logo.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit event title update-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['event_title'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_title = $user->edit_title($j1header1);
if ($edit_title) {
            // Saving title Success
    echo "<script>alert('Title has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving title Failed
 echo "<script>alert('Not a valid title.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}


//---------------Submit event jduge-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['judge_name'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_judge = $user->edit_judge_n($j1name1);
if ($edit_judge) {
            // Saving judge name Success
    echo "<script>alert('Judge has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving judge name Failed
 echo "<script>alert('Not a valid Judge.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit date-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['date_time'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_date = $user->edit_date($j1date1);
if ($edit_date) {
            // Saving date Success
    echo "<script>alert('Date has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving date Failed
 echo "<script>alert('Not a valid date.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit division-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_division'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_division = $user->edit_division($j1div1);
if ($edit_division) {
            // Saving division Success
    echo "<script>alert('Division has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving division Failed
 echo "<script>alert('Not a valid division.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit Stage-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_stage'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_stage = $user->edit_stage($j1st1);
if ($edit_stage) {
            // Saving stage Success
    echo "<script>alert('Stage has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving stage Failed
 echo "<script>alert('Not a valid Stage.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit Heat-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_heat'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_heat = $user->edit_heat($j1ht1);
if ($edit_heat) {
            // Saving stage Success
    echo "<script>alert('Heat has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving stage Failed
 echo "<script>alert('Not a valid heat.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit Jersey colors-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['jersey_colors'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_colors = $user->edit_jersey_col($j1col1,$j1col2,$j1col3,$j1col4);
if ($edit_colors) {
            // Saving colors Success
    echo "<script>alert('Colors has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving colors Failed
 echo "<script>alert('Not a valid Colors.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit Athlete Images-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_images'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
$j1img1 ="";
$j1img2 ="";
$j1img3 ="";
$j1img4 ="";
extract($_POST);
$edit_images = $user->edit_at_images($j1img1,$j1img2,$j1img3,$j1img4);
if ($edit_images) {
            // Saving Images Success
    echo "<script>alert('Athlete Images has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving Images score Failed
 echo "<script>alert('Not a valid images.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit update names-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_names'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_ath_names = $user->edit_at_names($j1n1,$j1n2,$j1n3,$j1n4);
if ($edit_ath_names) {
            // Saving names Success
    echo "<script>alert('Names has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving names Failed
 echo "<script>alert('Not a valid Names.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

//---------------Submit background image-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['bg_img'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
$bg1 ="";
extract($_POST);
$edit_bgimg = $user->edit_bg($bg1);
if ($edit_bgimg) {
            // Saving background image Success
    echo "<script>alert('Background image has save successfully!!!'); window.location='/sisaph-judging/judge3.php'</script>";
} else {
            // Saving background image Failed
 echo "<script>alert('Not a valid image.'); window.location='/sisaph-judging/judge3.php'</script>";
}
}

ob_end_flush();
?>
<!------------------------------------------------------------------------->



<!--------------------------------- judge-page.php--------------------------------------->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="description" content="Judging of Surfing Competition in Siargao Island, Philippines">
  <meta name="author" content="Siargao Web Protocol">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/<?php $user->get_logo($logo); ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <title>SISA PH Judge Page</title>

    <style>
body {
  background-image: url("images/<?php $user->get_bg_img($bgimg); ?>");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  font-family: Arial, Helvetica, sans-serif;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
  font-size:15px;
  padding-bottom: 40px;
  padding-top: 40px; 
}

.tr{
  border: 0;
  text-align: center;
  width: 100%;
}

.result{
  border: 0;
  text-align: center;
  width: 100%;
  font-size: 17px;
  font-weight: bold;
  text-decoration: underline;

}

.content {
  max-width: 1050px;
  margin: auto;
  background: white;
  border-radius: 35px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 8px;
  padding-right:8px;

}
.header{
  text-align: center;
}

* {
  box-sizing:border-box;
}

.left {
  width:35%; /* The width is 30%, by default */
  background-color:#F5F5F5;
  padding-left: 15px;
}

.main {
  width:40%; /* The width is 45%, by default */
  background-color:#F5F5F5;
}

.right { 
  width:35%; /* The width is 25%, by default */
  background-color:#F5F5F5;
  padding-right: 15px;
}

/* Use a media query to add a break point at 800px: */
@media screen and (max-width:800px) {
  .left, .main, .right {
    width:100%; /* The width is 100%, when the viewport is 800px or smaller */
  }
}

.img1 {
  border-radius: 50%;
  background:<?php $user->get_color_one($col_one); ?>;
  padding: 3px; 
  width:140px;
  height:140px;  
}
.img2 {
  border-radius: 50%;
  background:<?php $user->get_color_two($col_two); ?>;
  padding: 3px; 
  width:140px;
  height:140px;  
}
.img3 {
  border-radius: 50%;
  background:<?php $user->get_color_three($col_three); ?>;
  padding: 3px; 
  width:140px;
  height:140px;  
}
.img4 {
  border-radius: 50%;
  background:<?php $user->get_color_four($col_four); ?>;
  padding: 3px; 
  width:140px;
  height:140px;  
} 
.imglogo {
  border-radius: 50%;
  width:65px;
  height:65px;  
} 
.stroke1{
  background-color:#F5F5F5;
  border-radius-top:10%;
  padding: 10px;
  padding-right: 15px;
  padding-left: 15px;
}
.stroke2{
  background-color:#F5F5F5;
  padding: 8px;
  padding-right: 15px;
  padding-left: 15px;
}

.developer {
  color:#6495ED;
  font-size: 10px;
  text-align:center;
  padding-top: 5px;
  background-color:#F5F5F5;
  padding-bottom: 20px; 
}

</style>
</head>
<body>


<!---------------------------------SISA PH SCORING OF SURFING EVENT-------------------------------------->
<div class="table-responsive content">
<table class="table-responsive content"  align="center">
  <thead>
    <tr>
      <td class="stroke2" colspan="7" align="right" style="padding-top: 10px; border-radius: 20px 20px 0px 0px;"><div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    User: <?php $user->get_judge_username($judge_username); ?>
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" href="export_print.php" style="font-size: 14px">Print and Export</a>
    <a class="dropdown-item" href="judge1.php?q=logout" onclick="return confirm('Are you sure do you want to logout?')" style="font-size: 14px">Logout</a>
    <input type="hidden" name="<?php $user->get_judge_status($judge_status); ?>">
  </div>
</div></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="7" align="center"><h4 class="header"><img src="images/<?php $user->get_logo($logo); ?>" class="imglogo"></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="7" align="center"><h4 class="header"><?php $user->get_event_title($event_title); ?></h4></td>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="left" colspan="4" align="left"><p>Judge Name: <u><?php $user->get_judge_name($judge_name); ?></u></p></td>
      <td class="main" colspan="1"></td>
      <td class="right" colspan="2" align="right"><p>Division: <u><?php $user->get_division_name($division); ?></u></p></td>
    </tr>
    <tr>
      <td class="left" colspan="4" align="left"><p>Date: <u><?php $user->get_date($date); ?></u></p></td>
      <td class="main" colspan="1"></td>
      <td class="right" colspan="2" align="right">
   <!---------------- Drown Down Menu Edit Data-------------------------->
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>

            <?php

               $query = "SELECT * FROM judges_data_form ORDER BY form_id = $form ASC";
               $query_run = mysqli_query($con,$query);
            
                
                 while ($row = mysqli_fetch_assoc ($query_run)) {
                $id=$row['form_id'];
                $logo=$row['logo'];
                $header=$row['event_title'];
                $judge=$row['ju_name'];
                $division=$row['at_division'];
                $date=$row['event_date'];
                $stage=$row['at_stage'];
                $heat=$row['at_heat'];
                $color1=$row['at_col_one'];
                $color2=$row['at_col_two'];
                $color3=$row['at_col_three'];
                $color4=$row['at_col_four'];
                $img1=$row['at_img_one'];
                $img2=$row['at_img_two'];
                $img3=$row['at_img_three'];
                $img4=$row['at_img_four'];
                $name1=$row['at_one'];
                $name2=$row['at_two'];
                $name3=$row['at_three'];
                $name4=$row['at_four'];
                $bg=$row['bg_img'];
                 }
              ?>
 
  <div class="dropdownAct">
  <button class="btn btn-secondary btn-xs dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:160px">
   Change form data
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#logo" data-target="#logo<?php echo $id;?>">Header logo</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#header-title" data-target="#header-title<?php echo $id;?>">Header title</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#judge" data-target="#judge<?php echo $id;?>">Judge name</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#date" data-target="#date<?php echo $id;?>">Date</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#division" data-target="#division<?php echo $id;?>">Division</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#stage" data-target="#stage<?php echo $id;?>">Stage</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#heat" data-target="#heat<?php echo $id;?>">Heat</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#colors" data-target="#colors<?php echo $id;?>">Jersey colors</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#images" data-target="#images<?php echo $id;?>">Athlete images</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#names" data-target="#names<?php echo $id;?>">Athlete names</a>
  <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#bg-img" data-target="#bg-img<?php echo $id;?>">Background image</a>
  </div>
</div>


<!-- Modal Edit Logo Image of the page-->
<div class="modal fade" id="logo<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Header Logo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="" enctype="multipart/form-data">
  <div class="form-group">
    <input type="file" class="form-control" name="j1logo1" value="<?php echo $logo;?>" aria-describedby="logo" required>
    <small id="logoHelp" class="form-text text-muted">Choose the logo image do you want.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="logo" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Header Title -->
<div class="modal fade" id="header-title<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Event Title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post">
  <div class="form-group">
    <input type="text" class="form-control" name="j1header1" value="<?php echo $header;?>" aria-describedby="header title" required>
    <small id="headerHelp" class="form-text text-muted">Write the title do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="event_title" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Judge-->
<div class="modal fade" id="judge<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change Judge Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1name1" value="<?php echo $judge;?>" aria-describedby="judge name" required>
    <small id="judgeHelp" class="form-text text-muted">Write the judge name do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="judge_name" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Date-->
<div class="modal fade" id="date<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Date</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1date1" value="<?php echo $date; ?>" aria-describedby="Date and Time" required>
    <small id="datetimeHelp" class="form-text text-muted">Write the date, time do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="date_time" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Division-->
<div class="modal fade" id="division<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Division</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1div1" value="<?php echo $division; ?>" aria-describedby="division name" required>
    <small id="divisionHelp" class="form-text text-muted">Write the division do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="at_division" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Stage-->
<div class="modal fade" id="stage<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Stage</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1st1" value="<?php echo $stage; ?>" aria-describedby="stage name" required>
    <small id="stageHelp" class="form-text text-muted">Write the stage name do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="at_stage" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Heat-->
<div class="modal fade" id="heat<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Heat</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1ht1" value="<?php echo $heat; ?>" aria-describedby="heat name" required>
    <small id="stageHelp" class="form-text text-muted">Write the stage name do you want and don't forget to save it.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="at_heat" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Colors-->
<div class="modal fade" id="colors<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Jersey Colors</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1col1" value="<?php echo $color1; ?>" aria-describedby="color1" required>
    <small id="colorHelp" class="form-text text-muted">Type the jersey color do you want of athlete one. Example: red or blue.</small>
    <input type="text" class="form-control" name="j1col2" value="<?php echo $color2; ?>" aria-describedby="color2" required>
    <small id="colorHelp" class="form-text text-muted">Type the jersey color do you want of athlete two. Example: red or blue.</small>
    <input type="text" class="form-control" name="j1col3" value="<?php echo $color3; ?>" aria-describedby="color3" required>
    <small id="colorHelp" class="form-text text-muted">Type the jersey color do you want of athlete three. Example: red or blue.</small>
    <input type="text" class="form-control" name="j1col4" value="<?php echo $color4; ?>" aria-describedby="color4" required>
    <small id="colorHelp" class="form-text text-muted">Type the jersey color do you want of athlete four. Example: red or blue.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="jersey_colors" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>


<!-- Modal Edit Athletes Images-->
<div class="modal fade" id="images<?php  echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Athlete Images</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" enctype="multipart/form-data">
  <div class="form-group">
    <input type="file" class="form-control" name="j1img1" value="<?php echo $img1; ?>" aria-describedby="image1" required>
    <small id="imageHelp" class="form-text text-muted">Choose the image of athlete one.</small>
    <input type="file" class="form-control" name="j1img2" value="<?php echo $img2; ?>" aria-describedby="image2" required>
    <small id="imageHelp" class="form-text text-muted">Choose the image of athlete two.</small>
    <input type="file" class="form-control" name="j1img3" value="<?php echo $img3; ?>" aria-describedby="image3" required>
    <small id="imageHelp" class="form-text text-muted">Choose the image of athlete three.</small>
    <input type="file" class="form-control" name="j1img4" value="<?php echo $img4; ?>" aria-describedby="image4" required>
    <small id="imageHelp" class="form-text text-muted">Choose the image of athlete four.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="at_images" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Athlete Names-->
<div class="modal fade" id="names<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Athlete Names</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="j1n1" value="<?php echo $name1; ?>" aria-describedby="athlete name1" required>
    <small id="nameHelp" class="form-text text-muted">Write the name do you want of athlete number one.</small>
    <input type="text" class="form-control" name="j1n2" value="<?php echo $name2; ?>" aria-describedby="athlete name2" required>
    <small id="nameHelp" class="form-text text-muted">Write the name do you want of athlete number two.</small>
    <input type="text" class="form-control" name="j1n3" value="<?php echo $name3; ?>" aria-describedby="athlete name3" required>
    <small id="nameHelp" class="form-text text-muted">Write the name do you want of athlete number three.</small>
    <input type="text" class="form-control" name="j1n4" value="<?php echo $name4; ?>" aria-describedby="athlete name4" required>
    <small id="nameHelp" class="form-text text-muted">Write the name do you want of athlete number four.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="at_names" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Background Image of the page-->
<div class="modal fade" id="bg-img<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change the Background Image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?form_id='.$id; ?>" method="post" name="" enctype="multipart/form-data">
  <div class="form-group">
    <input type="file" class="form-control" name="bg1" value="<?php echo $bg; ?>" aria-describedby="bgimg" required>
    <small id="bgimageHelp" class="form-text text-muted">Choose the background image do you want.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="bg_img" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>

</td>
    </tr>

</td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="7" align="center"><h5 class="header"><u><?php $user->get_stage_name($at_stage); ?></u></h5></td>
    </tr>
        <tr class="tr">
      <td class="stroke1" colspan="7" align="center"><h5 class="header"><u><?php $user->get_heat_name($at_heat); ?></u></h5></td>
    </tr>
    <tr class="tr">
      <td  class="stroke1" colspan="1"><img src="images/<?php $user->get_img_one($img_one);?>" class="img1"></td>
      <td  class="stroke1" colspan="2"><img src="images/<?php $user->get_img_two($img_two);?>" class="img2"></td>
      <td  class="stroke1" colspan="2"><img src="images/<?php $user->get_img_three($img_three);?>" class="img3"></td>
      <td  class="stroke1" colspan="2"><img src="images/<?php $user->get_img_four($img_four);?>" class="img4"></td>
    </tr>
    <tr class="tr">
      <th class="stroke2" colspan="1"><?php $user->get_at_one($name_one);?></th>
      <th class="stroke2" colspan="2"><?php $user->get_at_two($name_two);?></th>
      <th class="stroke2" colspan="2"><?php $user->get_at_three($name_three);?></th>
      <th class="stroke2" colspan="2"><?php $user->get_at_four($name_four);?></th>
    </tr>
     <?php
  
      $qry_j1 = "SELECT * FROM judges_data_form WHERE form_id = $form";
      $qry_run_j1 = mysqli_query($con,$qry_j1);

      
      while ($num = mysqli_fetch_assoc ($qry_run_j1)) {
            $at1 = $num['at_one'];
            $at2 = $num['at_two'];
            $at3 = $num['at_three'];
            $at4 = $num['at_four'];

            $p1 = $num['at_img_one'];
            $p2 = $num['at_img_two'];
            $p3 = $num['at_img_three'];
            $p4 = $num['at_img_four'];
            
            $co1 = $num['at_col_one'];
            $co2 = $num['at_col_two'];
            $co3 = $num['at_col_three'];
            $co4 = $num['at_col_four'];

            $n1 = $num['at_one'];
            $n2 = $num['at_two'];
            $n3 = $num['at_three'];
            $n4 = $num['at_four'];

            $d1 = $num['at_division'];
            $st1 = $num['at_stage'];
            $heat1 = $num['at_heat'];
            $ti1 = $num['event_title'];
            $judge1 = $num['ju_name'];
            } 


      $query_j1 = "SELECT * FROM judge_three";
      $query_run_j1 = mysqli_query($con,$query_j1);

      $wc= 0;
      $qty1= 0;
      $qty2= 0;
      $qty3= 0;
      $qty4= 0;
      
      while ($num = mysqli_fetch_assoc ($query_run_j1)) {
            $wc = $num['wavec'];
            $qty1 += $num['at1'];
            $qty2 += $num['at2'];
            $qty3 += $num['at3'];
            $qty4 += $num['at4'];

          
            } 
    ?>
<?php 
include("event_scores.php");
    $tol_at1 = number_format($j1,1)+number_format($j5,1)+number_format($j9,1)+number_format($j13,1)+number_format($j17,1);
    $tol_at2 = number_format($j2,1)+number_format($j6,1)+number_format($j10,1)+number_format($j14,1)+number_format($j18,1);
    $tol_at3 = number_format($j3,1)+number_format($j7,1)+number_format($j11,1)+number_format($j15,1)+number_format($j19,1);
    $tol_at4 = number_format($j4,1)+number_format($j8,1)+number_format($j12,1)+number_format($j16,1)+number_format($j20,1);
?>
    <form action="" method="post" name="">
    <tr class="tr">
      <td  class="stroke2" colspan="1"><input type="text" name="at_one" value="0"></td>
      <td  class="stroke2" colspan="2"><input type="text" name="at_two" value="0"></td>
      <td  class="stroke2" colspan="2"><input type="text" name="at_three" value="0"></td>
      <td class="stroke2" colspan="2"><input type="text" name="at_four" value="0"></td>
    </tr>
      <tr class="tr">
      <td  class="stroke2" colspan="1"><input type="hidden" name="reset_at1" value="0"></td>
      <td  class="stroke2" colspan="2"><input type="hidden" name="reset_at2" value="0"></td>
      <td  class="stroke2" colspan="2"><input type="hidden" name="reset_at3" value="0"></td>
      <td class="stroke2" colspan="2"><input type="hidden" name="reset_at4" value="0"></td>
    </tr> 
    <tr>
      <td><input type="hidden" name="dm_wave" value="<?php echo $wc+1; ?>"></td>
      <td><input type="hidden" name="dm_ju_n" value="<?php echo $judge1; ?>"></td>
      <td><input type="hidden" name="wavec" value="<?php echo $wc+1; ?>"></td>
      <td><input type="hidden" name="n1" value="<?php echo $n1; ?>"></td>
      <td><input type="hidden" name="n2" value="<?php echo $n2; ?>"></td>
      <td><input type="hidden" name="n3" value="<?php echo $n3; ?>"></td>
      <td><input type="hidden" name="n4" value="<?php echo $n4; ?>"></td>
    </tr>
    <tr> 
      <td><input type="hidden" name="co1" value="<?php echo $co1; ?>"></td>
      <td><input type="hidden" name="co2" value="<?php echo $co2; ?>"></td>
      <td><input type="hidden" name="co3" value="<?php echo $co3; ?>"></td>
      <td><input type="hidden" name="co4" value="<?php echo $co4; ?>"></td>
    </tr>
    <tr>
      <td><input type="hidden" name="tol_at1" value="<?php echo $tol_at1; ?>"></td>
      <td><input type="hidden" name="tol_at2" value="<?php echo $tol_at2; ?>"></td>
      <td><input type="hidden" name="tol_at3" value="<?php echo $tol_at3; ?>"></td>
      <td><input type="hidden" name="tol_at4" value="<?php echo $tol_at4; ?>"></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="7" style="padding: 2px;"></td>
    </tr>
    <tr class="tr">
        <td class="stroke1" colspan="3"><button type="submit" name="at_sbmone" class="btn btn-success">Submit Scores</button></td>
      <td class="stroke1" colspan="3"><button type="submit" name="at_sbmtwo" class="btn btn-warning" onclick="return confirm('Are you sure do you want to reset the data?')">Reset Data</button></td>
      <td class="stroke1"></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="7" style="padding: 15px;"></td>
    </tr>
</form>
     <tr class="tr">
      <td class="stroke1" colspan="5" align="center"><h5 class="header"><u><?php $user->get_stage_name($at_stage); ?> Scores</u></h5></td>
      <td class="stroke1" colspan="2" align="center">
<!-- Data Monitoring -->
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#monitoring">
  Data Monitoring
</button></td>
    </tr>



    <!-- Modal of Data Monitoring -->
<div class="modal fade" id="monitoring" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Data Monitoring</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <?php
  
      $query_dm = "SELECT * FROM data_monitoring ORDER BY dm_id DESC";
      $query_run_dm = mysqli_query($con,$query_dm);

      $dm1= 0;
      $dm2= 0;
      $dm3= 0;
      $dm4= 0;
      
      while ($dm_row = mysqli_fetch_assoc ($query_run_dm)) {
            $dm_ju = $dm_row['judge_names'];
            $dm_act = $dm_row['actions'];
            $wave = $dm_row['dm_wave'];
            $dm_at1 = $dm_row['dm_at1'];
            $dm_at2 = $dm_row['dm_at2'];
            $dm_at3 = $dm_row['dm_at3'];
            $dm_at4 = $dm_row['dm_at4'];
            $dm1 = $dm_row['score1'];
            $dm2 = $dm_row['score2'];
            $dm3 = $dm_row['score3'];
            $dm4 = $dm_row['score4'];
            $dm_time = $dm_row['cur_time'];
            
           echo "<p>"."<strong>".$dm_time."</strong>"."<br>"."<u>".$dm_ju."</u>"."  ".$dm_act."<br>"."  "."<font style='color:green;'><strong>".$dm_at1." ".":"." ".$dm1.", <br>".$dm_at2." ".":"." ".$dm2.", <br>".$dm_at3." ".":"." ".$dm3.", <br>".$dm_at4." ".":"." ".$dm4."<br></strong></font>"." on"." "."<u>"."wave"." ".$wave."</u>."."</p>";  
           
            } 
    ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
     

     <!-- Scores inputted by the judge output codes -->

    <tr class="tr">
      <th class="stroke2">Wave #</th>
      <th class="stroke2"><?php $user->get_at_one($name_one);?></th>
      <th class="stroke2"><?php $user->get_at_two($name_two);?></th>
      <th class="stroke2"><?php $user->get_at_three($name_three);?></th>
      <th class="stroke2"><?php $user->get_at_four($name_four);?></th>
      <th class="stroke2"></th>
      <th class="stroke2"></th>
      </th> 
    </tr>


               <?php
          
               if(isset($_POST['delete'])){
                 $del_id = $_POST['delete_id'];
                 $del_query = "DELETE FROM judge_three WHERE jsb_id ='$del_id' ORDER BY jsb_id";
                 $del_query_run = mysqli_query($con,$del_query);
                
                 date_default_timezone_set('Asia/Manila');
                 $todays_date = date("M. d, Y, h:i:s a");
                 $dm_act = "was deleted his/her scores";
                 $dm_ju_n = $_POST['dm_ju_n'];
                 $dm_wave = $_POST['dm_wave'];
                 $n1 = $_POST['n1'];
                 $n2 = $_POST['n2'];
                 $n3 = $_POST['n3'];
                 $n4 = $_POST['n4'];
                 $s1 = $_POST['s1'];
                 $s2 = $_POST['s2'];
                 $s3 = $_POST['s3'];
                 $s4 = $_POST['s4'];

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $del_query_dm = mysqli_query($con,$query5);

                ?>
                <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
               <script>
      swal({
  title: "The scores have been deleted successfully.",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
         });
    window.location='/sisaph-judging/judge3.php'</script>

              <?php   
               } 

               $query = "SELECT * FROM judge_three ORDER BY jsb_id ASC";
               $del_query_run = mysqli_query($con,$query);

                
                 while ($row = mysqli_fetch_assoc ($del_query_run)) {
                $id=$row['jsb_id'];
                $wc = $row['wavec'];
                $n1=$row['at_n1'];
                $n2=$row['at_n2'];
                $n3=$row['at_n3'];
                $n4=$row['at_n4'];
                $s1=$row['at1'];
                $s2=$row['at2'];
                $s3=$row['at3'];
                $s4=$row['at4'];
                ?>
 
                
    <tr class="tr">
      <form method="post">
      <input type="hidden" name="dm_ju_n" value="<?php echo $judge1; ?>">  
      <input type="hidden" name="dm_wave" value="<?php echo $wc; ?>">
      <input type="hidden" name="n1" value="<?php echo $n1; ?>">
      <input type="hidden" name="n2" value="<?php echo $n2; ?>">
      <input type="hidden" name="n3" value="<?php echo $n3; ?>">
      <input type="hidden" name="n4" value="<?php echo $n4; ?>">
      <input type="hidden" name="s1" value="<?php echo $s1; ?>">
      <input type="hidden" name="s2" value="<?php echo $s2; ?>">
      <input type="hidden" name="s3" value="<?php echo $s3; ?>">
      <input type="hidden" name="s4" value="<?php echo $s4; ?>">
       
      <td class="stroke2"><?php echo $row['wavec']; ?></td>
      <td class="stroke2"><?php echo number_format($row['at1'],2); ?></td>
      <td class="stroke2"><?php echo number_format($row['at2'],2); ?></td>
      <td class="stroke2"><?php echo number_format($row['at3'],2); ?></td>
      <td class="stroke2"><?php echo number_format($row['at4'],2); ?></td>
      <td class="stroke2">
      <input type="hidden" name="delete_id" value="<?php echo $row['jsb_id']; ?>">  
      <input type="submit" class="btn btn-danger" name="delete" value="Delete" onclick="return confirm('Are you sure do you want to delete scores?')">
    </form>
      </td>
       <!-- Button trigger modal Edit Scores-->
      <td class="stroke2">
      <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#scores<?php echo $id;?>">
       Edit
    </button>
    </td>
    </tr>

            <!-- Modal Edit Scores-->
<div class="modal fade" id="scores<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Scores</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="<?php echo '?jsb_id='.$id; ?>" method="post" name="">
  <div class="form-group">
      <input type="hidden" name="dm_wave" value="<?php echo $wc; ?>">
      <input type="hidden" name="dm_ju_n" value="<?php echo $judge1; ?>">
      <input type="hidden" name="n1" value="<?php echo $n1; ?>">
      <input type="hidden" name="n2" value="<?php echo $n2; ?>">
      <input type="hidden" name="n3" value="<?php echo $n3; ?>">
      <input type="hidden" name="n4" value="<?php echo $n4; ?>">
    <input type="text" class="form-control" name="s1" value="<?php echo $s1; ?>" aria-describedby="athlete name1" required>
    <small id="nameHelp" class="form-text text-muted">Write the score do you want.</small>
    <input type="text" class="form-control" name="s2" value="<?php echo $s2; ?>" aria-describedby="athlete name2" required>
    <small id="nameHelp" class="form-text text-muted">Write the score do you want.</small>
    <input type="text" class="form-control" name="s3" value="<?php echo $s3; ?>" aria-describedby="athlete name3" required>
    <small id="nameHelp" class="form-text text-muted">Write the score do you want.</small>
    <input type="text" class="form-control" name="s4" value="<?php echo $s4; ?>" aria-describedby="athlete name4" required>
    <small id="nameHelp" class="form-text text-muted">Write the score do you want.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="judge_edit_scores" class="btn btn-success">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div> 
    <?php }  ?>


    <form action="" method="post">
    <tr class="result">
      <td class="stroke2">Total Scores :</td>
      <td class="stroke2">
        <?php echo number_format($qty1,2); ?>
        <input type="hidden" name="dm_ju_n" value="<?php echo $judge1; ?>">
        <input type="hidden" name="ti1" value="<?php echo $ti1; ?>">
        <input type="hidden" name="p1" value="<?php echo $p1; ?>">
        <input type="hidden" name="t1" value="<?php echo $qty1; ?>">
        <input type="hidden" name="n1" value="<?php echo $n1; ?>">
        <input type="hidden" name="d1" value="<?php echo $d1; ?>">
      </td>
      <td class="stroke2">
        <?php echo number_format($qty2,2); ?>
        <input type="hidden" name="p2" value="<?php echo $p2; ?>">
        <input type="hidden" name="t2" value="<?php echo $qty2; ?>">
        <input type="hidden" name="n2" value="<?php echo $n2; ?>">
        <input type="hidden" name="st1" value="<?php echo $st1; ?>">
        <input type="hidden" name="ht1" value="<?php echo $heat1; ?>">
      </td>
      <td class="stroke2">
        <?php echo number_format($qty3,2); ?>
        <input type="hidden" name="p3" value="<?php echo $p3; ?>">
        <input type="hidden" name="t3" value="<?php echo $qty3; ?>">
        <input type="hidden" name="n3" value="<?php echo $n3; ?>">
      </td>
      <td class="stroke2">
        <?php echo number_format($qty4,2); ?>
        <input type="hidden" name="p4" value="<?php echo $p4; ?>">
        <input type="hidden" name="t4" value="<?php echo $qty4; ?>">
        <input type="hidden" name="n4" value="<?php echo $n4; ?>">
      </td>
      <td class="stroke2"></td>
      <td class="stroke2"><button type="submit" name="final_scores" class="btn btn-success" onclick="return confirm('Are you sure do you want to save scores?')">Save Scores</button>
      </td>
    </tr>
     </form>

    <tr class="tr">
      <td class="stroke1" colspan="7" style="padding: 15px;"></td>
    </tr>
    <tr>
      <td colspan="7" class="developer"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="7" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"></td>
    </tr>
  </tbody>
</table>
</div>
</div>
     
     <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- load jQuery 1.10.2 -->
     <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
     <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

<?php
    //---------------Submit Button Two-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['at_sbmtwo'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$sendone = $user->reset_scores_j3($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4);
if ($sendone) {
  // Sending score Success
  ?>

               <script>
      swal({
  title: "Resetting data successfully!!!",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
         });
    window.location='/sisaph-judging/judge3.php'</script>
    
    <?php
} else {
            // Sending score Failed
  echo '<script>alert("Resetting scores failed")</script>';
  header("location:judge3.php");
}
}
?>

<?php 
    if (isset($_POST['final_scores'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$final = $user->reg_final_scores($dm_ju_n,$ti1,$p1,$p2,$p3,$p4,$d1,$st1,$ht1,$n1,$n2,$n3,$n4,$t1,$t2,$t3,$t4);
if ($final) {
  // Saving scores success
  ?>
 <!-------------SWAL FOR SAVING FINAL SCORES END OF SET------------------> 
    <script>
      swal({
  title: "The scores has save successfully!!!",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
         });
    window.location='/sisaph-judging/judge3.php'</script>

<?php }else {
            // Saving scores failed
  ?>

   <script>
      swal({
  title: "Not a valid scores.",
  //text: "You clicked the button!",
  icon: "error",
  button: "ok",
         });
    </script>

<?php
} 

} ?>


<?php 
 //---------------Submit Button One---------------///
if (isset($_POST['at_sbmone'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$sendone = $user->reg_judge3_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$n1,$n2,$n3,$n4);
if ($sendone) {
            // Sending score Success
  ?>
<!-------------SWAL FOR SENDING SCORES OR SAVING------------------>  
    <script>
swal({
   title: "Sending scores successfully!!!",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
    });
  window.location='/sisaph-judging/judge3.php'</script>

<?php
     } else {
            // Sending score Failed
  ?>
     <script>
      swal({
  title: "Not a valid scores.",
  //text: "You clicked the button!",
  icon: "error",
  button: "ok",
         });
    </script>
<?php
}
}
?>
<?php
//---------------Submit judge_edit_scores-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['judge_edit_scores'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_judge_one = $user->edit_scores_j3($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4);
if ($edit_judge_one) {
            // Saving scores success
           ?> 
<!-------------SWAL FOR UPDATE------------------>
        <script>
      swal({
  title: "The scores has change successfully!!!",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
         });
     window.location='/sisaph-judging/judge3.php'</script>

  <?php  
} else {
  // Saving scores failed
  ?>

      <script>
      swal({
  title: "Not a valid scores.",
  //text: "You clicked the button!",
  icon: "error",
  button: "ok",
         });
    </script>

<?php 
}
}
?>

  </body>
</html>