<?php 
ob_start();
session_start();
require_once("include/crud.php");
require_once ("include/class.judge.php"); // class of functions of User.
require_once("include/con-total-og.php");
require_once("include/database-con.php");
$user = new judge();
$crud = new crud();

//user status and username session
$judge_username = $_SESSION['ju_name'];
$judge_status = $_SESSION['ju_name'];

      
      $query_all = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $query_run_all = mysqli_query($con,$query_all);


      while ($res = mysqli_fetch_assoc ($query_run_all)) {

            $co1a = $res['at_col_one'];
            $co2a = $res['at_col_two'];
            $co3a = $res['at_col_three'];
            $co4a = $res['at_col_four'];

            $logo1a = $res['logo'];
            $bg_img1a = $res['bg_img'];
            $event_titale1a = $res['event_title'];
            $heat = $res['at_heat'];
            }


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:index.php");
}else{
  
  $sql = "UPDATE judges_account SET ju_status = 'Online' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:index.php");
  
  $sql = "UPDATE judges_account SET ju_status = 'Offline' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
  session_destroy();
  session_unset();
}


   //---------------Submit Button EVENT DATA-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['add_event'])){  // $_POST['add_event'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$og = $user->reg_og($date,$div1,$st1,$ht1,$og_jc1,$og_jc2,$og_jc3,$og_jc4,$og_at1,$og_at2,$og_at3,$og_at4);
if ($og) {
  // Sending score Success
  echo "<script>alert('Adding data successfully!!!'); window.location='/sisaph-judging/organize-event04.php'</script>";

} else {
            // Sending score Failed
  echo "<script>alert('Adding data failed.'); window.location='/sisaph-judging/organize-event04.php'</script>";
}
}



if(isset($_POST['delete_data'])){
$user = "root"; 
$password = ""; 
$host = "localhost:3308"; 
$database= "admin_cms";

$connection= mysqli_connect ($host, $user, $password, $database);
if (!$connection)
{
die ('Could not connect:' . mysqli_error());
}


$truncatetable= mysqli_query($connection,"TRUNCATE TABLE organize_event");


if($truncatetable !== FALSE)
{

echo "<script>alert('All data have been deleted.'); window.location='/sisaph-judging/organize-event04.php'</script>";
  
}
else
{
 
   echo "<script>alert('No data have been deleted.'); window.location='/sisaph-judging/organize-event04.php'</script>";
}

}



//---------------Submit edit upnext-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['update_og'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_upnext = $user->edit_og($date,$div1,$st1,$ht1,$og_jc1,$og_jc2,$og_jc3,$og_jc4,$og_at1,$og_at2,$og_at3,$og_at4);
if ($edit_upnext) {
            // update success
  echo "<script>alert('The data has change successfully!!!'); window.location='/sisaph-judging/organize-event04.php'</script>";
 
} else {
  // Update failed
  echo "<script>alert('Not a valid data.'); window.location='/sisaph-judging/organize-event04.php'</script>";

}
}

//---------------Submit edit link data-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['update_link'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$update_d= $user->update_link($li_div1,$li_div2,$li_div3,$li_div4,$li_div5);
if ($update_d) {
            // update success
  echo "<script>alert('The division name has change successfully!!!'); window.location='/sisaph-judging/organize-event04.php'</script>";
 
} else {
  // Update failed
  echo "<script>alert('Not a valid name.'); window.location='/sisaph-judging/organize-event04.php'</script>";

}
}

ob_end_flush();
?>

<!--------------------------------- judge-page.php--------------------------------------->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="description" content="Judging of Surfing Competition in Siargao Island, Philippines">
  <meta name="author" content="Siargao Web Protocol">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/<?php echo $logo1a; ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/upnext.css">
    <title>SISA PH Organize Event</title>
<style>
body {
  background-image: url("images/<?php echo $bg_img1a; ?>");
}  
</style>
</head>
<body>


<!---------------------------------SISA PH SCORING OF SURFING EVENT-------------------------------------->
<div class="table-responsive content">
<table class="table-responsive content"  align="center">
  <thead>
    <tr>
      <td class="stroke2" colspan="5" align="right" style="padding-top: 10px; border-radius: 20px 20px 0px 0px;">
        <div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    User: <?php $user->get_judge_username($judge_username); ?>
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" style="font-size: 14px" href="upnext.php">Up Next Data</a>
    <a class="dropdown-item" href="export_print.php" style="font-size: 14px">Print and Export</a>
    <a class="dropdown-item" style="font-size: 14px" href="head-judge.php">Back</a>
    <a class="dropdown-item" href="head-judge.php?q=logout" onclick="return confirm('Are you sure do you want to log out?')" style="font-size: 14px">Logout</a>
    <input type="hidden" name="<?php $user->get_judge_status($judge_status); ?>">
  </div>
  </div>


    </td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h4 class="header"><img src="images/<?php echo $logo1a; ?>" class="imglogo"></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h4 class="header"><?php echo $event_titale1a; ?></h4></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h5 class="header"><u>Event Organizer</u></h5></td>
    </tr>
   
    <tr>
      <form method="post">
       <th class="stroke2" colspan="1" style="text-align:left;">
              <?php
              $tol = $total4[0];
              ?>
              TOD: <strong style="color:blue;"><?php echo $tol; ?></strong>
             <?php
              mysqli_close($con);
              ?>
        </th> 
      <th class="stroke2" colspan="1" style="text-align: right;"><a class="btn btn-primary" data-toggle="modal" style="font-size: 14px" href="#update_link" data-target="#update_link">Update Division</a></th>  
      <th class="stroke2" colspan="2" style="text-align: right;"><input type="submit" class="btn btn-danger" style="font-size: 14px" name="delete_data" value="Delete All Data" onclick="return confirm('Are you sure do you want to delete all data?')"></th>
      </form>
     <th class="stroke2" colspan="1" style="text-align: right;"> 
    <div class="dropdown">
  <a class="btn btn-info dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Organize Now</a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
    <a class="dropdown-item" data-toggle="modal" style="font-size: 14px" href="#ced" data-target="#ced">Create Event Data</a>
  </div>
  </div>
   </th>
    </tr>


  <!-- Modal Create Event Data-->
<div class="modal fade" id="ced" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Create Event Data</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  <form action="" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="date" required>
    <small class="form-text text-muted">Type the date do you want. Example: Oct. 23, 2020</small>
     <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query_all = "SELECT * FROM data_link WHERE link_id = 1";
      $query_run_all = mysqli_query($con,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
     <select type="text" name="div1" class="form-control" required>        
     <option  value="">--Select One--</option>
     <option type="text" value="<?php echo $link_div1; ?>"><?php echo $link_div1; ?></option>
     <option type="text" value="<?php echo $link_div2; ?>"><?php echo $link_div2; ?></option>
     <option type="text" value="<?php echo $link_div3; ?>"><?php echo $link_div3; ?></option>
     <option type="text" value="<?php echo $link_div4; ?>"><?php echo $link_div4; ?></option>
     <option type="text" value="<?php echo $link_div5; ?>"><?php echo $link_div5; ?></option>
     </select>       
  
    <small class="form-text text-muted">Type the division do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="st1" required>
    <small class="form-text text-muted">Type the stage do you want. Example: Quarterfinals.</small>
    <input type="text" class="form-control" name="ht1"  required>
    <small class="form-text text-muted">Type the heat do you want. Example: Heat 1.</small>

    <input type="text" class="form-control" name="og_jc1"  required>
    <small class="form-text text-muted">Type the color for athlete number one. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc2"  required>
    <small class="form-text text-muted">Type the color for athlete number two. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc3"  required>
    <small class="form-text text-muted">Type the color for athlete number three. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc4"  required>
    <small class="form-text text-muted">Type the color for athlete number four. Example: red or blue.</small>

    <input type="text" class="form-control" name="og_at1" required>
    <small class="form-text text-muted">Type the athlete name one do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control"  name="og_at2" required>
    <small class="form-text text-muted">Type the athlete name two do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control"  name="og_at3" required>
    <small class="form-text text-muted">Type the athlete name three do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control"  name="og_at4" required>
    <small class="form-text text-muted">Type the athlete name four do you want. Example: Mike Albarado.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="add_event" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

    <tr>
      <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      
      $query_all = "SELECT * FROM data_link";
      $query_run_all = mysqli_query($con,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }

       ?>
      <th class="stroke2" style="text-align: left;"><a class="btn btn-outline-secondary" style="font-size: 14px" href="organize-event01.php"><?php echo $link_div1; ?></a></th>
      <th class="stroke2" style="text-align: left;"><a class="btn btn-outline-secondary" style="font-size: 14px" href="organize-event02.php"><?php echo $link_div2; ?></a></th>
      <th class="stroke2" style="text-align: left;"><a class="btn btn-outline-secondary" style="font-size: 14px" href="organize-event03.php"><?php echo $link_div3; ?></a></th>
      <th class="stroke2" style="text-align: left;"><a class="btn btn-outline-secondary" style="font-size: 14px" href="organize-event04.php"><?php echo $link_div4; ?></a></th>
      <th class="stroke2" style="text-align: left;"><a class="btn btn-outline-secondary" style="font-size: 14px" href="organize-event05"><?php echo $link_div5; ?></a></th>
    </tr>

     <!-- Modal Update link Data-->
<div class="modal fade" id="update_link" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Division Name</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  <form action="<?php echo '?link_id='.$id; ?>" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="li_div1" value="<?php echo $link_div1; ?>" required>
    <small class="form-text text-muted">Type the division name do you want. Example: Men's Open.</small>  
    <input type="text" class="form-control" name="li_div2" value="<?php echo $link_div2; ?>" required>
    <small class="form-text text-muted">Type the division name do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="li_div3" value="<?php echo $link_div3; ?>"  required>
    <small class="form-text text-muted">Type the division name do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="li_div4" value="<?php echo $link_div4; ?>" required>
    <small class="form-text text-muted">Type the division name do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="li_div5" value="<?php echo $link_div5; ?>" required>
    <small class="form-text text-muted">Type the division name do you want. Example: Men's Open.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="update_link" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

      <tr>
        <!-- data of list of competitors -->
        <?php
            $do = addslashes($link_div4);
            $que1 = "SELECT * FROM organize_event WHERE og_division = '$do'";
            $que_run1 = mysqli_query($con,$que1);

            while ($res1 = mysqli_fetch_assoc($que_run1))
            { 
              $id=$res1['og_id'];
              $date=$res1['og_date'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];
              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];
            ?> 
      <th class="stroke2" colspan="5" style="text-align: left;"><a href="<?php echo $date; ?>.php"><?php echo $date; ?></a></th>
      </tr>

    <tr>
      <th class="stroke2"><?php echo $og_division; ?></th>
      <th class="stroke2"><?php echo $og_stage; ?></th>
      <th class="stroke2"><?php echo $og_heat; ?></th>
      <th class="stroke2"></th>
      <th class="stroke2"></th>
    </tr>
  </thead>

           <tbody>
            <tr>
    <td class="stroke1" style="background-color:<?php echo $og_jc1; ?>"><?php echo $og_at1; ?></td>
    <td class="stroke1" style="background-color:<?php echo $og_jc2; ?>"><?php echo $og_at2; ?></td>
    <td class="stroke1" style="background-color:<?php echo $og_jc3; ?>"><?php echo $og_at3; ?></td>
    <td class="stroke1" style="background-color:<?php echo $og_jc4; ?>"><?php echo $og_at4; ?></td>

    <td class="stroke1"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#og<?php echo $id; ?>" style="font-size: 14px">
       Update Data
    </button>
   </td>

    <!-- Modal of Editing Add Next-->
<div class="modal fade" id="og<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  <form action="<?php echo '?og_id='.$id; ?>" method="post">
    <div class="form-group">
      <input type="text" class="form-control" name="date" value="<?php echo $date; ?>" required>
    <small class="form-text text-muted">Type the date do you want. Example: Oct. 23, 2020</small>
    <select type="text" name="div1" class="form-control" required>        
     <option type="text" value="">--Select One--</option>     
     <option type="text" value="<?php echo $link_div1; ?>"><?php echo $link_div1; ?></option>
     <option type="text" value="<?php echo $link_div2; ?>"><?php echo $link_div2; ?></option>
     <option type="text" value="<?php echo $link_div3; ?>"><?php echo $link_div3; ?></option>
     <option type="text" value="<?php echo $link_div4; ?>"><?php echo $link_div4; ?></option>
     <option type="text" value="<?php echo $link_div5; ?>"><?php echo $link_div5; ?></option>
     </select>
    <small class="form-text text-muted">Type the division do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="st1" value="<?php echo $og_stage; ?>" required>
    <small class="form-text text-muted">Type the stage do you want. Example: Quarterfinals.</small>
    <input type="text" class="form-control" name="ht1" value="<?php echo $og_heat; ?>"  required>
    <small class="form-text text-muted">Type the heat do you want. Example: Heat 1.</small>

    <input type="text" class="form-control" name="og_jc1" value="<?php echo $og_jc1; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number one. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc2" value="<?php echo $og_jc2; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number two. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc3" value="<?php echo $og_jc3; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number three. Example: red or blue.</small>
    <input type="text" class="form-control" name="og_jc4" value="<?php echo $og_jc4; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number four. Example: red or blue.</small>

    <input type="text" class="form-control" style="color:black; background-color:<?php echo $og_jc1; ?>" name="og_at1" value="<?php echo $og_at1; ?>" required>
    <small class="form-text text-muted">Type the athlete name one do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $og_jc2; ?>" name="og_at2" value="<?php echo $og_at2; ?>" required>
    <small class="form-text text-muted">Type the athlete name two do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $og_jc3; ?>" name="og_at3" value="<?php echo $og_at3; ?>" required>
    <small class="form-text text-muted">Type the athlete name three do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $og_jc4; ?>" name="og_at4" value="<?php echo $og_at4; ?>" required>
    <small class="form-text text-muted">Type the athlete name four do you want. Example: Mike Albarado.</small>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="update_og" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

</tr>

  <?php } ?>

    <tr class="tr">
      <td class="stroke1" colspan="5" style="padding: 15px;"></td>
    </tr>
    <tr>
      <td colspan="5" class="developer"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="5" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"></td>
    </tr>
  </tbody>
</table>
</div>
</div>
     
    <!-- load jQuery 1.10.2 -->
     <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
     <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!-- Refresh page and send data at one time -->
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

  </body>
</html>