<?php 
ob_start();
session_start();
require_once("include/crud.php");
require_once ("include/class.judge.php"); // class of functions of User.
require_once("include/database-con.php");
$user = new judge();
$crud = new crud();

//user status and username session
$judge_username = $_SESSION['ju_name'];
$judge_status = $_SESSION['ju_name'];

      $query_all = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $query_run_all = mysqli_query($con,$query_all);


      while ($res = mysqli_fetch_assoc ($query_run_all)) {

            $co1a = $res['at_col_one'];
            $co2a = $res['at_col_two'];
            $co3a = $res['at_col_three'];
            $co4a = $res['at_col_four'];

            $logo1a = $res['logo'];
            $bg_img1a = $res['bg_img'];
            $event_titale1a = $res['event_title'];
            $heat = $res['at_heat'];
            }


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:index.php");
}else{
  $sql = "UPDATE judges_account SET ju_status = 'Online' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:index.php");
  $sql = "UPDATE judges_account SET ju_status = 'Offline' WHERE judge_id = '$judge_status'";
  mysqli_query($con,$sql);
  session_destroy();
  session_unset();
}



//---------------Submit Reset Data-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['reset_data'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_upnext = $user->reset_upnext($div1);
if ($edit_upnext) {
            // Saving scores success
  echo "<script>alert('The data have been reset successfully!!!'); window.location='/sisaph-judging/upnext.php'</script>";
 
} else {
  // Saving scores failed
  echo "<script>alert('Not a valid data.'); window.location='/sisaph-judging/upnext.php'</script>";

}
}

//---------------Submit update upnext-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------///

if (isset($_POST['update_upnext'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$edit_upnext = $user->edit_upnext($div1,$st1,$ht1,$un_jc1,$un_jc2,$un_jc3,$un_jc4,$un_at1,$un_at2,$un_at3,$un_at4);
if ($edit_upnext) {
            // Saving scores success
  echo "<script>alert('The data has change successfully!!!'); window.location='/sisaph-judging/upnext.php'</script>";
 
} else {
  // Saving scores failed
  echo "<script>alert('Not a valid data.'); window.location='/sisaph-judging/upnext.php'</script>";

}
}

ob_end_flush();
?>

<!--------------------------------- judge-page.php--------------------------------------->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="description" content="Judging of Surfing Competition in Siargao Island, Philippines">
  <meta name="author" content="Siargao Web Protocol">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/<?php echo $logo1a; ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/upnext.css">
    <title>SISA PH Up Next</title>
<style>
body {
  background-image: url("images/<?php echo $bg_img1a; ?>");    
}
</style>
</head>
<body>


<!---------------------------------SISA PH SCORING OF SURFING EVENT-------------------------------------->
<div class="table-responsive content">
<table class="table-responsive content"  align="center">
  <thead>
    <tr>
      <td class="stroke2" colspan="5" align="right" style="padding-top: 10px; border-radius: 20px 20px 0px 0px;"><div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    User: <?php $user->get_judge_username($judge_username); ?>
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
  <a class="dropdown-item" style="font-size: 14px" href="organize-event01.php">Organize Event Data</a>
    <a class="dropdown-item" href="export_print.php" style="font-size: 14px">Print and Export</a>
    <a class="dropdown-item" style="font-size: 14px" href="head-judge.php">Back</a>
    <a class="dropdown-item" href="judge1.php?q=logout" onclick="return confirm('Are you sure do you want to logout?')" style="font-size: 14px">Logout</a>
    <input type="hidden" name="<?php $user->get_judge_status($judge_status); ?>">
  </div>
  </div>


  <!-- Modal Organize Surfing of Event-->
<div class="modal fade" id="ose" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Organize Surfing Event</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
  <form action="" method="post" name="">
  <div class="form-group">
    <input type="text" class="form-control" name="div1"  required>
    <small class="form-text text-muted">Type the division do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="st1" required>
    <small class="form-text text-muted">Type the stage do you want. Example: Quarterfinals.</small>
    <input type="text" class="form-control" name="ht1" required>
    <small class="form-text text-muted">Type the heat do you want. Example: Heat 1.</small>
    <input type="text" class="form-control" name="nam1" required>
    <small class="form-text text-muted">Type the athlete name do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" name="jc1" required>
    <small id="colorHelp" class="form-text text-muted">Type the jersey color do you want of athlete four. Example: red or blue.</small>
  </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="ose" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

    </td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h4 class="header"><img src="images/<?php echo $logo1a; ?>" class="imglogo"></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h4 class="header"><?php echo $event_titale1a; ?></h4></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="5" align="center"><h5 class="header"><u>Up Next Data</u></h5></td>
    </tr>

    <tr>
      <th class="stroke2" colspan="5" style="text-align: right;">
           <?php
            $que = "SELECT * FROM upnext";
            $que_run = mysqli_query($con,$que);

            while ($res1 = mysqli_fetch_assoc($que_run))
            { 
              $id=$res1['un_id'];
            }
            ?> 
        <form action="<?php echo '?un_id='.$id; ?>" method="post">
        <input type="hidden" name="div1" value="<i>updating...</i>"> 
        <input type="submit" class="btn btn-danger" name="reset_data" value="Reset Data" onclick="return confirm('Are you sure do you want to reset the data?')" style="font-size: 14px">
        </form>
      </th>
    </tr>

      <tr>
        <?php
            $que1 = "SELECT * FROM upnext";
            $que_run1 = mysqli_query($con,$que1);

            while ($res1 = mysqli_fetch_assoc($que_run1))
            { 
              $date=$res1['un_date'];
            ?> 
      <th class="stroke2" colspan="5" style="text-align: left;"><?php echo $date; ?></th>
    <?php } ?>
      </tr>

    <tr>
      <?php
            $que2 = "SELECT * FROM upnext";
            $que_run2 = mysqli_query($con,$que2);

            while ($res1 = mysqli_fetch_assoc($que_run2))
            { 
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];
            ?> 
      <th class="stroke2"><?php echo $un_division; ?></th>
      <th class="stroke2"><?php echo $un_stage; ?></th>
      <th class="stroke2"><?php echo $un_heat; ?></th>
      <th class="stroke2"></th>
      <th class="stroke2"></th>
    <?php } ?>
    </tr>
  </thead>

           <tbody>
            <tr>
            <!-- data from upnext -->
           <?php   
            $que3 = "SELECT * FROM upnext";
            $que_run3 = mysqli_query($con,$que3);

            while ($res1 = mysqli_fetch_assoc($que_run3))
            { 
              $id=$res1['un_id'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
            ?> 
    <td class="stroke1" style="background-color:<?php echo $un_jc1; ?>"><?php echo $un_at1; ?></td>
    <td class="stroke1" style="background-color:<?php echo $un_jc2; ?>"><?php echo $un_at2; ?></td>
    <td class="stroke1" style="background-color:<?php echo $un_jc3; ?>"><?php echo $un_at3; ?></td>
    <td class="stroke1" style="background-color:<?php echo $un_jc4; ?>"><?php echo $un_at4; ?></td>

    <td class="stroke1"><button type="button" class="btn btn-primary" data-toggle="modal" data-target="#upedit<?php echo $id; ?>" style="font-size: 14px">
       Update Data
    </button>
   </td>

    <!-- Modal of Editing Add Next-->
<div class="modal fade" id="upedit<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  <form action="<?php echo '?un_id='.$id; ?>" method="post" name="">
    <div class="form-group">
    <select type="text" name="div1" class="form-control" required>        
     <option type="text" value="">--Select One--</option>     
     <option type="text" value="Men's Open">Men's Open</option>
     <option type="text" value="Women's Open">Women's Open</option>
     <option type="text" value="Groomet">Groomet</option>
     <option type="text" value="Airborne">Airborne</option>
     </select>
    <small class="form-text text-muted">Type the division do you want. Example: Men's Open.</small>
    <input type="text" class="form-control" name="st1" value="<?php echo $un_stage; ?>" required>
    <small class="form-text text-muted">Type the stage do you want. Example: Quarterfinals.</small>
    <input type="text" class="form-control" name="ht1" value="<?php echo $un_heat; ?>"  required>
    <small class="form-text text-muted">Type the heat do you want. Example: Heat 1.</small>

    <input type="text" class="form-control" name="un_jc1" value="<?php echo $un_jc1; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number one. Example: red or blue.</small>
    <input type="text" class="form-control" name="un_jc2" value="<?php echo $un_jc2; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number two. Example: red or blue.</small>
    <input type="text" class="form-control" name="un_jc3" value="<?php echo $un_jc3; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number three. Example: red or blue.</small>
    <input type="text" class="form-control" name="un_jc4" value="<?php echo $un_jc4; ?>" required>
    <small class="form-text text-muted">Type the color for athlete number four. Example: red or blue.</small>

    <input type="text" class="form-control" style="color:black; background-color:<?php echo $un_jc1; ?>" name="un_at1" value="<?php echo $un_at1; ?>" required>
    <small class="form-text text-muted">Type the athlete name one do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $un_jc2; ?>" name="un_at2" value="<?php echo $un_at2; ?>" required>
    <small class="form-text text-muted">Type the athlete name two do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $un_jc3; ?>" name="un_at3" value="<?php echo $un_at3; ?>" required>
    <small class="form-text text-muted">Type the athlete name three do you want. Example: Mike Albarado.</small>
    <input type="text" class="form-control" style="color:black; background-color:<?php echo $un_jc4; ?>" name="un_at4" value="<?php echo $un_at4; ?>" required>
    <small class="form-text text-muted">Type the athlete name four do you want. Example: Mike Albarado.</small>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="update_upnext" class="btn btn-success">Save</button>
      </div>
      </form>
    </div>
  </div>
</div>

</tr>

  <?php } ?>

    <tr class="tr">
      <td class="stroke1" colspan="5" style="padding: 15px;"></td>
    </tr>
    <tr>
      <td colspan="5" class="developer"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="5" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"></td>
    </tr>
  </tbody>
</table>
</div>
</div>
     
    <!-- load jQuery 1.10.2 -->
     <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
     <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!-- Refresh page and send data at one time -->
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

  </body>
</html>