    
<?php
      $connect1 = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query1 = "SELECT * FROM judge_one";
      $query_run1 = mysqli_query($connect1,$query1);

      $j1= 0;
      $j2= 0;
      $j3= 0;
      $j4= 0;

      while ($num = mysqli_fetch_assoc ($query_run1)) {
            $j1 += $num['at1'];
            $j2 += $num['at2'];
            $j3 += $num['at3'];
            $j4 += $num['at4'];
            } 
    ?>

    <?php
      $connect2 = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query2 = "SELECT * FROM judge_two";
      $query_run2 = mysqli_query($connect2,$query2);

      $j5= 0;
      $j6= 0;
      $j7= 0;
      $j8= 0;
  

      while ($num = mysqli_fetch_assoc ($query_run2)) {
            $j5 += $num['at1'];
            $j6 += $num['at2'];
            $j7 += $num['at3'];
            $j8 += $num['at4'];
            } 
    ?>

    <?php
      $connect3 = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query3 = "SELECT * FROM judge_three";
      $query_run3 = mysqli_query($connect3,$query3);

      $j9= 0;
      $j10= 0;
      $j11= 0;
      $j12= 0;
  

      while ($num = mysqli_fetch_assoc ($query_run3)) {
            $j9 += $num['at1'];
            $j10 += $num['at2'];
            $j11 += $num['at3'];
            $j12 += $num['at4'];
            } 
    ?>

    <?php
      $connect4 = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query4 = "SELECT * FROM judge_four";
      $query_run4 = mysqli_query($connect4,$query4);

      $j13= 0;
      $j14= 0;
      $j15= 0;
      $j16= 0;
    

      while ($num = mysqli_fetch_assoc ($query_run4)) {
            $j13 += $num['at1'];
            $j14 += $num['at2'];
            $j15 += $num['at3'];
            $j16 += $num['at4'];
            } 
    ?>

    <?php
      $connect5 = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query5= "SELECT * FROM judge_five";
      $query_run5 = mysqli_query($connect5,$query5);

      $j17= 0;
      $j18= 0;
      $j19= 0;
      $j20= 0;
   

      while ($num = mysqli_fetch_assoc ($query_run5)) {
            $j17 += $num['at1'];
            $j18 += $num['at2'];
            $j19 += $num['at3'];
            $j20 += $num['at4'];
            } 
    ?>
    
    