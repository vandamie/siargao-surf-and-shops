<?php
error_reporting(0);
ob_start();
require_once("include/database-con.php");

      $que_on = "SELECT * FROM judges_account ORDER BY ju_status";
      $que_run_on = mysqli_query($con,$que_on);

      while ($res_on = mysqli_fetch_assoc($que_run_on)) {
            $on = $res_on['ju_status'];
            }  

if ($on == 'Offline'){  // session_start(); getting the user_name and user_password from the moment 


      $que = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $que_run = mysqli_query($con,$que);

      while ($res = mysqli_fetch_assoc($que_run)) {
            $logo = $res['logo'];
            $bg = $res['bg_img'];
            }  
  ?>



<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Judging of Surfing Competition in Siargao Island, Philippines">
    <meta name="author" content="Siargao Web Protocol">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/<?php echo $logo; ?>">
    <meta http-equiv="refresh" content="300">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>SISA PH NO EVENT</title>
      <style type="text/css">
      body {
  background-image: url("images/cloud-9.jpg");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  padding-top: 15%;
  text-align: center;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
  font-family: Arial, Helvetica, sans-serif;
  padding-bottom: 85%;
}

.content {
  max-width: 500px;
  margin: auto;
  background: white;
  padding: 10px;
  border-radius: 10px;
  border: 0px;
}

img{
  border-radius: 25px;
  height: 45px;
  width: 45px;
}
a{
  font-size: 14px;
}
  </style>

  </head>
  <body>
<div class="table-responsive content example">
  <div class="container">
<table class="table">
    <thead>
      <tr>
        <thead><img src="images/<?php echo $logo; ?>"></thead>
      </tr>
    </thead>
    <tbody>
      <tr>
      <td align="center"><h5>Sorry, no surfing event is happening today.</h5><a href="https://sisaph.000webhostapp.com/">Click for more details.</a></td>
      </tr>
    </tbody>
</table>
</div>
</div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

  </body>
</html>




<?php 
}else{
?>






<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Judging of Surfing Competition in Siargao Island, Philippines">
    <meta name="author" content="Siargao Web Protocol">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/sisa-logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>SISA PH EVENT</title>
      <style type="text/css">
  body {
  background-image: url("images/cloud-9.jpg");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  padding-top: 120px;
  padding-bottom: 200px;
  text-align: center;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
  font-size:12.5px;
  font-family: Arial, Helvetica, sans-serif;
}
th, td{
  padding:3px;
  border:0px;
  width: 35%;
  background-color:#F5F5F5; 
}
.dot1 {
  height: 16px;
  width: 16px;
  border-radius: 50%;
  display: inline-block;
}
.dot2 {
  height: 16px;
  width: 16px;
  border-radius: 50%;
  display: inline-block;
}
.dot3 {
  height: 16px;
  width: 16px;
  border-radius: 50%;
  display: inline-block;
}
.dot4 {
  height: 16px;
  width: 16px;
  border-radius: 50%;
  display: inline-block;
}

.col1 {
  width: 25%;
}
.col2 {
  width: 20%;
}
.content {
  max-width: 400px;
  margin: auto;
  background: white;
  padding-bottom: 10px;
  padding-top: 10px;
  padding-right: 1px;
  padding-left: 1px;
  border-radius:15px;
  border: 0px;
}
img{
  border-radius: 25px;
  height: 45px;
  width: 45px;
}
.bg{
  color:#6495ED;
  font-size: 10px;
} 

.developer {
  color:#6495ED;
  font-size: 10px;
  text-align:center; 
}

#clock {
  font-family: 'Orbitron', sans-serif;
  color: #00000;
  font-size: 14px;
  text-align: center;
  padding: 0px;
}
  </style>

  </head>
  <body>

 <?php
      $con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $que = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $que_run = mysqli_query($con,$que);

      while ($res = mysqli_fetch_assoc($que_run)) {
            $logo = $res['logo'];
            $title = $res['event_title'];
            $division = $res['at_division'];
            $stage = $res['at_stage'];
            $heat = $res['at_heat'];
            $at1 = $res['at_one'];
            $at2 = $res['at_two'];
            $at3 = $res['at_three'];
            $at4 = $res['at_four'];
            $co1 = $res['at_col_one'];
            $co2 = $res['at_col_two'];
            $co3 = $res['at_col_three'];
            $co4 = $res['at_col_four'];
            } 


      $query1 = "SELECT * FROM judge_one";
      $query_run1 = mysqli_query($con,$query1);

      $j1= 0;
      $j2= 0;
      $j3= 0;
      $j4= 0;

      while ($num = mysqli_fetch_assoc ($query_run1)) {
            $j1 += $num['at1'];
            $j2 += $num['at2'];
            $j3 += $num['at3'];
            $j4 += $num['at4'];
            } 
    ?>

    <?php

      $query2 = "SELECT * FROM judge_two";
      $query_run2 = mysqli_query($con,$query2);

      $j5= 0;
      $j6= 0;
      $j7= 0;
      $j8= 0;
  

      while ($num = mysqli_fetch_assoc ($query_run2)) {
            $j5 += $num['at1'];
            $j6 += $num['at2'];
            $j7 += $num['at3'];
            $j8 += $num['at4'];
            } 
    ?>

    <?php

      $query3 = "SELECT * FROM judge_three";
      $query_run3 = mysqli_query($con,$query3);

      $j9= 0;
      $j10= 0;
      $j11= 0;
      $j12= 0;
  

      while ($num = mysqli_fetch_assoc ($query_run3)) {
            $j9 += $num['at1'];
            $j10 += $num['at2'];
            $j11 += $num['at3'];
            $j12 += $num['at4'];
            } 
    ?>

    <?php

      $query4 = "SELECT * FROM judge_four";
      $query_run4 = mysqli_query($con,$query4);

      $j13= 0;
      $j14= 0;
      $j15= 0;
      $j16= 0;
    

      while ($num = mysqli_fetch_assoc ($query_run4)) {
            $j13 += $num['at1'];
            $j14 += $num['at2'];
            $j15 += $num['at3'];
            $j16 += $num['at4'];
            } 
    ?>

    <?php

      $query5= "SELECT * FROM judge_five";
      $query_run5 = mysqli_query($con,$query5);

      $j17= 0;
      $j18= 0;
      $j19= 0;
      $j20= 0;
   

      while ($num = mysqli_fetch_assoc ($query_run5)) {
            $j17 += $num['at1'];
            $j18 += $num['at2'];
            $j19 += $num['at3'];
            $j20 += $num['at4'];
            } 
    ?>
    
    <?php
    $tol_at1 = number_format($j1,2)+number_format($j5,2)+number_format($j9,2)+number_format($j13,2)+number_format($j17,2);
    $tol_at2 = number_format($j2,2)+number_format($j6,2)+number_format($j10,2)+number_format($j14,2)+number_format($j18,2);
    $tol_at3 = number_format($j3,2)+number_format($j7,2)+number_format($j11,2)+number_format($j15,2)+number_format($j19,2);
    $tol_at4 = number_format($j4,2)+number_format($j8,2)+number_format($j12,2)+number_format($j16,2)+number_format($j20,2);
     ?>
     
   <!------------------ATHLETE 1 IF STATEMENT RESULT---------------------->
     <?php if($tol_at1 > $tol_at2 && $tol_at1 > $tol_at3 && $tol_at1 > $tol_at4){ ?>

      <?php
      $nd1 = $tol_at1 - $tol_at2+1;
      $nd2 = $tol_at1 - $tol_at3+1; 
      $nd3 = $tol_at1 - $tol_at4+1;
     ?>

<div class="table-responsive content">
  <div class="container">
<table align="center">
  <thead>
    <tr>
      <td colspan="4" style="padding-top: 10px; border-radius: 20px 20px 0px 0px; text-align:right;">
            <!-- Button trigger modal for Up Next link -->
<a data-toggle="modal" data-target="#un" href="#un">
Up Next
</a>

    </td>
    </tr>

<!-- Modal UP NEXT-->
<div class="modal fade" id="un" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center">Up Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="right">
        <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query_all = "SELECT * FROM data_link";
      $query_run_all = mysqli_query($con,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
        <a data-toggle="modal" data-target="#li_div1" href="#li_div1"><?php echo $link_div1; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div2" href="#li_div2"><?php echo $link_div2; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div3" href="#li_div3"><?php echo $link_div3; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div4" href="#li_div4"><?php echo $link_div4; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div5" href="#li_div5"><?php echo $link_div5; ?></a>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $query_dm2 = "SELECT * FROM upnext ORDER BY un_id DESC LIMIT 1";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_date=$res1['un_date'];
              $un_ad_name=$res1['un_ad_name'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];         
           echo "<strong>".$un_date."</strong>"."<br>"."<u>".$un_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_heat.""."</u><br>";  
            }
        

      $query_dm2 = "SELECT * FROM upnext ORDER BY un_id ASC";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
              }
           ?>
            
           <br><span class="dot1" style="background:<?php echo $un_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $un_at1; ?>
           <br><span class="dot2" style="background:<?php echo $un_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $un_at2; ?>
           <br><span class="dot3" style="background:<?php echo $un_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $un_at3; ?>
           <br><span class="dot4" style="background:<?php echo $un_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $un_at4; ?>
          </p>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division One-->
<div class="modal fade" id="li_div1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div1; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div1);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division Two-->
<div class="modal fade" id="li_div2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div2; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div2);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of Organize Event Division three-->
<div class="modal fade" id="li_div3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div3; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div3);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division four-->
<div class="modal fade" id="li_div4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div4; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div4);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division five-->
<div class="modal fade" id="li_div5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div5; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div5);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
      <!------------/////////////////////output for viewers page////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--------->
    </tr>
    <tr>
      <th colspan="4" align="center"><img src="images/<?php echo $logo; ?>"></th>
    </tr>
    <tr>
      <td colspan="4" style="padding: 5px;"></td>
    </tr>
    <tr>
      <td style="text-decoration: underline;"><?php echo $division; ?></td>
      <td style="text-decoration: underline;"><?php echo $stage; ?></td>
      <td align="center"><?php echo $heat; ?></td>
      <td></td>
    </tr> 
   </thead> 
  <tbody>
    <tr>
      <td class="col1"><span class="dot1" style="background:<?php echo $co1; ?>;"></span></td>
      <td class="col2"><?php echo $at1; ?></td>
      <td class="col2"><?php echo number_format($tol_at1,2); ?></td>
      <th class="col1"></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot2" style="background:<?php echo $co2; ?>;"></span></td>
      <td class="col2"><?php echo $at2; ?></td>
      <td class="col2"><?php echo number_format($tol_at2,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd1,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot3" style="background:<?php echo $co3; ?>;"></span></td>
      <td class="col2"><?php echo $at3; ?></td>
      <td class="col2"><?php echo number_format($tol_at3,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd2,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot4" style="background:<?php echo $co4; ?>;"></span></td>
      <td class="col2"><?php echo $at4; ?></td>
      <td class="col2"><?php echo number_format($tol_at4,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd3,2); ?></th>
    </tr>
    <tr>
      <td colspan="4" class="developer" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
  </tbody>
</table>
</div>
</div>
    <!-------------ATHLETE 2----------------->
    <?php }else if($tol_at2 > $tol_at1 && $tol_at2 > $tol_at3 && $tol_at2 > $tol_at4){ ?>

      <?php
      $nd1 = $tol_at2 - $tol_at1+1;
      $nd2 = $tol_at2 - $tol_at3+1; 
      $nd3 = $tol_at2 - $tol_at4+1;
     ?>

<div class="table-responsive content">
  <div class="container">
<table align="center">
  <thead>
    <tr>
      <td colspan="4" style="padding-top: 10px; border-radius: 20px 20px 0px 0px; text-align:right;">
            <!-- Button trigger modal for Up Next link -->
<a data-toggle="modal" data-target="#un" href="#un">
Up Next
</a>

    </td>
    </tr>

<!-- Modal UP NEXT-->
<div class="modal fade" id="un" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center">Up Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="right">
        <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $connect_all = mysqli_connect("localhost:3308", "root", "", "admin_cms");
      $query_all = "SELECT * FROM data_link WHERE link_id = 1";
      $query_run_all = mysqli_query($connect_all,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
        <a data-toggle="modal" data-target="#li_div1" href="#li_div1"><?php echo $link_div1; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div2" href="#li_div2"><?php echo $link_div2; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div3" href="#li_div3"><?php echo $link_div3; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div4" href="#li_div4"><?php echo $link_div4; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div5" href="#li_div5"><?php echo $link_div5; ?></a>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $query_dm2 = "SELECT * FROM upnext ORDER BY un_id DESC LIMIT 1";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_date=$res1['un_date'];
              $un_ad_name=$res1['un_ad_name'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];         
           echo "<strong>".$un_date."</strong>"."<br>"."<u>".$un_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_heat.""."</u><br>";  
            }
        

      $query_dm2 = "SELECT * FROM upnext ORDER BY un_id ASC";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
              }
           ?>
            
           <br><span class="dot1" style="background:<?php echo $un_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $un_at1; ?>
           <br><span class="dot2" style="background:<?php echo $un_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $un_at2; ?>
           <br><span class="dot3" style="background:<?php echo $un_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $un_at3; ?>
           <br><span class="dot4" style="background:<?php echo $un_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $un_at4; ?>
          </p>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division One-->
<div class="modal fade" id="li_div1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div1; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div1);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division Two-->
<div class="modal fade" id="li_div2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div2; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div2);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of Organize Event Division three-->
<div class="modal fade" id="li_div3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div3; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div3);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division four-->
<div class="modal fade" id="li_div4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div4; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div4);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division five-->
<div class="modal fade" id="li_div5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div5; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div5);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
      <!------------/////////////////////output for viewers page////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--------->
    </tr>
    <tr>
      <th colspan="4" align="center"><img src="images/<?php echo $logo; ?>"></th>
    </tr>
    <tr>
      <th colspan="4" align="center"><?php echo $title; ?></th>
    </tr>
    <tr>
      <td colspan="4" style="padding: 5px;"></td>
    </tr>
    <tr>
      <td style="text-decoration: underline;"><?php echo $division; ?></td>
      <td style="text-decoration: underline;"><?php echo $stage; ?></td>
      <td align="center"><?php echo $heat; ?></td>
      <td></td>
    </tr> 
   </thead> 
  <tbody>
    <tr>
      <td class="col1"><span class="dot1" style="background:<?php echo $co2; ?>;"></span></td>
      <td class="col2"><?php echo $at2; ?></td>
      <td class="col2"><?php echo number_format($tol_at2,2); ?></td>
      <th class="col1"></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot2" style="background:<?php echo $co1; ?>;"></span></td>
      <td class="col2"><?php echo $at1; ?></td>
      <td class="col2"><?php echo number_format($tol_at1,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd1,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot3" style="background:<?php echo $co3; ?>;"></span></td>
      <td class="col2"><?php echo $at3; ?></td>
      <td class="col2"><?php echo number_format($tol_at3,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd2,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot4" style="background:<?php echo $co4; ?>;"></span></td>
      <td class="col2"><?php echo $at4; ?></td>
      <td class="col2"><?php echo number_format($tol_at4,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd3,2); ?></th>
    </tr>
    <tr>
      <td colspan="4" class="developer" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
  </tbody>
</table>
</div>
</div>
<!----------TOTAL FOR ATHLETE 3----------->
    <?php }else if($tol_at3 > $tol_at1 && $tol_at3 > $tol_at2 && $tol_at3 > $tol_at4){ ?>

      <?php
      $nd1 = $tol_at3 - $tol_at2+1;
      $nd2 = $tol_at3 - $tol_at1+1; 
      $nd3 = $tol_at3 - $tol_at4+1;
     ?>

<div class="table-responsive content">
  <div class="container">
<table align="center">
  <thead>
    <tr>
      <td colspan="4" style="padding-top: 10px; border-radius: 20px 20px 0px 0px; text-align:right;">
            <!-- Button trigger modal for Up Next link -->
<a data-toggle="modal" data-target="#un" href="#un">
Up Next
</a>

    </td>
    </tr>

<!-- Modal UP NEXT-->
<div class="modal fade" id="un" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center">Up Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="right">
        <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $connect_all = mysqli_connect("localhost:3308", "root", "", "admin_cms");
      $query_all = "SELECT * FROM data_link WHERE link_id = 1";
      $query_run_all = mysqli_query($connect_all,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
        <a data-toggle="modal" data-target="#li_div1" href="#li_div1"><?php echo $link_div1; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div2" href="#li_div2"><?php echo $link_div2; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div3" href="#li_div3"><?php echo $link_div3; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div4" href="#li_div4"><?php echo $link_div4; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div5" href="#li_div5"><?php echo $link_div5; ?></a>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $query_dm2 = "SELECT * FROM upnext ORDER BY un_id DESC LIMIT 1";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_date=$res1['un_date'];
              $un_ad_name=$res1['un_ad_name'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];         
           echo "<strong>".$un_date."</strong>"."<br>"."<u>".$un_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_heat.""."</u><br>";  
            }
        

      $query_dm2 = "SELECT * FROM upnext ORDER BY un_id ASC";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
              }
           ?>
            
           <br><span class="dot1" style="background:<?php echo $un_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $un_at1; ?>
           <br><span class="dot2" style="background:<?php echo $un_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $un_at2; ?>
           <br><span class="dot3" style="background:<?php echo $un_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $un_at3; ?>
           <br><span class="dot4" style="background:<?php echo $un_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $un_at4; ?>
          </p>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division One-->
<div class="modal fade" id="li_div1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div1; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div1);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division Two-->
<div class="modal fade" id="li_div2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div2; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div2);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of Organize Event Division three-->
<div class="modal fade" id="li_div3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div3; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div3);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division four-->
<div class="modal fade" id="li_div4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div4; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div4);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division five-->
<div class="modal fade" id="li_div5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div5; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div5);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
      <!------------/////////////////////output for viewers page////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--------->
    </tr>
    <tr>
      <th colspan="4" align="center"><img src="images/<?php echo $logo; ?>"></th>
    </tr>
    <tr>
      <th colspan="4" align="center"><?php echo $title; ?></th>
    </tr>
    <tr>
      <td colspan="4" style="padding: 5px;"></td>
    </tr>
    <tr>
      <td style="text-decoration: underline;"><?php echo $division; ?></td>
      <td style="text-decoration: underline;"><?php echo $stage; ?></td>
      <td align="center"><?php echo $heat; ?></td>
      <td></td>
    </tr> 
   </thead> 
  <tbody>
    <tr>
      <td class="col1"><span class="dot1" style="background:<?php echo $co3; ?>;"></span></td>
      <td class="col2"><?php echo $at3; ?></td>
      <td class="col2"><?php echo number_format($tol_at3,2); ?></td>
      <th class="col1"></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot2" style="background:<?php echo $co2; ?>;"></span></td>
      <td class="col2"><?php echo $at2; ?></td>
      <td class="col2"><?php echo number_format($tol_at2,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd1,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot3" style="background:<?php echo $co1; ?>;"></span></td>
      <td class="col2"><?php echo $at1; ?></td>
      <td class="col2"><?php echo number_format($tol_at1,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd2,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot4" style="background:<?php echo $co4; ?>;"></span></td>
      <td class="col2"><?php echo $at4; ?></td>
      <td class="col2"><?php echo number_format($tol_at4,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd3,2); ?></th>
    </tr>
    <tr>
      <td colspan="4" class="developer" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
  </tbody>
</table>
</div>
</div>
<!----------TOTAL FOR ATHLETE 4----------->
    <?php }else if($tol_at4 > $tol_at2 && $tol_at4 > $tol_at3 && $tol_at4 > $tol_at1){ ?>

      <?php
      $nd1 = $tol_at4 - $tol_at2+1;
      $nd2 = $tol_at4 - $tol_at3+1; 
      $nd3 = $tol_at4 - $tol_at1+1;
     ?>

<div class="table-responsive content">
  <div class="container">
<table align="center">
  <thead>
    <tr>
      <td colspan="4" style="padding-top: 10px; border-radius: 20px 20px 0px 0px; text-align:right;">
      <!-- Button trigger modal for Up Next link -->
<a data-toggle="modal" data-target="#un" href="#un">
Up Next
</a>

    </td>
    </tr>

<!-- Modal UP NEXT-->
<div class="modal fade" id="un" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center">Up Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="right">
        <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $connect_all = mysqli_connect("localhost:3308", "root", "", "admin_cms");
      $query_all = "SELECT * FROM data_link WHERE link_id = 1";
      $query_run_all = mysqli_query($connect_all,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
        <a data-toggle="modal" data-target="#li_div1" href="#li_div1"><?php echo $link_div1; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div2" href="#li_div2"><?php echo $link_div2; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div3" href="#li_div3"><?php echo $link_div3; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div4" href="#li_div4"><?php echo $link_div4; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div5" href="#li_div5"><?php echo $link_div5; ?></a>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $query_dm2 = "SELECT * FROM upnext ORDER BY un_id DESC LIMIT 1";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_date=$res1['un_date'];
              $un_ad_name=$res1['un_ad_name'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];         
           echo "<strong>".$un_date."</strong>"."<br>"."<u>".$un_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_heat.""."</u><br>";  
            }
        

      $query_dm2 = "SELECT * FROM upnext ORDER BY un_id ASC";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
              }
           ?>
            
           <br><span class="dot1" style="background:<?php echo $un_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $un_at1; ?>
           <br><span class="dot2" style="background:<?php echo $un_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $un_at2; ?>
           <br><span class="dot3" style="background:<?php echo $un_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $un_at3; ?>
           <br><span class="dot4" style="background:<?php echo $un_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $un_at4; ?>
          </p>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division One-->
<div class="modal fade" id="li_div1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div1; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div1);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division Two-->
<div class="modal fade" id="li_div2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div2; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div2);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of Organize Event Division three-->
<div class="modal fade" id="li_div3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div3; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div3);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division four-->
<div class="modal fade" id="li_div4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div4; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div4);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division five-->
<div class="modal fade" id="li_div5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div5; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div5);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
      <!------------/////////////////////output for viewers page////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--------->
    </tr>
    <tr>
      <th colspan="4" align="center"><img src="images/<?php echo $logo; ?>"></th>
    </tr>
    <tr>
      <th colspan="4" align="center"><?php echo $title; ?></th>
    </tr>
    <tr>
      <td colspan="4" style="padding: 5px;"></td>
    </tr>
    <tr>
      <td style="text-decoration: underline;"><?php echo $division; ?></td>
      <td style="text-decoration: underline;"><?php echo $stage; ?></td>
      <td align="center"><?php echo $heat; ?></td>
      <td></td>
    </tr> 
   </thead> 
  <tbody>
    <tr>
      <td class="col1"><span class="dot1" style="background:<?php echo $co4; ?>;"></span></td>
      <td class="col2"><?php echo $at4; ?></td>
      <td class="col2"><?php echo number_format($tol_at4,2); ?></td>
      <th class="col1"></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot2" style="background:<?php echo $co2; ?>;"></span></td>
      <td class="col2"><?php echo $at2; ?></td>
      <td class="col2"><?php echo number_format($tol_at2,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd1,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot3" style="background:<?php echo $co3; ?>;"></span></td>
      <td class="col2"><?php echo $at3; ?></td>
      <td class="col2"><?php echo number_format($tol_at3,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd2,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot4" style="background:<?php echo $co1; ?>;"></span></td>
      <td class="col2"><?php echo $at1; ?></td>
      <td class="col2"><?php echo number_format($tol_at1,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd3,2); ?></th>
    </tr>
    <tr>
      <td colspan="4" class="developer" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
  </tbody>
</table>
</div>
</div>

<!----------TOTAL FOR ATHLETE 1 ELSE RESULT----------->
<?php }else{ ?>

     <?php
      $nd1 = $tol_at2 - $tol_at1+1;
      $nd2 = $tol_at2 - $tol_at3+1; 
      $nd3 = $tol_at2 - $tol_at4+1;
     ?>

<div class="table-responsive content">
  <div class="container">
<table align="center">
  <thead>
    <tr>
      <td colspan="4" style="padding-top: 10px; border-radius: 20px 20px 0px 0px; text-align:right;">  
<!-- Button trigger modal for Up Next link -->
<a data-toggle="modal" data-target="#un" href="#un">
Up Next
</a>

    </td>
    </tr>

<!-- Modal UP NEXT-->
<div class="modal fade" id="un" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center">Up Next</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="right">
        <!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $query_all = "SELECT * FROM data_link WHERE link_id = 1";
      $query_run_all = mysqli_query($con,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $id=$res['link_id'];
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>
        <a data-toggle="modal" data-target="#li_div1" href="#li_div1"><?php echo $link_div1; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div2" href="#li_div2"><?php echo $link_div2; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div3" href="#li_div3"><?php echo $link_div3; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div4" href="#li_div4"><?php echo $link_div4; ?></a>&nbsp;&nbsp;&nbsp;
        <a data-toggle="modal" data-target="#li_div5" href="#li_div5"><?php echo $link_div5; ?></a>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $query_dm2 = "SELECT * FROM upnext ORDER BY un_id DESC LIMIT 1";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_date=$res1['un_date'];
              $un_ad_name=$res1['un_ad_name'];
              $un_division=$res1['un_division'];
              $un_stage=$res1['un_stage'];
              $un_heat=$res1['un_heat'];         
           echo "<strong>".$un_date."</strong>"."<br>"."<u>".$un_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$un_heat.""."</u><br>";  
            }
        

      $query_dm2 = "SELECT * FROM upnext ORDER BY un_id ASC";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $un_jc1=$res1['un_jc1'];
              $un_jc2=$res1['un_jc2'];
              $un_jc3=$res1['un_jc3'];
              $un_jc4=$res1['un_jc4'];
              $un_at1=$res1['un_at1'];
              $un_at2=$res1['un_at2'];
              $un_at3=$res1['un_at3'];
              $un_at4=$res1['un_at4'];
              }
           ?>
            
           <br><span class="dot1" style="background:<?php echo $un_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $un_at1; ?>
           <br><span class="dot2" style="background:<?php echo $un_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $un_at2; ?>
           <br><span class="dot3" style="background:<?php echo $un_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $un_at3; ?>
           <br><span class="dot4" style="background:<?php echo $un_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $un_at4; ?>
          </p>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division One-->
<div class="modal fade" id="li_div1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div1; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div1);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of  Organize Event Division Two-->
<div class="modal fade" id="li_div2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div2; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div2);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal list of Organize Event Division three-->
<div class="modal fade" id="li_div3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div3; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div3);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division four-->
<div class="modal fade" id="li_div4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div4; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div4);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal list of  Organize Event Division five-->
<div class="modal fade" id="li_div5" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle" align="center"><?php echo $link_div5; ?></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" align="left">
  
      <p>
     <?php
     $do = addslashes($link_div5);
     $query_dm2 = "SELECT * FROM organize_event WHERE og_division = '$do' ";
      $query_run_dm2 = mysqli_query($con,$query_dm2);
      while ($res1 = mysqli_fetch_assoc ($query_run_dm2)){
              $og_date=$res1['og_date'];
              $og_ad_name=$res1['og_ad_name'];
              $og_division=$res1['og_division'];
              $og_stage=$res1['og_stage'];
              $og_heat=$res1['og_heat'];

              $og_jc1=$res1['og_jc1'];
              $og_jc2=$res1['og_jc2'];
              $og_jc3=$res1['og_jc3'];
              $og_jc4=$res1['og_jc4'];
              $og_at1=$res1['og_at1'];
              $og_at2=$res1['og_at2'];
              $og_at3=$res1['og_at3'];
              $og_at4=$res1['og_at4'];         
           echo "<strong>".$og_date."</strong>"."<br>"."<u>".$og_division."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_stage."</u>"."&nbsp;"."&nbsp;"."&nbsp;"."&nbsp;"."<u>".$og_heat.""."</u><br>";  
           ?>
            
           <br><span class="dot1" style="background:<?php echo $og_jc1; ?>"></span>&nbsp;&nbsp;<?php echo $og_at1; ?>
           <br><span class="dot2" style="background:<?php echo $og_jc2; ?>"></span>&nbsp;&nbsp;<?php echo $og_at2; ?>
           <br><span class="dot3" style="background:<?php echo $og_jc3; ?>"></span>&nbsp;&nbsp;<?php echo $og_at3; ?>
           <br><span class="dot4" style="background:<?php echo $og_jc4; ?>"></span>&nbsp;&nbsp;<?php echo $og_at4; ?><br><br>
         <?php } ?>
          </p>
        </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
      <!------------/////////////////////output for viewers page////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////--------->
    <tr>
      <th colspan="4" align="center"><img src="images/<?php echo $logo; ?>"></th>
    </tr>
    <tr>
      <th colspan="4" align="center"><?php echo $title; ?></th>
    </tr>
    <tr>
      <td colspan="4" style="padding: 5px;"></td>
    </tr>
    <tr>
      <td style="text-decoration: underline;"><?php echo $division; ?></td>
      <td style="text-decoration: underline;"><?php echo $stage; ?></td>
      <td align="center"><?php echo $heat; ?></td>
      <td></td>
    </tr> 
   </thead> 
  <tbody>
    <tr>
      <td class="col1"><span class="dot1" style="background:<?php echo $co2; ?>;"></span></td>
      <td class="col2"><?php echo $at2; ?></td>
      <td class="col2"><?php echo number_format($tol_at2,2); ?></td>
      <th class="col1"></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot2" style="background:<?php echo $co1; ?>;"></span></td>
      <td class="col2"><?php echo $at1; ?></td>
      <td class="col2"><?php echo number_format($tol_at1,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd1,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot3" style="background:<?php echo $co3; ?>;"></span></td>
      <td class="col2"><?php echo $at3; ?></td>
      <td class="col2"><?php echo number_format($tol_at3,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd2,2); ?></th>
    </tr>
    <tr>
      <td class="col1"><span class="dot4" style="background:<?php echo $co4; ?>;"></span></td>
      <td class="col2"><?php echo $at4; ?></td>
      <td class="col2"><?php echo number_format($tol_at4,2); ?></td>
      <th class="col1"><?php echo "need"." ".number_format($nd3,2); ?></th>
    </tr>
    <tr>
      <td colspan="4" class="developer" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
  </tbody>
</table>
</div>
</div>


<?php } ?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>


  </body>
</html>




<?php

}

ob_end_flush();
?>
