<?php 
ob_start();
error_reporting(E_ALL);
session_start();
require_once("include/crud.php");
require_once ("include/class.judge.php"); // class of functions of User.
require_once ("include/database-con.php"); // class of functions of database connection.
$user = new judge();
$crud = new crud();

//user status and username session
$hjudge = $_SESSION['ju_name'];
$judge_status = $_SESSION['ju_name'];


      $query_all = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $query_run_all = mysqli_query($con,$query_all);


      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $at1a = $res['at_one'];
            $at2a = $res['at_two'];
            $at3a = $res['at_three'];
            $at4a = $res['at_four'];

            $p1a = $res['at_img_one'];
            $p2a = $res['at_img_two'];
            $p3a = $res['at_img_three'];
            $p4a = $res['at_img_four'];

            $co1a = $res['at_col_one'];
            $co2a = $res['at_col_two'];
            $co3a = $res['at_col_three'];
            $co4a = $res['at_col_four'];

            $n1a = $res['at_one'];
            $n2a = $res['at_two'];
            $n3a = $res['at_three'];
            $n4a = $res['at_four'];

            $d1a = $res['at_division'];
            $st1a = $res['at_stage'];
            $ht1a = $res['at_heat'];
            
            $logo1a = $res['logo'];
            $bg_img1a = $res['bg_img'];
            $event_titale1a = $res['event_title'];
            } 


if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:index.php");
}else{

  $sql = "UPDATE judges_account SET ju_status = 'Online' WHERE judge_id = '$hjudge'";
  mysqli_query($con,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  header("location:index.php");

  $sql = "UPDATE judges_account SET ju_status = 'Offline' WHERE judge_id = '$hjudge'";
  mysqli_query($con,$sql);
  session_destroy();
  session_unset();
}

ob_end_flush();
?>



<!--------------------------------- head judge-page.php--------------------------------------->
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/<?php echo $logo1a; ?>">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>SISA PH Head Judge Page</title>

    <style>
body {
  background-image: url("images/<?php echo $bg_img1a; ?>");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  font-family:arial;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
  font-size:15px;
  padding-bottom: 40px;
  padding-top: 40px; 
  text-align: center;
}
.tr{
  border: 0;
  text-align: center;
  width: 100%;
}

.result{
  border: 0;
  text-align: center;
  width: 100%;
  font-size: 17px;
  font-weight: bold;
  text-decoration: underline;

}

.content {
  max-width: 1050px;
  margin: auto;
  background: white;
  border-radius: 35px;
  padding: 8px 8px 8px 8px;
}

.header{
  text-align: center;
}

* {
  box-sizing:border-box;
}

.left {
  width:35%; /* The width is 30%, by default */
  background-color:#F5F5F5;
  padding-left: 15px;
}

.main {
  width:40%; /* The width is 45%, by default */
  background-color:#F5F5F5;
}

.right { 
  width:35%; /* The width is 25%, by default */
  background-color:#F5F5F5;
  padding-right: 15px;
}

/* Use a media query to add a break point at 800px: */
@media screen and (max-width:800px) {
  .left, .main, .right {
    width:100%; /* The width is 100%, when the viewport is 800px or smaller */
  }
}

.img1 {
  border-radius: 50%;
  background:<?php echo $co1a; ?>;
  padding: 3px; 
  width:70px;
  height:70px;   
}
.img2 {
  border-radius: 50%;
  background:<?php echo $co2a; ?>;
  padding: 3px; 
  width:70px;
  height:70px;    
}
.img3 {
  border-radius: 50%;
  background:<?php echo $co3a; ?>;
  padding: 3px; 
  width:70px;
  height:70px;    
}
.img4 {
  border-radius: 50%;
  background:<?php echo $co4a; ?>;
  padding: 3px; 
  width:70px;
  height:70px;  
} 
.imglogo {
  border-radius: 50%;
  width:65px;
  height:65px;  
} 
.stroke1{
  background-color:#F5F5F5;
  border-radius-top:10%;
  padding: 10px;
  padding-right: 15px;
  padding-left: 15px;
}
.stroke2{
  background-color:#F5F5F5;
  padding: 8px;
  padding-right: 15px;
  padding-left: 15px;
}

.developer {
  color:#6495ED;
  font-size: 10px;
  text-align:center;
  padding-top: 5px;
  background-color:#F5F5F5;
  padding-bottom: 20px; 
}
th{
  padding: 4px;
}

</style>
</head>
<body>


<!---------------------------------SISA PH SCORING OF SURFING EVENT-------------------------------------->
<div class="table-responsive content">
<table class="table-responsive content"  align="center">
  <thead>
    <tr>
      <td class="stroke2" colspan="9" align="right" style="padding-top: 10px; border-radius: 20px 20px 0px 0px;"><div class="dropdown">
  <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size: 14px">
    User: <?php $user->get_hjudge($hjudge); ?>
  </a>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
      <a class="dropdown-item" style="font-size: 14px" href="upnext.php" data-target="#upnext">Add Next</a>
  <a class="dropdown-item" style="font-size: 14px" href="organize-event01.php">Organize Surfing Event</a>
  <a class="dropdown-item" href="export_print.php" style="font-size: 14px">Print and Export</a>
    <a class="dropdown-item" href="head-judge.php?q=logout" style="font-size: 14px" onclick="return confirm('Are you sure do you want to logout?')">Logout</a>
    <input type="hidden" name="<?php $user->get_judge_status($judge_status); ?>">
  </div>
</div></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="9" align="center"><h4 class="header"><img src="images/<?php echo $logo1a; ?>" class="imglogo"></td>
    </tr>
    <tr>
      <td class="stroke2" colspan="9" align="center"><h4 class="header"><?php echo $event_titale1a; ?></h4></td>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td class="stroke2" colspan="9" align="center"><h5 class="header"><?php echo $d1a; ?></h5></td>
    </tr>
    
    <tr class="tr">
      <td class="stroke1" colspan="9" align="center"><h5 class="header"><u><?php echo $st1a; ?> Scores</u></h5></td>
    </tr>
    
    <tr class="tr">
      <td class="stroke1" colspan="9" align="center"><h5 class="header"><u><?php echo $ht1a; ?></u></h5></td>
    </tr>
    
    <tr class="tr">
      <td class="stroke1" colspan="9" align="right">
        
        <!-- Data Monitoring -->
<button type="button" class="btn btn-info" data-toggle="modal" data-target="#monitoring">
  Data Monitoring
</button></td>


    <!-- Modal of Data Monitoring -->
<div class="modal fade" id="monitoring" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Data Monitoring</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post"> 
      <div class="modal-body" align="left"> 
     <?php
      
      $query_dm = "SELECT * FROM data_monitoring ORDER BY dm_id DESC";
      $query_run_dm = mysqli_query($con,$query_dm);

      $dm1= 0;
      $dm2= 0;
      $dm3= 0;
      $dm4= 0;
      
      while ($dm_row = mysqli_fetch_assoc ($query_run_dm)) {
            $dm_ju = $dm_row['judge_names'];
            $dm_act = $dm_row['actions'];
            $wave = $dm_row['dm_wave'];
            $dm_at1 = $dm_row['dm_at1'];
            $dm_at2 = $dm_row['dm_at2'];
            $dm_at3 = $dm_row['dm_at3'];
            $dm_at4 = $dm_row['dm_at4'];
            $dm1 = $dm_row['score1'];
            $dm2 = $dm_row['score2'];
            $dm3 = $dm_row['score3'];
            $dm4 = $dm_row['score4'];
            $dm_time = $dm_row['cur_time'];
            
           echo "<p>"."<strong>".$dm_time."</strong>"."<br>"."<u>".$dm_ju."</u>"."  ".$dm_act."<br>"."  "."<font style='color:green;'><strong>".$dm_at1." ".":"." ".$dm1.", <br>".$dm_at2." ".":"." ".$dm2.", <br>".$dm_at3." ".":"." ".$dm3.", <br>".$dm_at4." ".":"." ".$dm4."<br></strong></font>"." on"." "."<u>"."wave"." ".$wave."</u>."."</p>";  
           
            } 
    ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-danger" name="dm_delete" value="Clear Data" onclick="return confirm('Are you sure do you want to clear the data?')">
      </form>
      </div>
    </div>
  </div>
</div>
      </td>
    </tr>

<!-----------------------------------Judge Five-------------------------------------------> 
    <?php


      $qry5 = "SELECT * FROM judges_data_form WHERE form_id = 5";
      $qry_run5 = mysqli_query($con,$qry5);

      while ($res = mysqli_fetch_assoc ($qry_run5)) {

            $nt1 = $res['at_one'];
            $nt2 = $res['at_two'];
            $nt3 = $res['at_three'];
            $nt4 = $res['at_four'];

            $ju5 = $res['ju_name'];

            } 

      $query5 = "SELECT * FROM judge_five, judges_data_form WHERE form_id = 5";
      $query_run5 = mysqli_query($con,$query5);

      $tolfi1= 0;
      $tolfi2= 0;
      $tolfi3= 0;
      $tolfi4= 0;

      while ($num = mysqli_fetch_assoc ($query_run5)) {

            $tolfi1 += $num['at1'];
            $tolfi2 += $num['at2'];
            $tolfi3 += $num['at3'];
            $tolfi4 += $num['at4'];

            }
  ?>          
 <!-----------------------------------------Judge Four-------------------------------------------->          
  <?php           
      
      $qry4 = "SELECT * FROM judges_data_form WHERE form_id = 4";
      $qry_run4 = mysqli_query($con,$qry4);

      while ($res = mysqli_fetch_assoc ($qry_run4)) {

            $nt1 = $res['at_one'];
            $nt2 = $res['at_two'];
            $nt3 = $res['at_three'];
            $nt4 = $res['at_four'];

            $ju4 = $res['ju_name'];

            } 

    
      $query4 = "SELECT * FROM judge_four, judges_data_form WHERE form_id = 4";
      $query_run4 = mysqli_query($con,$query4);

      $tolfo1= 0;
      $tolfo2= 0;
      $tolfo3= 0;
      $tolfo4= 0;

      while ($num = mysqli_fetch_assoc ($query_run4)) {

            $tolfo1 += $num['at1'];
            $tolfo2 += $num['at2'];
            $tolfo3 += $num['at3'];
            $tolfo4 += $num['at4'];

            }
 ?>           
 <!-----------------------------------------Judge Three-------------------------------------------->        
<?php    

      $qry3 = "SELECT * FROM judges_data_form WHERE form_id = 3";
      $qry_run3 = mysqli_query($con,$qry3);

      while ($res = mysqli_fetch_assoc ($qry_run3)) {

            $nt1 = $res['at_one'];
            $nt2 = $res['at_two'];
            $nt3 = $res['at_three'];
            $nt4 = $res['at_four'];

            $ju3 = $res['ju_name'];

            } 
  

      $query3 = "SELECT * FROM judge_three, judges_data_form WHERE form_id = 3";
      $query_run3 = mysqli_query($con,$query3);

      $tolth1= 0;
      $tolth2= 0;
      $tolth3= 0;
      $tolth4= 0;

      while ($num = mysqli_fetch_assoc ($query_run3)) {

            $tolth1 += $num['at1'];
            $tolth2 += $num['at2'];
            $tolth3 += $num['at3'];
            $tolth4 += $num['at4'];

            } 
 ?>           
<!-----------------------------------------Judge Two-------------------------------------------->
<?php            
   
  
      $qry2 = "SELECT * FROM judges_data_form WHERE form_id = 2";
      $qry_run2 = mysqli_query($con,$qry2);

      while ($res = mysqli_fetch_assoc ($qry_run2)) {

            $nt1 = $res['at_one'];
            $nt2 = $res['at_two'];
            $nt3 = $res['at_three'];
            $nt4 = $res['at_four'];

            $ju2 = $res['ju_name'];

            } 
            
           

      $query2 = "SELECT * FROM judge_two";
      $query_run2 = mysqli_query($con,$query2);

      $tolt1= 0;
      $tolt2= 0;
      $tolt3= 0;
      $tolt4= 0;


      while ($num = mysqli_fetch_assoc ($query_run2)) {

            $tolt1 += $num['at1'];
            $tolt2 += $num['at2'];
            $tolt3 += $num['at3'];
            $tolt4 += $num['at4'];

            } 
?>
<!-----------------------------------------Judge One-------------------------------------------->
<?php  


      $qry1 = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $qry_run1 = mysqli_query($con,$qry1);

      while ($res = mysqli_fetch_assoc ($qry_run1)) {

            $at1 = $res['at_one'];
            $at2 = $res['at_two'];
            $at3 = $res['at_three'];
            $at4 = $res['at_four'];

            $p1 = $res['at_img_one'];
            $p2 = $res['at_img_two'];
            $p3 = $res['at_img_three'];
            $p4 = $res['at_img_four'];

            $co1 = $res['at_col_one'];
            $co2 = $res['at_col_two'];
            $co3 = $res['at_col_three'];
            $co4 = $res['at_col_four'];

            $n1 = $res['at_one'];
            $n2 = $res['at_two'];
            $n3 = $res['at_three'];
            $n4 = $res['at_four'];

            $d1 = $res['at_division'];
            $st1 = $res['at_stage'];
            $ju1 = $res['ju_name'];

            } 
    

      $query1 = "SELECT * FROM judge_one";
      $query_run1 = mysqli_query($con,$query1);

      $tolo1= 0;
      $tolo2= 0;
      $tolo3= 0;
      $tolo4= 0;

      while ($num = mysqli_fetch_assoc ($query_run1)) {

            $tolo1 += $num['at1'];
            $tolo2 += $num['at2'];
            $tolo3 += $num['at3'];
            $tolo4 += $num['at4'];
            } 
    ?>

      <tr class="tr">
      <td>

    <table>
     <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
     </tr>
     <tr class="tr">
      <th class="stroke2" colspan="5"><?php echo $ju1;?></th>
    </tr>

      <tr>
      <th class="stroke2"></th>  
      <th class="stroke2"><img src="images/<?php echo  $p1;?>" class="img1"></th>
      <th class="stroke2"><img src="images/<?php echo  $p2;?>" class="img2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p3;?>" class="img3"></th>
      <th class="stroke2"><img src="images/<?php echo  $p4;?>" class="img4"></th>
    </tr>
    <tr class="tr">
      <th class="stroke2">Wave #</th>
      <th class="stroke2"><?php echo $n1;?></th>
      <th class="stroke2"><?php echo $n2;?></th>
      <th class="stroke2"><?php echo $n3;?></th>
      <th class="stroke2"><?php echo $n4;?></th>
      </tr>          
           
                <?php
                $queryo = "SELECT * FROM judge_one ORDER BY jsb_id ASC";
                $query_runo = mysqli_query($con,$queryo);

                while ($row = mysqli_fetch_assoc ($query_runo)){
                $wave3=$row['wavec'];
                $jso1=$row['at1'];
                $jso2=$row['at2'];
                $jso3=$row['at3'];
                $jso4=$row['at4'];
                ?>

     <tr class="tr">
      <td class="stroke2"><?php echo $wave3; ?></td>
      <td class="stroke2"><?php echo number_format($jso1,2); ?></td>
      <td class="stroke2"><?php echo number_format($jso2,2); ?></td>
      <td class="stroke2"><?php echo number_format($jso3,2); ?></td>
      <td class="stroke2"><?php echo number_format($jso4,2); ?></td>
      </tr>
      <?php }  ?>

      <tr class="tr">
      <td class="stroke2">Total Scores:</td>
      <td class="stroke2"><strong><u><?php echo number_format($tolo1,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolo2,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolo3,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolo4,2); ?></u></strong></td>
      </tr>
    </table>

  </td>



   <td>
    <table>
      <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
     </tr>
    <tr class="tr">
      <th class="stroke2" colspan="5"><?php echo $ju2;?></th>
    </tr>

     
      <tr class="tr">
      <th class="stroke2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p1;?>" class="img1"></th>
      <th class="stroke2"><img src="images/<?php echo  $p2;?>" class="img2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p3;?>" class="img3"></th>
      <th class="stroke2"><img src="images/<?php echo  $p4;?>" class="img4"></th>
      </tr>

      <tr>
      <th class="stroke2">Wave #</th>
      <th class="stroke2"><?php echo $n1;?></th>
      <th class="stroke2"><?php echo $n2;?></th>
      <th class="stroke2"><?php echo $n3;?></th>
      <th class="stroke2"><?php echo $n4;?></th>
    </tr>
      
               <?php
                $queryt = "SELECT * FROM judge_two ORDER BY jsb_id ASC";
                $query_runt = mysqli_query($con,$queryt);

                while ($row = mysqli_fetch_assoc ($query_runt)){
                $wave3=$row['wavec'];
                $jst1=$row['at1'];
                $jst2=$row['at2'];
                $jst3=$row['at3'];
                $jst4=$row['at4'];
                ?>
      <tr class="tr">
      <td class="stroke2"><?php echo $wave3; ?></td>   
      <td class="stroke2"><?php echo number_format($jst1,2); ?></td>
      <td class="stroke2"><?php echo number_format($jst2,2); ?></td>
      <td class="stroke2"><?php echo number_format($jst3,2); ?></td>
      <td class="stroke2"><?php echo number_format($jst4,2); ?></td>
    </tr>
               <?php }  ?>

      <tr class="tr">
      <td class="stroke2">Total Scores:</td>
      <td class="stroke2"><strong><u><?php echo number_format($tolt1,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolt2,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolt3,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolt4,2); ?></u></strong></td>
    </tr>
   </table>
     </td>
    </tr>
       

    <tr class="tr">
    <td>
    <table>
     <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
     </tr>
    <tr class="tr">
      <th class="stroke2" colspan="5"><?php echo $ju3;?></th>
    </tr>
    <tr class="tr">
      <th class="stroke2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p1;?>" class="img1"></th>
      <th class="stroke2"><img src="images/<?php echo  $p2;?>" class="img2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p3;?>" class="img3"></th>
      <th class="stroke2"><img src="images/<?php echo  $p4;?>" class="img4"></th>
      </tr>
    <tr class="tr">
      <th class="stroke2">Wave #</th>
      <th class="stroke2"><?php echo $n1;?></th>
      <th class="stroke2"><?php echo $n2;?></th>
      <th class="stroke2"><?php echo $n3;?></th>
      <th class="stroke2"><?php echo $n4;?></th>
      </tr>

               <?php
                $queryth = "SELECT * FROM judge_three ORDER BY jsb_id ASC";
                $query_runth = mysqli_query($con,$queryth);

                while ($row = mysqli_fetch_assoc ($query_runth)){
                $wave3=$row['wavec'];  
                $jsth1=$row['at1'];
                $jsth2=$row['at2'];
                $jsth3=$row['at3'];
                $jsth4=$row['at4'];
                ?>
                
    <tr class="tr">
      <td class="stroke2"><?php echo $wave3; ?></td>
      <td class="stroke2"><?php echo number_format($jsth1,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsth2,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsth3,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsth4,2); ?></td>
    <tr>
       <?php }  ?>
      <tr class="tr">
        <td class="stroke2">Total Scores:</td>
      <td class="stroke2"><strong><u><?php echo number_format($tolth1,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolth2,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolth3,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolth4,2); ?></u></strong></td>
      </tr>
      <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
     </tr>
      </table>
       </td>



    <td>
    <table>
    <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
    </tr>
    <tr class="tr">
      <th class="stroke2" colspan="5"><?php echo $ju4;?></th>
    </tr>  
    <tr class="tr">
      <th class="stroke2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p1;?>" class="img1"></th>
      <th class="stroke2"><img src="images/<?php echo  $p2;?>" class="img2"></th>
      <th class="stroke2"><img src="images/<?php echo  $p3;?>" class="img3"></th>
      <th class="stroke2"><img src="images/<?php echo  $p4;?>" class="img4"></th>
    </tr>   
    <tr class="tr">
      <th class="stroke2">Wave #</th>
      <th class="stroke2"><?php echo $n1;?></th>
      <th class="stroke2"><?php echo $n2;?></th>
      <th class="stroke2"><?php echo $n3;?></th>
      <th class="stroke2"><?php echo $n4;?></th>
    </tr>
               <?php
                $queryfo = "SELECT * FROM judge_four ORDER BY jsb_id ASC";
                $query_runfo = mysqli_query($con,$queryfo);

                while ($row = mysqli_fetch_assoc ($query_runfo)){
                $wave3=$row['wavec'];
                $jsfo1=$row['at1'];
                $jsfo2=$row['at2'];
                $jsfo3=$row['at3'];
                $jsfo4=$row['at4'];
                ?>
    <tr class="tr">
    <td class="stroke2"><?php echo $wave3; ?></td>        
      <td class="stroke2"><?php echo number_format($jsfo1,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsfo2,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsfo3,2); ?></td>
      <td class="stroke2"><?php echo number_format($jsfo4,2); ?></td>
    </tr>
    <?php }  ?>

      <tr>
      <td class="stroke2">Total Scores:</td>
      <td class="stroke2"><strong><u><?php echo number_format($tolfo1,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolfo2,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolfo3,2); ?></u></strong></td>
      <td class="stroke2"><strong><u><?php echo number_format($tolfo4,2); ?></u></strong></td>
    </tr>
    <tr class="tr">
      <th class="stroke2" colspan="9"><hr></th>
     </tr>

     </table>
     </td>
     </tr>

    <tr>
    <td class="stroke2" colspan="2">
    <table align="center">  
      <tr class="tr">
      <th class="stroke2" colspan="9"><?php echo $ju5;?></th>
     </tr>
      <tr class="tr">
      <th class="stroke2"></th>  
      <th class="stroke2" colspan="3"><img src="images/<?php echo  $p1;?>" class="img1"></th>
      <th class="stroke2" colspan="2"><img src="images/<?php echo  $p2;?>" class="img2"></th>
      <th class="stroke2" colspan="2"><img src="images/<?php echo  $p3;?>" class="img3"></th>
      <th class="stroke2" colspan="2"><img src="images/<?php echo  $p4;?>" class="img4"></th>
    </tr>
    <tr class="tr">
      <th class="stroke2">Wave #</th>
      <th class="stroke2" colspan="3"><?php echo $n1;?></th>
      <th class="stroke2" colspan="2"><?php echo $n2;?></th>
      <th class="stroke2" colspan="2"><?php echo $n3;?></th>
      <th class="stroke2" colspan="2"><?php echo $n4;?></th>
    </tr>

               <?php
                $queryfi = "SELECT * FROM judge_five ORDER BY jsb_id ASC";
                $query_runfi = mysqli_query($con,$queryfi);

                while ($row = mysqli_fetch_assoc ($query_runfi)){
                $wave3=$row['wavec'];
                $jsfi1=$row['at1'];
                $jsfi2=$row['at2'];
                $jsfi3=$row['at3'];
                $jsfi4=$row['at4'];
                ?>
     <tr>
      <td class="stroke2"><?php echo $wave3; ?></td> 
      <td class="stroke2" colspan="3"><?php echo number_format($jsfi1,1); ?></td>
      <td class="stroke2" colspan="2"><?php echo number_format($jsfi2,1); ?></td>
      <td class="stroke2" colspan="2"><?php echo number_format($jsfi3,1); ?></td>
      <td class="stroke2" colspan="2"><?php echo number_format($jsfi4,1); ?></td>
    </tr>
             <?php }  ?>
    <tr class="tr">
      <td class="stroke2">Total Scores:</td>
      <td class="stroke2" colspan="3"><strong><u><?php echo number_format($tolfi1,1); ?></u></strong></td>
      <td class="stroke2" colspan="2"><strong><u><?php echo number_format($tolfi2,1); ?></u></strong></td>
      <td class="stroke2" colspan="2"><strong><u><?php echo number_format($tolfi3,1); ?></u></strong></td>
      <td class="stroke2" colspan="2"><strong><u><?php echo number_format($tolfi4,1); ?></u></strong></td>
    </tr>
    <tr class="tr">
      <td class="stroke2" colspan="9"><hr></td>
     </tr>

     </table>
     </td>
     </tr>

   
    <tr class="tr">
      <td class="stroke1" colspan="9" style="padding: 15px;"></td>
    </tr>
    <tr>
      <td colspan="9" class="developer"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
    <tr class="tr">
      <td class="stroke1" colspan="9" style="padding-top:2px; border-radius: 0px 0px 20px 20px;"></td>
    </tr>

  </tbody>
</table>
</div>
</div>
      <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

    <?php 
if(isset($_POST['dm_delete'])){
$user = "id14326742_admin_sisaph"; 
$password = "S1@rg@0island"; 
$host = "localhost"; 
$database= "id14326742_admin_cms";

$connection= mysqli_connect ($host, $user, $password, $database);
if (!$connection)
{
die ('Could not connect:' . mysqli_error());
}


$truncatetable= mysqli_query($connection,"TRUNCATE TABLE data_monitoring");


if($truncatetable !== FALSE)
{?>

    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
               <script>
      swal({
  title: "All data have been deleted.",
  //text: "You clicked the button!",
  icon: "success",
  button: "ok",
         });
    window.location='/sisaph-judging/head-judge.php'</script>

<?php   
}
else
{
 
   echo "<script>alert('No data have been deleted.'); window.location='/sisaph-judging/head-judge.php'</script>";
}

}

?>

  </body>
</html>
