<?php
ob_start(); 
session_start(); 
require_once ("include/class.judge.php");//connection to database and public functions
require_once("include/database-con.php");//database connection
$judge = new judge();//connection to public User function



$result = mysqli_query($con,"select count(*) FROM judges_account WHERE ju_status = 'Online' ");
//----------fetch total numbers of online judges-----------//
$total = mysqli_fetch_array($result);



if (isset($_POST['submit'])) {  // posting data after submit button.
  extract($_POST); //extracting all data  from database.   
  $login = $judge->check_login($judge_name, $judge_password); // calling function verification process.
  
  if ($login && $total[0] == 6) {
               // Full users
    echo '<script>alert("The judges slot was full.")</script>';
  }else if ($login && $judge_name == 'judge1') {
          // Registration Success
    header("location:judge1.php");
   }else if ($login && $judge_name == 'judge2') {
          // Registration Success
    header("location:judge2.php");
    }else if ($login && $judge_name == 'judge3') {
          // Registration Success
    header("location:judge3.php"); 
    }else if ($login && $judge_name == 'judge4') {
          // Registration Success
    header("location:judge4.php"); 
    }else if ($login && $judge_name == 'judge5') {
          // Registration Success
    header("location:judge5.php"); 
    }else if ($login && $judge_name == 'hjudge') {
          // Registration Success
    header("location:head-judge.php"); 
  } else {
          // Registration Failed
    echo '<script>alert("Wrong username or password or your account is need for the admin approval.")</script>';
  }
}
ob_end_flush();
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/sisa-logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Judges Login Page</title>
    <style type="text/css">
      body {
  background-image: url("images/cloud-9.jpg");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  padding-top: 50px;
  padding-bottom: 50px;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
}

.content {
  max-width: 350px;
  margin: auto;
  background: white;
  padding: 20px;
  border-radius: 10px;
}
img {
  border-radius: 50%;
}
    </style>
  </head>
  <body>
    <div class="table-responsive content">
   <div class="container">
    <h4 align="center"><img src="images/sisa-logo.jpg" width="50" height="50"></h4>
    <h5 align="center">Log In</h5>
  <form action="" method="post" name="login" class="was-validated">
    <div class="form-group">
      <label for="uname">Username:</label>
      <input type="text" class="form-control" id="uname" placeholder="Enter username" name="judge_name" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="judge_password" required>
      <div class="valid-feedback">Valid.</div>
      <div class="invalid-feedback">Please fill out this field.</div>
    </div>
    <div class="form-group" align="center">
      <button type="submit" name="submit" class="btn btn-primary">Login</button>
    </div>
    <div class="form-group" align="center">
      <td colspan="7" class="developer"><a style="font-size:10px;color:#6495ED;" href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></div>
    </tr>
  </form>
</div>
</div>

        <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
    
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
    
  </body>
</html>