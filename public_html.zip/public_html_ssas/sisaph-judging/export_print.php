<?php
namespace sisaph;

use \sisaph\Results;
require_once ("class/results.php");

$product = new Results();
$productResult = $product->getAllProduct();

if (isset($_POST["export"])) {
    $product->exportProductDatabase($productResult);
}

require_once ("view/event-results.php");
?>