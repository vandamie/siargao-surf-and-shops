<?php 
ob_start();



      $con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");
      $que = "SELECT * FROM judges_data_form WHERE form_id = 1";
      $que_run = mysqli_query($con,$que);

      while ($res = mysqli_fetch_assoc($que_run)) {
            $logo = $res['logo'];
            $bgimg = $res['bg_img'];
            $co1 = $res['at_col_one'];
            $co2 = $res['at_col_two'];
            $co3 = $res['at_col_three'];
            $co4 = $res['at_col_four'];
            } 
            
ob_end_flush();
?>

<?php include ("include/event_result_con.php"); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SISA PH Event Results</title>
	<link rel="icon" type="image" href="images/<?php echo $logo; ?>">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style type="text/css">
  body {
  background-image: url("images/<?php echo $bgimg; ?>");
  background-repeat: no-repeat, repeat;
  background-size: cover;
  font-family: Arial, Helvetica, sans-serif;
  opacity: 0.9;
  filter: alpha(opacity=100); /* For IE8 and earlier */
  font-size:15px;
  padding-bottom: 40px;
  padding-top: 40px; 
}
.content {
  max-width: 1050px;
  margin: auto;
  background: white;
  border-radius: 35px;
  padding-top: 8px;
  padding-bottom: 8px;
  padding-left: 8px;
  padding-right:8px;

}

.img1 {
  border-radius: 50%;
  background:<?php echo $co1; ?>;
  padding: 3px; 
  width:70px;
  height:70px;  
}
.img2 {
  border-radius: 50%;
  background:<?php echo $co2; ?>;
  padding: 3px; 
  width:70px;
  height:70px;    
}
.img3 {
  border-radius: 50%;
  background:<?php echo $co3; ?>;
  padding: 3px; 
  width:70px;
  height:70px;   
}
.img4 {
  border-radius: 50%;
  background:<?php echo $co4; ?>;
  padding: 3px; 
  width:70px;
  height:70px;    
}
.carousel-control-prev-icon {
 background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%230000FF' viewBox='0 0 8 8'%3E%3Cpath d='M5.25 0l-4 4 4 4 1.5-1.5-2.5-2.5 2.5-2.5-1.5-1.5z'/%3E%3C/svg%3E") !important;
}

.carousel-control-next-icon {
  background-image: url("data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='%230000FF' viewBox='0 0 8 8'%3E%3Cpath d='M2.75 0l-1.5 1.5 2.5 2.5-2.5 2.5 1.5 1.5 4-4-4-4z'/%3E%3C/svg%3E") !important;
} 

th,td{
text-align: center;
}
    </style>
</head>
<body>
<div id="carouselExampleControls" class="carousel slide content" data-ride="carousel" data-interval="false">
<!---------------------------Mens Finals----------------------------------->
  <div class="carousel-inner">

    <div class="carousel-item active" align="center">
      <h3><?php echo $sta1; ?></h3>

      <div class="table-responsive content">
     <table class="table">
	  <thead>
	  	<tr>
	  	<th>Division</th>
		<th>Jersey Colors</th>
		<th>Names</th>
		<th>Scores</th>
	    </tr>
	  </thead>
	 <tbody>
        <tr>
        <td><?php echo $div1; ?></td>
		<td><img src="images/<?php echo $p1; ?>" class="img1"></td>
		<td><?php echo $at1; ?></td>
		<td><?php echo $f1; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $div1; ?></td>
		<td><img src="images/<?php echo $p2; ?>" class="img2"></td>
		<td><?php echo $at2; ?></td>
		<td><?php echo $f2; ?></td>
	    </tr>
	    	    <tr class="tr">
      <td class="stroke1" colspan="4" style="padding-top: 15px;"></td>
    </tr>
	   <tr class="tr">
      <td colspan="4" class="developer" style=" border-radius: 0px 0px 20px 20px; font-size:12px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
	 </tbody>
     </table>
     </div>

    </div>

    <div class="carousel-item" align="center">
      <h3><?php echo $sta2; ?></h3>

  <!--------------------------- Mens Semifinals----------------------------------->    

      <div class="table-responsive content">
     <table class="table">
	  <thead>
	  	<tr>
	  	<th>Division</th>
		<th>Jersey Colors</th>
		<th>Names</th>
		<th>Scores</th>
	    </tr>
	  </thead>
	 <tbody>
        <tr>
        <td><?php echo $div2; ?></td>
		<td><img src="images/<?php echo $pp1; ?>" class="img1"></td>
		<td><?php echo $att3; ?></td>
		<td><?php echo $ff3; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $div2; ?></td>
		<td><img src="images/<?php echo $pp2; ?>" class="img2"></td>
		<td><?php echo $att3; ?></td>
		<td><?php echo $ff3; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $div2; ?></td>
		<td><img src="images/<?php echo $pp3; ?>" class="img3"></td>
		<td><?php echo $att3; ?></td>
		<td><?php echo $ff3; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $div2; ?></td>	
		<td><img src="images/<?php echo $pp4; ?>" class="img4"></td>
		<td><?php echo $att3; ?></td>
		<td><?php echo $ff3; ?></td>
	    </tr>
	    	    <tr class="tr">
      <td class="stroke1" colspan="4" style="padding-top: 15px;"></td>
    </tr>
	   <tr class="tr">
      <td colspan="4" class="developer" style=" border-radius: 0px 0px 20px 20px; font-size:12px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
	 </tbody>
     </table>
     </div>

    </div>
<!--------------------------- Mens Quarterfinals----------------------------------->
<!-------------------------------------Mens Quaterfinals HEAT 1--------------------------->
    <div class="carousel-item" align="center">
      <h3><?php echo $qt_sta1; ?></h3>
      <h3><?php echo $ht_qt1; ?></h3>
       <div class="table-responsive content">
     <table class="table">
	  <thead>
	  	<tr>
	  	<th>Division</th>
		<th>Jersey Colors</th>
		<th>Names</th>
		<th>Scores</th>
	    </tr>
	  </thead>
	 <tbody>
        <tr>
        <td><?php echo $qt_div1; ?></td>
		<td><img src="images/<?php echo $qtp1; ?>" class="img1"></td>
		<td><?php echo $at_qt1; ?></td>
		<td><?php echo $f_qt1; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div1; ?></td>
		<td><img src="images/<?php echo $qtp2; ?>" class="img2"></td>
		<td><?php echo $at_qt2; ?></td>
		<td><?php echo $f_qt2; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div1; ?></td>
		<td><img src="images/<?php echo $qtp3; ?>" class="img3"></td>
		<td><?php echo $at_qt3; ?></td>
		<td><?php echo $f_qt3; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div1; ?></td>	
		<td><img src="images/<?php echo $qtp4; ?>" class="img4"></td>
		<td><?php echo $at_qt4; ?></td>
		<td><?php echo $f_qt4; ?></td>
	    </tr>
	 </tbody>
     </table>

<!-------------------------------------Mens Quaterfinals HEAT 2--------------------------------------------------->
     <h3><?php echo $ht_qt2; ?></h3>

       <div class="table-responsive content">
     <table class="table">
	  <thead>
	  	<tr>
	  	<th>Division</th>
		<th>Jersey Colors</th>
		<th>Names</th>
		<th>Scores</th>
	    </tr>
	  </thead>
	 <tbody>
        <tr>
        <td><?php echo $qt_div2; ?></td>
		<td><img src="images/<?php echo $p_qtp1; ?>" class="img1"></td>
		<td><?php echo $att_qt1; ?></td>
		<td><?php echo $ff_qt1; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div2; ?></td>
		<td><img src="images/<?php echo $p_qtp2; ?>" class="img2"></td>
		<td><?php echo $att_qt2; ?></td>
		<td><?php echo $ff_qt2; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div2; ?></td>
		<td><img src="images/<?php echo $p_qtp3; ?>" class="img3"></td>
		<td><?php echo $att_qt3; ?></td>
		<td><?php echo $ff_qt3; ?></td>
	    </tr>
	    <tr>
	    <td><?php echo $qt_div2; ?></td>	
		<td><img src="images/<?php echo $p_qtp4; ?>" class="img4"></td>
		<td><?php echo $att_qt4; ?></td>
		<td><?php echo $ff_qt4; ?></td>
	    </tr>
	    <tr class="tr">
      <td class="stroke1" colspan="4" style="padding-top: 15px;"></td>
    </tr>
	   <tr class="tr">
      <td colspan="4" class="developer" style=" border-radius: 0px 0px 20px 20px; font-size:12px;"><a href="https://web.facebook.com/wsp2021/">Developed by: Siargao Web Protocol v1.0</a></td>
    </tr>
	 </tbody>
     </table>
     </div>

    </div>

  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


            <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>