<?php
$con = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
?>