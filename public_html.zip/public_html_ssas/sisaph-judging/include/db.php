<?php 
$hostName = "localhost";
$dbName = "id14326742_admin_cms";
$userName = "root";
$password = "";

/*DEFINE ('DB_USER', 'id14326742_admin_sisaph');
DEFINE ('DB_PASSWORD', 'S1@rg@0island');  
DEFINE ('DB_HOST', 'localhost');
DEFINE ('DB_NAME', 'id14326742_admin_cms');

$link = @mysqli_connect (DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) 
OR die("could not connect");*/


try {
    $conn = new PDO("mysqli:host=$hostName;dbname=$dbName",$userName,$password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch(PDOException $e)
    {
     echo "Connection failed: " . $e->getMessage();
    }
?>