<?php
require_once("database-con.php");
require_once("con-data-link.php");

$do1 = addslashes($link_div1);
$result1 = mysqli_query($con,"select count(og_division) FROM organize_event WHERE og_division = '$do1'");
$total1 = mysqli_fetch_array($result1);

$do2 = addslashes($link_div2);
$result2 = mysqli_query($con,"select count(og_division) FROM organize_event WHERE og_division = '$do2'");
$total2 = mysqli_fetch_array($result2);

$do3 = addslashes($link_div3);
$result3 = mysqli_query($con,"select count(og_division) FROM organize_event WHERE og_division = '$do3'");
$total3 = mysqli_fetch_array($result3);

$do4 = addslashes($link_div4);
$result4 = mysqli_query($con,"select count(og_division) FROM organize_event WHERE og_division = '$do4'");
$total4 = mysqli_fetch_array($result4);

$do5 = addslashes($link_div5);
$result5 = mysqli_query($con,"select count(og_division) FROM organize_event WHERE og_division = '$do5'");
$total5 = mysqli_fetch_array($result5);
?>