    
<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Men's Open Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->

    <?php
    ob_start();
      $con1 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que1 = "SELECT p1,p2,p3,p4,division,stage,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Mens Open' AND stage = 'Finals' LIMIT 2";
      $que_run1 = mysqli_query($con1,$que1);

      $p1 ="";
      $p2 ="";
      $p3 ="";
      $p4 ="";
      $sta1 ="";
      $div1 ="";
      $at1 ="";
      $at2 ="";
      $at3 ="";
      $at4 ="";
      $f1 = "";
      $f2 = "";
      $f3 = "";
      $f4 = "";

      while ($res1 = mysqli_fetch_assoc($que_run1)) {
            $p1 = $res1['p1'];
            $p2 = $res1['p2'];
            $p3 = $res1['p3'];
            $p4 = $res1['p4'];
            $div1 = $res1['division'];
            $sta1 = $res1['stage'];
            $at1 = $res1['at1'];
            $at2 = $res1['at2'];
            $at3 = $res1['at3'];
            $at4 = $res1['at4'];
            $f1 = $res1['final1'];
            $f2 = $res1['final2'];
            $f3 = $res1['final3'];
            $f4 = $res1['final4'];
            } 
    ?>

    <?php
      $con2 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que2 = "SELECT p1,p2,p3,p4,division,stage,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Mens Open' AND stage = 'Semifinals' LIMIT 4";
      $que_run2 = mysqli_query($con2,$que2);

      $pp1 ="";
      $pp2 ="";
      $pp3 ="";
      $pp4 ="";
      $sta2 ="";
      $div2 ="";
      $att1 ="";
      $att2 ="";
      $att3 ="";
      $att4 ="";
      $ff1 = "";
      $ff2 = "";
      $ff3 = "";
      $ff4 = "";

      while ($res2 = mysqli_fetch_assoc($que_run2)) {
            $pp1 = $res2['p1'];
            $pp2 = $res2['p2'];
            $pp3 = $res2['p3'];
            $pp4 = $res2['p4'];
            $div2 = $res2['division'];
            $sta2 = $res2['stage'];
            $att1 = $res2['at1'];
            $att2 = $res2['at2'];
            $att3 = $res2['at3'];
            $att4 = $res2['at4'];
            $ff1 = $res2['final1'];
            $ff2 = $res2['final2'];
            $ff3 = $res2['final3'];
            $ff4 = $res2['final4'];
            } 
    ?>
<!-----------------------------------Mens Quarterfinals Heat 1--------------------------------------------->
    <?php
      $con3 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que3 = "SELECT p1,p2,p3,p4,division,stage,heats,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Mens Open' AND stage = 'Quarterfinals' AND heats ='Heat 1' LIMIT 4";
      $que_run3 = mysqli_query($con3,$que3);

      $qtp1 ="";
      $qtp2 ="";
      $qtp3 ="";
      $qtp4 ="";
      $qt_sta1 ="";
      $qt_div1 ="";
      $at_qt1 ="";
      $at_qt2 ="";
      $at_qt3 ="";
      $at_qt4 ="";
      $f_qt1 = "";
      $f_qt2 = "";
      $f_qt3 = "";
      $f_qt4 = "";
      $ht_qt1 = "";

      while ($res3 = mysqli_fetch_assoc($que_run3)) {
            $qtp1 = $res3['p1'];
            $qtp2 = $res3['p2'];
            $qtp3 = $res3['p3'];
            $qtp4 = $res3['p4'];
            $qt_div1 = $res3['division'];
            $qt_sta1 = $res3['stage'];
            $at_qt1 = $res3['at1'];
            $at_qt2 = $res3['at2'];
            $at_qt3 = $res3['at3'];
            $at_qt4 = $res3['at4'];
            $f_qt1 = $res3['final1'];
            $f_qt2 = $res3['final2'];
            $f_qt3 = $res3['final3'];
            $f_qt4 = $res3['final4'];
            $ht_qt1= $res3['heats'];
            } 
    ?>

<!-----------------------------------Mens Quarterfinals Heat 2--------------------------------------------->
        <?php
      $con4 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que4 = "SELECT p1,p2,p3,p4,division,stage,heats,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Mens Open' AND stage = 'Quarterfinals' AND heats = 'Heat 2'  LIMIT 4";
      $que_run4 = mysqli_query($con4,$que4);

            $p_qtp1 = "";
            $p_qtp2 = "";
            $p_qtp3 = "";
            $p_qtp4 = "";
            $qt_div2 = "";
            $qt_sta2 = "";
            $att_qt1 = "";
            $att_qt2 = "";
            $att_qt3 = "";
            $att_qt4 = "";
            $ff_qt1 = "";
            $ff_qt2 = "";
            $ff_qt3 = "";
            $ff_qt4 = "";;
            $ht_qt2 = "";

      while ($res4 = mysqli_fetch_assoc($que_run4)) {
            $p_qtp1 = $res4['p1'];
            $p_qtp2 = $res4['p2'];
            $p_qtp3 = $res4['p3'];
            $p_qtp4 = $res4['p4'];
            $qt_div2 = $res4['division'];
            $qt_sta2 = $res4['stage'];
            $att_qt1 = $res4['at1'];
            $att_qt2 = $res4['at2'];
            $att_qt3 = $res4['at3'];
            $att_qt4 = $res4['at4'];
            $ff_qt1 = $res4['final1'];
            $ff_qt2 = $res4['final2'];
            $ff_qt3 = $res4['final3'];
            $ff_qt4 = $res4['final4'];
            $ht_qt2 = $res4['heats'];
            } 
    ?>



<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Women's Open Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->

        <?php
      $con3 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que3 = "SELECT p1,p2,p3,p4,division,stage,heats,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Womens Open' AND stage = 'Finals' AND heats = 'Heat 2'";
      $que_run3 = mysqli_query($con3,$que3);

      $ppp1 ="";
      $ppp2 ="";
      $ppp3 ="";
      $ppp4 ="";
      $sta3 ="";
      $div3 ="";
      $attt1 ="";
      $attt2 ="";
      $attt3 ="";
      $attt4 ="";
      $fff1 = "";
      $fff2 = "";
      $fff3 = "";
      $fff4 = "";

      while ($res3 = mysqli_fetch_assoc($que_run3)) {
            $ppp1 = $res3['p1'];
            $ppp2 = $res3['p2'];
            $ppp3 = $res3['p3'];
            $ppp4 = $res3['p4'];
            $div3 = $res3['division'];
            $sta3 = $res3['stage'];
            $attt1 = $res3['at1'];
            $attt2 = $res3['at2'];
            $attt3 = $res3['at3'];
            $attt4 = $res3['at4'];
            $fff1 = $res3['final1'];
            $fff2 = $res3['final2'];
            $fff3 = $res3['final3'];
            $fff4 = $res3['final4'];
            } 
    ?>


          <?php
      $con3 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que3 = "SELECT p1,p2,p3,p4,division,stage,heats,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Womens Open' AND stage = 'Semifinals' AND heats = 'Heat 2' ";
      $que_run3 = mysqli_query($con3,$que3);

      $ppp1 ="";
      $ppp2 ="";
      $ppp3 ="";
      $ppp4 ="";
      $sta3 ="";
      $div3 ="";
      $attt1 ="";
      $attt2 ="";
      $attt3 ="";
      $attt4 ="";
      $fff1 = "";
      $fff2 = "";
      $fff3 = "";
      $fff4 = "";

      while ($res3 = mysqli_fetch_assoc($que_run3)) {
            $ppp1 = $res3['p1'];
            $ppp2 = $res3['p2'];
            $ppp3 = $res3['p3'];
            $ppp4 = $res3['p4'];
            $div3 = $res3['division'];
            $sta3 = $res3['stage'];
            $attt1 = $res3['at1'];
            $attt2 = $res3['at2'];
            $attt3 = $res3['at3'];
            $attt4 = $res3['at4'];
            $fff1 = $res3['final1'];
            $fff2 = $res3['final2'];
            $fff3 = $res3['final3'];
            $fff4 = $res3['final4'];
            } 
    ?>


        <?php
      $con3 = mysqli_connect("localhost", "root", "", "id14326742_admin_cms");
      $que3 = "SELECT p1,p2,p3,p4,division,stage,at1,at2,at3,at4,final1,final2,final3,final4 FROM sisaph_event_results WHERE division = 'Womens Open' AND stage = 'Quarterfinals' ";
      $que_run3 = mysqli_query($con3,$que3);

      $ppp1 ="";
      $ppp2 ="";
      $ppp3 ="";
      $ppp4 ="";
      $sta3 ="";
      $div3 ="";
      $attt1 ="";
      $attt2 ="";
      $attt3 ="";
      $attt4 ="";
      $fff1 = "";
      $fff2 = "";
      $fff3 = "";
      $fff4 = "";

      while ($res3 = mysqli_fetch_assoc($que_run3)) {
            $ppp1 = $res3['p1'];
            $ppp2 = $res3['p2'];
            $ppp3 = $res3['p3'];
            $ppp4 = $res3['p4'];
            $div3 = $res3['division'];
            $sta3 = $res3['stage'];
            $attt1 = $res3['at1'];
            $attt2 = $res3['at2'];
            $attt3 = $res3['at3'];
            $attt4 = $res3['at4'];
            $fff1 = $res3['final1'];
            $fff2 = $res3['final2'];
            $fff3 = $res3['final3'];
            $fff4 = $res3['final4'];
            } 

       ob_end_flush();     
    ?>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Cloud 9 Master's Open Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->










<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Airborne Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->










<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Grommet Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->









<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Men's Longboard Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->








<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// Women's Longboard Devision//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->