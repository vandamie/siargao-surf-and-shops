<!---------------------DIVISION LINK DATA--------------------------->
      <?php
      $query_all = "SELECT * FROM data_link";
      $query_run_all = mysqli_query($con,$query_all);

      while ($res = mysqli_fetch_assoc ($query_run_all)) {
            $link_div1 = $res['link_div1'];
            $link_div2 = $res['link_div2'];
            $link_div3 = $res['link_div3'];
            $link_div4 = $res['link_div4'];
            $link_div5 = $res['link_div5'];
            }
       ?>