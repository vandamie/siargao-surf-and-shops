<?php
ob_start();
include ("db_config.php");
class Validation 
{
        protected $db;
	    public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
}
	public function check_empty($data, $fields)
	{
		$msg = null;
		foreach ($fields as $value) {
			if (empty($data[$value])) {
				$msg .= "$value field empty <br />";
			}
		} 
		return $msg;
	}
	

}
ob_end_flush();	
?>
