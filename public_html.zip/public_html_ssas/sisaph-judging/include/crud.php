<?php
ob_start();
include_once 'dbcons.php'; // database connection

class Crud extends DbCons // calling crud class and database class
{
	public function __construct()
	{
		parent::__construct();
	}
	    // function for confirmation if database was connected or not
	public function getdata($query)
	{		
		$result = $this->connection->query($query);
		
		if ($result == false) {
			return false;
		} 
		
		$rows = array();
		
		while ($row = $result->fetch_assoc()) {
			$rows[] = $row;
		}
		
		return $rows;
	}
	     // function for execution database connection	
	public function execute($query) 
	{
		$result = $this->connection->query($query);
		
		if ($result == false) {
			echo 'Error: cannot execute the command';
			return false;
		} else {
			return true;
		}		
	}



// accepting all data format of images
public	function is_image($img_one,$img_two,$img_three,$img_four)
{
	$a = getimagesize($img_one,$img_two,$img_three,$img_four);
	$image_type = $a[2];
	
	if(in_array($image_type , array(IMAGETYPE_GIF , IMAGETYPE_JPEG ,IMAGETYPE_PNG , IMAGETYPE_BMP)))
	{
		return true;
	}
	return false;
}

	    // function for delete data
	public function event_delete($id, $table) 
	{ 
		$query = "DELETE FROM $table WHERE ad_id = $id";
		
		$result = $this->connection->query($query);
	
		if ($result == false) {
			echo 'Error: cannot delete id ' . $id . ' from table ' . $table;
			return false;
		} else {
			return true;
		}
	}

           
	   // accepting all data format
	public function escape_string($value)
	{
		return $this->connection->real_escape_string($value);
	}
}
ob_end_flush();
?>
