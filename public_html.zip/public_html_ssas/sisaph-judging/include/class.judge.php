<?php
error_reporting(E_ALL);
require_once("db_config.php");
class judge{
	protected $db;
	public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
	}
	
	  //-------------------UPDATE LINK NAME AT ORGANIZE EVENT DATA----------------------// 
//---------------------------------------------------// 
public function update_link($li_div1,$li_div2,$li_div3,$li_div4,$li_div5){
date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");  
$get_id = $_REQUEST['link_id'];
$li_div1 = addslashes($li_div1);
$li_div2 = addslashes($li_div2);
$li_div3 = addslashes($li_div3);
$li_div4 = addslashes($li_div4);
$li_div5 = addslashes($li_div5);
if(is_string($li_div1) && is_string($li_div2) && is_string($li_div3) && is_string($li_div4) && is_string($li_div5)){
    
            $query = "UPDATE data_link SET link_div1='$li_div1',link_div2='$li_div2',link_div3='$li_div3',link_div4='$li_div4',link_div5='$li_div5',date_time='$todays_date' WHERE link_id ='$get_id'";
        $result = $this->db->query($query) or die($this->db->error);

    return true;
  }else{

    return false;
  }

}
	
	    /*** CREATING EVENT DATA***/
   //---------------------------------------------------//
  public function reg_og($date,$div1,$st1,$ht1,$og_jc1,$og_jc2,$og_jc3,$og_jc4,$og_at1,$og_at2,$og_at3,$og_at4){
      date_default_timezone_set('Asia/Manila');
      //$todays_date = date("M. d, Y");
        //$time_registered = strtotime($todays_date);
      $div1 = addslashes($div1);
         
    if(is_string($div1) && is_string($st1) && is_string($ht1) && is_string($og_jc1) && is_string($og_at1)){
      $query = "INSERT INTO organize_event SET og_date='$date',og_division='$div1',og_stage='$st1',og_heat='$ht1',og_jc1='$og_jc1',og_jc2='$og_jc2',og_jc3='$og_jc3',og_jc4='$og_jc4',og_at1='$og_at1',og_at2='$og_at2',og_at3='$og_at3',og_at4='$og_at4'";
       $result = $this->db->query($query) or die($this->db->error);

           return true; 
      
    }else{

                // adding failed
           return false; 
    }  
    }

//-------------------EDITING EVENT DATA----------------------// 
//---------------------------------------------------// 
public function edit_og($date,$div1,$st1,$ht1,$og_jc1,$og_jc2,$og_jc3,$og_jc4,$og_at1,$og_at2,$og_at3,$og_at4){
date_default_timezone_set('Asia/Manila');
//$todays_date = date("M. d, Y");  
$get_id = $_REQUEST['og_id'];
$div1 = addslashes($div1);
if(is_string($div1) && is_string($st1) && is_string($ht1) && is_string($og_jc1) && is_string($og_at1)){
    
            $query = "UPDATE organize_event SET og_date='$date',og_division='$div1',og_stage='$st1',og_heat='$ht1',og_jc1='$og_jc1',og_jc2='$og_jc2',og_jc3='$og_jc3',og_jc4='$og_jc4',og_at1='$og_at1',og_at2='$og_at2',og_at3='$og_at3',og_at4='$og_at4' WHERE og_id ='$get_id'";
        $result = $this->db->query($query) or die($this->db->error);

    return true;
  }else{

    return false;
  }

}

    /*** UP NEXT DATA***/
   //---------------------------------------------------//
  public function reg_upnext($div1,$st1,$ht1,$un_jc1,$un_jc2,$un_jc3,$un_jc4,$un_at1,$un_at2,$un_at3,$un_at4){
      date_default_timezone_set('Asia/Manila');
      $todays_date = date("M. d, Y");
        //$time_registered = strtotime($todays_date);
      $div1 = addslashes($div1);
         
    if(is_string($div1) && is_string($st1) && is_string($ht1) && is_string($un_jc1) && is_string($un_at1)){
      $query = "INSERT INTO upnext SET un_date='$todays_date', un_division='$div1', un_stage='$st1', un_heat='$ht1', un_jc1='$un_jc1', un_jc2='$un_jc2', un_jc3='$un_jc3',un_jc4='$un_jc4',un_at1='$un_at1',un_at2='$un_at2',un_at3='$un_at3',un_at4='$un_at4'";
       $result = $this->db->query($query) or die($this->db->error);

           return true; 
      
    }else{

                // adding failed
           return false; 
    }
      
      
    }

//-------------------RESET UPNEXT DATA----------------------// 
//---------------------------------------------------// 
public function reset_upnext($div1){
date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y");  
$get_id = $_REQUEST['un_id'];
if(is_string($div1)){
    
            $query = "UPDATE upnext SET un_date='$todays_date', un_division='<i>updating...</i>', un_stage='<i>updating...</i>', un_heat='<i>updating...</i>', un_jc1='<i>updating...</i>', un_jc2='<i>updating...</i>', un_jc3='<i>updating...</i>',un_jc4='<i>updating...</i>',un_at1='<i>updating...</i>',un_at2='<i>updating...</i>',un_at3='<i>updating...</i>',un_at4='<i>updating...</i>' WHERE un_id ='$get_id'";
        $result = $this->db->query($query) or die($this->db->error);

    return true;
  }else{

    return false;
  }

}

//-------------------EDIT UPNEXT DATA----------------------// 
//---------------------------------------------------// 
public function edit_upnext($div1,$st1,$ht1,$un_jc1,$un_jc2,$un_jc3,$un_jc4,$un_at1,$un_at2,$un_at3,$un_at4){
date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y");  
$get_id = $_REQUEST['un_id'];
$div1 = addslashes($div1);
if(is_string($div1) && is_string($st1) && is_string($ht1) && is_string($un_jc1) && is_string($un_at1)){
    
            $query = "UPDATE upnext SET un_date='$todays_date', un_division='$div1', un_stage='$st1', un_heat='$ht1', un_jc1='$un_jc1', un_jc2='$un_jc2', un_jc3='$un_jc3',un_jc4='$un_jc4',un_at1='$un_at1',un_at2='$un_at2',un_at3='$un_at3',un_at4='$un_at4' WHERE un_id ='$get_id'";
        $result = $this->db->query($query) or die($this->db->error);

    return true;
  }else{

    return false;
  }

}
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    Editting for judges form data and scores/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
/*** for judge one editing process for score of athlete one and updating score of viewers ***/

 public function edit_scores_j1($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");
$get_id = $_REQUEST['jsb_id'];
$dm_act = "was changed his/her scores into";

if($s1 <= 10 && $s2 <= 10 && $s3 <= 10 && $s4 <= 10 && is_numeric($s1) && is_numeric($s2) && is_numeric($s3) && is_numeric($s4)){
    
            $query = "UPDATE judge_one SET  at1 ='$s1', at2 = '$s2', at3 = '$s3', at4 = '$s4',event_date_time='$todays_date'  WHERE jsb_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error);

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error);  

		return true;
	}else{

		return false;
	}

}

/*** for judge two editing process for score of athlete one and updating score of viewers ***/

 public function edit_scores_j2($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");	
$get_id = $_REQUEST['jsb_id'];
$dm_act = "was changed his/her scores into";

if($s1 <= 10 && $s2 <= 10 && $s3 <= 10 && $s4 <= 10 && is_numeric($s1) && is_numeric($s2) && is_numeric($s3) && is_numeric($s4)){
    
            $query = "UPDATE judge_two SET at1 ='$s1', at2 = '$s2', at3 = '$s3', at4 = '$s4',event_date_time='$todays_date'  WHERE jsb_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error);

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error);  

		return true;
	}else{

		return false;
	}

}


/*** for judge three editing process for score of athlete one and updating score of viewers ***/

 public function edit_scores_j3($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");	
$get_id = $_REQUEST['jsb_id'];
$dm_act = "was changed his/her scores into";

if($s1 <= 10 && $s2 <= 10 && $s3 <= 10 && $s4 <= 10 && is_numeric($s1) && is_numeric($s2) && is_numeric($s3) && is_numeric($s4)){
    
            $query = "UPDATE judge_three SET at1 ='$s1', at2 = '$s2', at3 = '$s3', at4 = '$s4',event_date_time='$todays_date'  WHERE jsb_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error); 

		return true;
	}else{

		return false;
	}

}

/*** for judge four editing process for score of athlete one and updating score of viewers ***/

 public function edit_scores_j4($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");	
$get_id = $_REQUEST['jsb_id'];
$dm_act = "was changed his/her scores into";

if($s1 <= 10 && $s2 <= 10 && $s3 <= 10 && $s4 <= 10 && is_numeric($s1) && is_numeric($s2) && is_numeric($s3) && is_numeric($s4)){
    
            $query = "UPDATE judge_four SET at1 ='$s1', at2 = '$s2', at3 = '$s3', at4 = '$s4',event_date_time='$todays_date'  WHERE jsb_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error); 

		return true;
	}else{

		return false;
	}

}


/*** for judge four editing process for score of athlete one and updating score of viewers ***/

 public function edit_scores_j5($dm_wave,$dm_ju_n,$s1,$s2,$s3,$s4,$n1,$n2,$n3,$n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");	
$get_id = $_REQUEST['jsb_id'];
$dm_act = "was changed his/her scores into";

if($s1 <= 10 && $s2 <= 10 && $s3 <= 10 && $s4 <= 10 && is_numeric($s1) && is_numeric($s2) && is_numeric($s3) && is_numeric($s4)){
    
            $query = "UPDATE judge_five SET at1 ='$s1', at2 = '$s2', at3 = '$s3', at4 = '$s4',event_date_time='$todays_date'  WHERE jsb_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

        //-------------------Data Monitoring UPDATE DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1 ='$n1',dm_at2 ='$n2',dm_at3 ='$n3',dm_at4 ='$n4', score1='$s1', score2='$s2', score3='$s3', score4='$s4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error); 

		return true;
	}else{

		return false;
	}

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////Editting Data Form of judge1/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
/*** for judge one editing process for logo on the form ***/

 public function edit_logo($j1logo1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("M. d, Y, h:i:s a");	
$get_id = $_REQUEST['form_id'];
 
 $imgFile1 = $_FILES['j1logo1']['name'];
 $tmp_dir1 = $_FILES['j1logo1']['tmp_name'];
 $imgSize1 = $_FILES['j1logo1']['size'];

// make a note of the directory that will recieve the uploaded file 
$upload_dir = '/storage/ssd1/742/14326742/public_html/sisaph-judging/images/';
//$upload_dir = 'C:/wamp64/www/sisaph-judging/images/'; 

   $imgExt1 = strtolower(pathinfo($imgFile1,PATHINFO_EXTENSION)); // get image extension
  
   // valid image extensions
   $valid_extensions1 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
  
   // rename uploading image
   $j1logo1 = rand(1000,1000000).".".$imgExt1;
    
   // allow valid image file formats
   if(in_array($imgExt1, $valid_extensions1)){
   // Check file size '5MB'
    if($imgSize1 < 5000000)    {   
     move_uploaded_file($tmp_dir1,$upload_dir.$j1logo1);

        /*$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE judges_data_form SET at_img_one ='$img1',at_img_two ='$img2',at_img_three ='$img3',at_img_four ='$img4', date_time='$todays_date' WHERE form_id = 1 ";
        $conn->exec($sql);*/
        $query = "UPDATE judges_data_form SET logo ='$j1logo1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error);
         return true;

        }else{
     //echo "<script>alert('Sorry, your file is too large.'); window.location='/sisaph-judging/judge1.php'</script>";
     return false;
    }

   }else{
    //echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.'); window.location='/sisaph-judging/judge1.php'</script>";
    return false;  
   }

}


/*** for judge one editing process for judge name on the form ***/

 public function edit_title($j1header1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");  
$get_id = $_REQUEST['form_id'];

    
            $query = "UPDATE judges_data_form SET event_title ='$j1header1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

    return true;

}


/*** for judge one editing process for judge name on the form ***/

 public function edit_judge_n($j1name1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1name1 = addslashes($j1name1);

    
            $query = "UPDATE judges_data_form SET ju_name ='$j1name1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;

}

/*** for judge one editing process for date on the form ***/

 public function edit_date($j1date1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1date1 = addslashes($j1date1);
    
            $query = "UPDATE judges_data_form SET date_time ='$j1date1'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;

}


/*** for judge one editing process for division on the form ***/

 public function edit_division($j1div1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1div1 = addslashes($j1div1);
    
            $query = "UPDATE judges_data_form SET at_division ='$j1div1',date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;

}

/*** for judge one editing process for stage on the form ***/

 public function edit_stage($j1st1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1div1 = addslashes($j1st1);
    
            $query = "UPDATE judges_data_form SET at_stage ='$j1st1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;

}

/*** for judge one editing process for heat on the form ***/

 public function edit_heat($j1ht1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1ht1 = addslashes($j1ht1);
    
            $query = "UPDATE judges_data_form SET at_heat ='$j1ht1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;

}


/*** for judge one editing process for jersey colors on the form ***/

 public function edit_jersey_col($j1col1,$j1col2,$j1col3,$j1col4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1col1 = addslashes($j1col1);
$j1col2 = addslashes($j1col2);
$j1col3 = addslashes($j1col3);
$j1col4 = addslashes($j1col4);

            $query = "UPDATE judges_data_form SET at_col_one ='$j1col1', at_col_two = '$j1col2', at_col_three = '$j1col3', at_col_four = '$j1col4',date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 

		return true;
}

/*** for judge one editing process for images on the form ***/
 public function edit_at_images($j1img1,$j1img2,$j1img3,$j1img4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];

 $imgFile1 = $_FILES['j1img1']['name'];
 $tmp_dir1 = $_FILES['j1img1']['tmp_name'];
 $imgSize1 = $_FILES['j1img1']['size'];

 $imgFile2 = $_FILES['j1img2']['name'];
 $tmp_dir2 = $_FILES['j1img2']['tmp_name'];
 $imgSize2 = $_FILES['j1img2']['size'];

 $imgFile3 = $_FILES['j1img3']['name'];
 $tmp_dir3 = $_FILES['j1img3']['tmp_name'];
 $imgSize3 = $_FILES['j1img3']['size'];

 $imgFile4 = $_FILES['j1img4']['name'];
 $tmp_dir4 = $_FILES['j1img4']['tmp_name'];
 $imgSize4 = $_FILES['j1img4']['size'];



// make a note of the directory that will recieve the uploaded file 
$upload_dir = '/storage/ssd1/742/14326742/public_html/sisaph-judging/images/';
//$upload_dir = 'C:/wamp64/www/sisaph-judging/images/'; 

   $imgExt1 = strtolower(pathinfo($imgFile1,PATHINFO_EXTENSION)); // get image extension
   $imgExt2 = strtolower(pathinfo($imgFile2,PATHINFO_EXTENSION)); // get image extension
   $imgExt3 = strtolower(pathinfo($imgFile3,PATHINFO_EXTENSION)); // get image extension
   $imgExt4 = strtolower(pathinfo($imgFile4,PATHINFO_EXTENSION)); // get image extension
  
   // valid image extensions
   $valid_extensions1 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
   $valid_extensions2 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
   $valid_extensions3 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
   $valid_extensions4 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
  
   // rename uploading image
   $j1img1 = rand(1000,1000000).".".$imgExt1;
   $j1img2 = rand(1000,1000000).".".$imgExt2;
   $j1img3 = rand(1000,1000000).".".$imgExt3;
   $j1img4 = rand(1000,1000000).".".$imgExt4;
    
   // allow valid image file formats
   if(in_array($imgExt1, $valid_extensions1) && in_array($imgExt2, $valid_extensions2) && in_array($imgExt3, $valid_extensions3) && in_array($imgExt4, $valid_extensions4)){
   // Check file size '5MB'
    if($imgSize1 < 5000000 && $imgSize2 < 5000000 && $imgSize3 < 5000000 && $imgSize4 < 5000000)    {   
     move_uploaded_file($tmp_dir1,$upload_dir.$j1img1);
     move_uploaded_file($tmp_dir2,$upload_dir.$j1img2);
     move_uploaded_file($tmp_dir3,$upload_dir.$j1img3);
     move_uploaded_file($tmp_dir4,$upload_dir.$j1img4);

        /*$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE judges_data_form SET at_img_one ='$img1',at_img_two ='$img2',at_img_three ='$img3',at_img_four ='$img4', date_time='$todays_date' WHERE form_id = 1 ";
        $conn->exec($sql);*/
        $query = "UPDATE judges_data_form SET at_img_one ='$j1img1', at_img_two = '$j1img2', at_img_three = '$j1img3', at_img_four = '$j1img4', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 
         return true;

        }else{
     //echo "<script>alert('Sorry, your file is too large.'); window.location='/sisaph-judging/judge1.php'</script>";
     return false;
    }

   }else{
    //echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.'); window.location='/sisaph-judging/judge1.php'</script>";
    return false;  
   }

}

/*** for judge one editing process for names on the form ***/
 public function edit_at_names($j1n1,$j1n2,$j1n3,$j1n4){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");	
$get_id = $_REQUEST['form_id'];
$j1n1 = addslashes($j1n1);
$j1n2 = addslashes($j1n2);
$j1n3 = addslashes($j1n3);
$j1n4 = addslashes($j1n4);
    
        $query = "UPDATE judges_data_form SET at_one ='$j1n1', at_two = '$j1n2', at_three = '$j1n3', at_four = '$j1n4',date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error); 
     return true;
}

/*** for judge one editing process for background image on the form ***/
 public function edit_bg($bg1){

date_default_timezone_set('Asia/Manila');
$todays_date = date("y-m-d h:i:sa");
$get_id = $_REQUEST['form_id'];	

 $imgFile1 = $_FILES['bg1']['name'];
 $tmp_dir1 = $_FILES['bg1']['tmp_name'];
 $imgSize1 = $_FILES['bg1']['size'];


// make a note of the directory that will recieve the uploaded file 
$upload_dir = '/storage/ssd1/742/14326742/public_html/sisaph-judging/images/';
//$upload_dir = 'C:/wamp64/www/sisaph-judging/images/'; 

   $imgExt1 = strtolower(pathinfo($imgFile1,PATHINFO_EXTENSION)); // get image extension
  
   // valid image extensions
   $valid_extensions1 = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
  
   // rename uploading image
   $bg1 = rand(1000,1000000).".".$imgExt1;
    
   // allow valid image file formats
   if(in_array($imgExt1, $valid_extensions1)){
   // Check file size '5MB'
    if($imgSize1 < 5000000)    {   
     move_uploaded_file($tmp_dir1,$upload_dir.$bg1);

        /*$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "UPDATE judges_data_form SET at_img_one ='$img1',at_img_two ='$img2',at_img_three ='$img3',at_img_four ='$img4', date_time='$todays_date' WHERE form_id = 1 ";
        $conn->exec($sql);*/
        $query = "UPDATE judges_data_form SET bg_img ='$bg1', date_time='$todays_date'  WHERE form_id = '$get_id' ";
        $result = $this->db->query($query) or die($this->db->error);
         return true;

        }else{
     //echo "<script>alert('Sorry, your file is too large.'); window.location='/sisaph-judging/judge1.php'</script>";
        return false;
    }

   }else{
    //echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.'); window.location='/sisaph-judging/judge1.php'</script>";
    return false;  
   }
}

//////////////////////////////////////////////////////////////////////////////////
/*** for SISA PH events editing process***/
/////////////////////////////////////////////////////////////////////////////
 public function editting_events($en,$ep,$ca,$es,$esd,$eed,$ey,$em,$npe){
		date_default_timezone_set('Asia/Manila');
        //$todays_date = date("M. d, Y");
        //$todays_year = date("Y");
        $get_id = $_REQUEST['ad_id'];
        $en = addslashes($en);
        $es = addslashes($es);
        $esd = addslashes($esd);
        $eed = addslashes($eed);
        $ey = addslashes($ey);
        $em = addslashes($em);
        $te = date("h:i:sa");
        $ts = date("h:i:sa");
        $npe = addslashes($npe);

             if(is_numeric($ep)){
			$result = "UPDATE adding_events SET event_name='$en' event_points='$ep', event_address='$ca',event_status='$es',event_year='$ey',event_month='$em',event_start_d='$esd',event_end_d='$eed',time_edited='not yet', time_saved='$ts',name_p_edited='$npe' WHERE ad_id = '$get_id'";
            $result = $this->db->query($result) or die($this->db->error);

			return true;
			}else{
				return false;
			}

}


//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////FUNCTIONS FOR ADDING AND RESETTING SCORES AND DATA FOR JUDGES FORM AND OUTPUT FOR VIEWERS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	
		/*** for judge one RESETTING process of scores of athletes on viewers ***/

   public function reset_scores_j1($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4){
		date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was resetted the scores into";
          
        //-------------------Delete all DATA codes----------------------//
        $query6 = "TRUNCATE TABLE judge_one";
        $result6 = $this->db->query($query6) or die($this->db->error);

        //---UPDATE DATA codes to change the output on JUDGES FORM AND VIEWERS PAGE-----//
        $query7 = "UPDATE judges_data_form SET at_division ='<i>updating...</i>', at_stage ='<i>updating...</i>', at_heat ='<i>updating...</i>', at_one ='<i>updating...</i>', at_two = '<i>updating...</i>', at_three = '<i>updating...</i>', at_four = '<i>updating...</i>' WHERE form_id = 1";
        $result7 = $this->db->query($query7) or die($this->db->error);

        //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at1 = '<i>updating...</i>', dm_at2 = '<i>updating...</i>', dm_at3 = '<i>updating...</i>', dm_at4 = '<i>updating...</i>', score1='$reset_at1', score2='$reset_at2', score3='$reset_at3', score4='$reset_at4', cur_time='$todays_date'";
        $result5 = $this->db->query($query5) or die($this->db->error);

        return true;         
		}
		

      /*** for judge two RESETTING process of scores of athletes on viewers ***/

   public function reset_scores_j2($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4){
    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was resetted the scores into";

        //-------------------Delete all DATA codes----------------------//
        $query6 = "TRUNCATE TABLE judge_two";
        $result6 = $this->db->query($query6) or die($this->db->error);

        //---UPDATE DATA codes to change the output on JUDGES FORM AND VIEWERS PAGE-----//
        $query7 = "UPDATE judges_data_form SET at_division ='<i>updating...</i>', at_stage ='<i>updating...</i>', at_heat ='<i>updating...</i>', at_one ='<i>updating...</i>', at_two = '<i>updating...</i>', at_three = '<i>updating...</i>', at_four = '<i>updating...</i>' WHERE form_id = 1";
        $result7 = $this->db->query($query7) or die($this->db->error);

        //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at2 = '<i>updating...</i>', dm_at3 = '<i>updating...</i>', dm_at4 = '<i>updating...</i>',score1='$reset_at1', score2='$reset_at2', score3='$reset_at3', score4='$reset_at4', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error);

        return true;         
    }


      /*** for judge three RESETTING process of scores of athletes on viewers ***/

   public function reset_scores_j3($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4){
    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was resetted the scores into";

        //-------------------Delete all DATA codes----------------------//
        $query6 = "TRUNCATE TABLE judge_three";
        $result6 = $this->db->query($query6) or die($this->db->error);

        //---UPDATE DATA codes to change the output on JUDGES FORM AND VIEWERS PAGE-----//
        $query7 = "UPDATE judges_data_form SET at_division ='<i>updating...</i>', at_stage ='<i>updating...</i>', at_heat ='<i>updating...</i>', at_one ='<i>updating...</i>', at_two = '<i>updating...</i>', at_three = '<i>updating...</i>', at_four = '<i>updating...</i>' WHERE form_id = 1";
        $result7 = $this->db->query($query7) or die($this->db->error);

        //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at2 = '<i>updating...</i>', dm_at3 = '<i>updating...</i>', dm_at4 = '<i>updating...</i>',score1='$reset_at1', score2='$reset_at2', score3='$reset_at3', score4='$reset_at4', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error);

        return true;         
    }
     

      /*** for judge four RESETTING process of scores of athletes on viewers ***/

   public function reset_scores_j4($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4){
    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was resetted the scores into";

        //-------------------Delete all DATA codes----------------------//
        $query6 = "TRUNCATE TABLE judge_four";
        $result6 = $this->db->query($query6) or die($this->db->error);

        //---UPDATE DATA codes to change the output on JUDGES FORM AND VIEWERS PAGE-----//
        $query7 = "UPDATE judges_data_form SET at_division ='<i>updating...</i>', at_stage ='<i>updating...</i>', at_heat ='<i>updating...</i>', at_one ='<i>updating...</i>', at_two = '<i>updating...</i>', at_three = '<i>updating...</i>', at_four = '<i>updating...</i>' WHERE form_id = 1";
        $result7 = $this->db->query($query7) or die($this->db->error);

        //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at2 = '<i>updating...</i>', dm_at3 = '<i>updating...</i>', dm_at4 = '<i>updating...</i>',score1='$reset_at1', score2='$reset_at2', score3='$reset_at3', score4='$reset_at4', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error);

        return true;         
    }


      /*** for judge five RESETTING process of scores of athletes on viewers ***/

   public function reset_scores_j5($dm_ju_n,$reset_at1,$reset_at2,$reset_at3,$reset_at4){
    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was resetted the scores into";
        
        //-------------------Delete all DATA codes----------------------//
        $query6 = "TRUNCATE TABLE judge_five";
        $result6 = $this->db->query($query6) or die($this->db->error);

        //---UPDATE DATA codes to change the output on JUDGES FORM AND VIEWERS PAGE-----//
        $query7 = "UPDATE judges_data_form SET at_division ='<i>updating...</i>', at_stage ='<i>updating...</i>', at_heat ='<i>updating...</i>', at_one ='<i>updating...</i>', at_two = '<i>updating...</i>', at_three = '<i>updating...</i>', at_four = '<i>updating...</i>' WHERE form_id = 1";
        $result7 = $this->db->query($query7) or die($this->db->error);

        //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at2 = '<i>updating...</i>', dm_at3 = '<i>updating...</i>', dm_at4 = '<i>updating...</i>', score1='$reset_at1', score2='$reset_at2', score3='$reset_at3', score4='$reset_at4', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error);

        return true;         
    }

		//////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////FUNCTIONS FOR SENDING SCORES OF JUDGES ON THEIR FORM AND OUTPUT FOR VIEWERS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*** for judge one saving process score of athletes and updating score of viewers ***/

   public function reg_judge1_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$co1,$co2,$co3,$co4,$n1,$n2,$n3,$n4,$tol_at1,$tol_at2,$tol_at3,$tol_at4){
		date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was gave scores";
        //$time_registered = strtotime($todays_date);

        //-------------------The viewers scores UPDATE DATA codes----------------------//
        $query1 = "UPDATE sisaph_scores SET colors ='$co1', athletes = '$n1', scores = '$tol_at1', event_date_time='$todays_date' WHERE total_id = 1";
        $result1 = $this->db->query($query1) or die($this->db->error);

        $query2 = "UPDATE sisaph_scores SET colors ='$co2', athletes = '$n2', scores = '$tol_at2', event_date_time='$todays_date' WHERE total_id = 2";
        $result2 = $this->db->query($query2) or die($this->db->error);

        $query3 = "UPDATE sisaph_scores SET colors ='$co3', athletes = '$n3', scores = '$tol_at3', event_date_time='$todays_date' WHERE total_id = 3";
        $result3 = $this->db->query($query3) or die($this->db->error);

        $query4 = "UPDATE sisaph_scores SET colors ='$co4', athletes = '$n4', scores = '$tol_at4', event_date_time='$todays_date' WHERE total_id = 4";
        $result4 = $this->db->query($query4) or die($this->db->error);         

		if($at_one <= 10 && $at_two <= 10 && $at_three <= 10 && $at_four <= 10 && is_numeric($at_one) && is_numeric($at_two) && is_numeric($at_three) && is_numeric($at_four)){
      //-------------------Judge one INSERT DATA codes----------------------//
			$query = "INSERT INTO judge_one SET wavec='$wavec', at_n1='$n1', at_n2='$n2', at_n3='$n3', at_n4='$n4', at1='$at_one', at2='$at_two',at3='$at_three', at4='$at_four', event_date_time='$todays_date'";
			 $result = $this->db->query($query) or die($this->db->error);


       //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$at_one', score2='$at_two', score3='$at_three', score4='$at_four', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error); 

      return true;
	    
		}else{

			 return false;     
		}
			
			
		}

		/*** for judge two saving process score of athletes and updating score of viewers scores ***/

  public function reg_judge2_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$n1,$n2,$n3,$n4){
    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was gave scores";
        //$time_registered = strtotime($todays_date);          

    if($at_one <= 10 && $at_two <= 10 && $at_three <= 10 && $at_four <= 10 && is_numeric($at_one) && is_numeric($at_two) && is_numeric($at_three) && is_numeric($at_four)){
      $query = "INSERT INTO judge_two SET wavec='$wavec', at_n1='$n1', at_n2='$n2', at_n3='$n3', at_n4='$n4',at1='$at_one', at2='$at_two',at3='$at_three', at4='$at_four', event_date_time='$todays_date'";
       $result = $this->db->query($query) or die($this->db->error);

       //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$at_one', score2='$at_two', score3='$at_three', score4='$at_four', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error); 
			 
                   // Sending score Success
			     return true; 
	    
		}else{

			          // Sending score Failed
           return false; 
		}
			
			
		}

		/*** for judge three saving process score of athletes and updating score of viewers scores ***/

	public function reg_judge3_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$n1,$n2,$n3,$n4){
		date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was gave scores";
        //$time_registered = strtotime($todays_date);          

		if($at_one <= 10 && $at_two <= 10 && $at_three <= 10 && $at_four <= 10 && is_numeric($at_one) && is_numeric($at_two) && is_numeric($at_three) && is_numeric($at_four)){
			$query = "INSERT INTO judge_three SET wavec='$wavec', at_n1='$n1', at_n2='$n2', at_n3='$n3', at_n4='$n4',at1='$at_one', at2='$at_two',at3='$at_three', at4='$at_four', event_date_time='$todays_date'";
			 $result = $this->db->query($query) or die($this->db->error);

       //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$at_one', score2='$at_two', score3='$at_three', score4='$at_four', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error); 
			 
                       // Sending score Success
           return true; 
      
    }else{

                // Sending score Failed
           return false; 
    }
    
			
			
		}

		/*** for judge four saving process score of athletes and updating score of viewers scores ***/

	public function reg_judge4_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$n1,$n2,$n3,$n4){
		date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was gave scores";
        //$time_registered = strtotime($todays_date);          

		if($at_one <= 10 && $at_two <= 10 && $at_three <= 10 && $at_four <= 10 && is_numeric($at_one) && is_numeric($at_two) && is_numeric($at_three) && is_numeric($at_four)){
			$query = "INSERT INTO judge_four SET wavec='$wavec', at_n1='$n1', at_n2='$n2', at_n3='$n3', at_n4='$n4',at1='$at_one', at2='$at_two',at3='$at_three', at4='$at_four', event_date_time='$todays_date'";
			 $result = $this->db->query($query) or die($this->db->error);

       //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$at_one', score2='$at_two', score3='$at_three', score4='$at_four', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error); 
			 
                        // Sending score Success
           return true; 
      
    }else{

                // Sending score Failed
           return false; 
    }
    
			
			
		}

		/*** for judge one saving process score of athletes and updating score of viewers scores ***/

	public function reg_judge5_score($dm_wave,$dm_ju_n,$wavec,$at_one,$at_two,$at_three,$at_four,$n1,$n2,$n3,$n4){
		    date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y, h:i:s a");
        $dm_act = "was gave scores";
        //$time_registered = strtotime($todays_date);          

		if($at_one <= 10 && $at_two <= 10 && $at_three <= 10 && $at_four <= 10 && is_numeric($at_one) && is_numeric($at_two) && is_numeric($at_three) && is_numeric($at_four)){
			$query = "INSERT INTO judge_five SET wavec='$wavec', at_n1='$n1', at_n2='$n2', at_n3='$n3', at_n4='$n4',at1='$at_one', at2='$at_two',at3='$at_three', at4='$at_four', event_date_time='$todays_date'";
			 $result = $this->db->query($query) or die($this->db->error);

       //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='$dm_wave', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$at_one', score2='$at_two', score3='$at_three', score4='$at_four', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error); 
			 
                    // Sending score Success
           return true; 
      
    }else{

                // Sending score Failed
           return false; 
    }
    
			
			
		}


		/*** for saving process of final scores for the athletes by set ***/

	public function reg_final_scores($dm_ju_n,$p1,$p2,$p3,$p4,$d1,$st1,$ht1,$n1,$n2,$n3,$n4,$t1,$t2,$t3,$t4){
		date_default_timezone_set('Asia/Manila');
        $todays_date = date("M. d, Y h:i:sa");
        $div1 = addslashes($d1);
        $dm_act = "was saved his/her scores";


			$query = "INSERT INTO sisaph_event_results SET p1='$p1', p2='$p2',p3='$p3',p4='$p4',division='$div1',stage='$st1',heat='$ht1',at1='$n1', at2='$n2',at3='$n3',at4='$n4',final1='$t1', final2='$t2',final3='$t3',final4='$t4',date_time='$todays_date' ";
            $result = $this->db->query($query) or die($this->db->error);

            //-------------------Data Monitoring INSERT DATA codes----------------------//
        $query5 = "INSERT INTO data_monitoring SET judge_names='$dm_ju_n', actions='$dm_act', dm_wave='end', dm_at1='$n1', dm_at2='$n2', dm_at3='$n3', dm_at4='$n4', score1='$t1', score2='$t2', score3='$t3', score4='$t4', cur_time='$todays_date' ";
        $result5 = $this->db->query($query5) or die($this->db->error);

			return true;
			
			
		}



		/*** for saving process of adding new events ***/

	public function adding_events($en,$ep,$ca,$es,$esd,$eed,$ey,$em,$npe){
		date_default_timezone_set('Asia/Manila');
        //$todays_date = date("M. d, Y");
        //$todays_year = date("Y");
        $te = date("h:i:sa");
        $ts = date("h:i:sa");
         
       
			$result = " INSERT INTO adding_events SET event_name = '$en' event_points='$ep', event_address='$ca',event_status='$es',event_year='$ey',event_month='$em',event_start_d='$esd',event_end_d='$eed',time_edited='$te', time_saved='$ts',name_p_edited='$npe' ";
            $result = $this->db->query($result) or die($this->db->error);

			return true;
			
		}



//--------------------------CHECKING FOR LOGIN-----------------------------------------//

//-----------------------------------------------------------------------------------//

		/*** for login process ***/
		public function check_login($judge_name, $judge_password){
			$judge_password = md5($judge_password);

			$query = "SELECT judge_id FROM judges_account WHERE ju_name='$judge_name' AND ju_password='$judge_password' AND ju_active = 'Yes' "; 

			$result = $this->db->query($query) or die($this->db->error);


			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$count_row = $result->num_rows;

			if ($count_row == 1 ) {
	            $_SESSION['login'] = true; // this login var will use for the session thing
	            $_SESSION['ju_name'] = $user_data['judge_id'];
	            return true;
	        }else{

	        	return false;
	        }

	    }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////JUDGE NUMBER ONE PAGE FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	        /*** for displaying judge name  ***/
	    public function get_hjudge($hjudge){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $hjudge";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	          
  //------------- function for all data from judges user ------------//

	              /*** for displaying form id  ***/
	    public function get_form($form){
	    	$query = "SELECT form_id FROM judges_data_form WHERE form_id  = $form";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['form_id'];

	    }


           /*** for displaying judge name  ***/
	    public function get_judge_username($judge_name){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }


	    /*** for displaying judge status  ***/
	    public function get_judge_status($judge_status){
	    	$query = "SELECT ju_status FROM judges_account WHERE judge_id = $judge_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_status'];

	    }

	    //------------- function for all data from scoring ------------//

	        /*** for displaying event title  ***/
	    public function get_event_title($event_title){
	    	$query = "SELECT event_title FROM judges_data_form WHERE form_id = $event_title";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_title'];

	    }

	    /*** for displaying judge name  ***/
	    public function get_judge_name($judge_name){
	    	$query = "SELECT ju_name FROM judges_data_form WHERE form_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	    /*** for displaying event division  ***/
	    public function get_division_name($division){
	    	$query = "SELECT at_division FROM judges_data_form WHERE form_id = $division";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_division'];

	    }
               
          /*** for displaying date time  ***/
	    public function get_date($date){
	    	$query = "SELECT date_time FROM judges_data_form WHERE form_id = $date";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['date_time'];

	    }
         

	     /*** for displaying event stage  ***/
	    public function get_stage_name($at_stage){
	    	$query = "SELECT at_stage FROM judges_data_form WHERE form_id = $at_stage";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_stage'];

	    }
	    
	     /*** for displaying event heat  ***/
	    public function get_heat_name($at_heat){
	    	$query = "SELECT at_heat FROM judges_data_form WHERE form_id = $at_heat";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_heat'];

	    }
	    
	    /*** for displaying athlete color one  ***/
	    public function get_color_one($col_one){
	    	$query = "SELECT at_col_one FROM judges_data_form WHERE form_id = $col_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_one'];

	    }

	    /*** for displaying athlete color two  ***/
	    public function get_color_two($at_color_two){
	    	$query = "SELECT at_col_two FROM judges_data_form WHERE form_id = $at_color_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_two'];

	    }
        
        /*** for displaying athlete color three  ***/
	    public function get_color_three($at_color_three){
	    	$query = "SELECT at_col_three FROM judges_data_form WHERE form_id = $at_color_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_three'];

	    }

        /*** for displaying athlete color four  ***/
	    public function get_color_four($at_color_four){
	    	$query = "SELECT at_col_four FROM judges_data_form WHERE form_id = $at_color_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_four'];

	    }

	    /*** for displaying image one  ***/
	    public function get_img_one($img_one){
	    	$query = "SELECT at_img_one FROM judges_data_form WHERE form_id = $img_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_one'];

	    }

	    /*** for displaying image two  ***/
	    public function get_img_two($img_two){
	    	$query = "SELECT at_img_two FROM judges_data_form WHERE form_id = $img_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_two'];

	    }

	    /*** for displaying image three  ***/
	    public function get_img_three($img_three){
	    	$query = "SELECT at_img_three FROM judges_data_form WHERE form_id = $img_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_three'];

	    }
	    /*** for displaying image four  ***/
	    public function get_img_four($img_four){
	    	$query = "SELECT at_img_four FROM judges_data_form WHERE form_id = $img_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_four'];

	    }

	    /*** for displaying athlete name one  ***/
	    public function get_at_one($name_one){
	    	$query = "SELECT at_one FROM judges_data_form WHERE form_id = $name_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_one'];

	    }

	    /*** for displaying athlete name two  ***/
	    public function get_at_two($name_two){
	    	$query = "SELECT at_two FROM judges_data_form WHERE form_id = $name_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_two'];

	    }

	    /*** for displaying athlete name three  ***/
	    public function get_at_three($name_three){
	    	$query = "SELECT at_three FROM judges_data_form WHERE form_id = $name_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_three'];

	    }
	    /*** for displaying athlete name four  ***/
	    public function get_at_four($name_four){
	    	$query = "SELECT at_four FROM judges_data_form WHERE form_id = $name_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_four'];

	    }


	    /*** for displaying athlete name four  ***/
	    public function get_tol_nameone($tol_one){
	    	$query = "SELECT SUM(at_nameone) AS tol_one FROM judges_scores_given WHERE jsb_id = $tol_one";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['tol_one'];

	    }

	    /*** for displaying the background image  ***/
	    public function get_bg_img($bgimg){
	    	$query = "SELECT bg_img FROM judges_data_form WHERE form_id = $bgimg";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['bg_img'];

	    }

        
        /*** for displaying the background image  ***/
	    public function get_logo($logo){
	    	$query = "SELECT logo FROM judges_data_form WHERE form_id = $logo";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['logo'];

	    }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////JUDGE NUMBER TWO FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	          
  //------------- function for all data from judges user ------------//

           /*** for displaying judge name  ***/
	    public function get_judge_username2($judge_name){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }


	    /*** for displaying judge status  ***/
	    public function get_judge_status2($judge_status){
	    	$query = "SELECT ju_status FROM judges_account WHERE judge_id = $judge_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_status'];

	    }

	    //------------- function for all data from scoring ------------//

	        /*** for displaying event title  ***/
	    public function get_event_title2($event_title){
	    	$query = "SELECT event_title FROM judges_data_form WHERE form_id = $event_title";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_title'];

	    }

	    /*** for displaying judge name  ***/
	    public function get_judge_name2($judge_name){
	    	$query = "SELECT ju_name FROM judges_data_form WHERE form_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	    /*** for displaying event division  ***/
	    public function get_division_name2($division){
	    	$query = "SELECT at_division FROM judges_data_form WHERE form_id = $division";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_division'];

	    }
               
          /*** for displaying date time  ***/
	    public function get_date2($date){
	    	$query = "SELECT event_date FROM judges_data_form WHERE form_id = $date";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_date'];

	    }
         

	     /*** for displaying event stage  ***/
	    public function get_stage_name2($at_stage){
	    	$query = "SELECT at_stage FROM judges_data_form WHERE form_id = $at_stage";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_stage'];

	    }

	    /*** for displaying athlete color one  ***/
	    public function get_color_one2($col_one){
	    	$query = "SELECT at_col_one FROM judges_data_form WHERE form_id = $col_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_one'];

	    }

	    /*** for displaying athlete color two  ***/
	    public function get_color_two2($at_color_two){
	    	$query = "SELECT at_col_two FROM judges_data_form WHERE form_id = $at_color_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_two'];

	    }
        
        /*** for displaying athlete color three  ***/
	    public function get_color_three2($at_color_three){
	    	$query = "SELECT at_col_three FROM judges_data_form WHERE form_id = $at_color_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_three'];

	    }

        /*** for displaying athlete color four  ***/
	    public function get_color_four2($at_color_four){
	    	$query = "SELECT at_col_four FROM judges_data_form WHERE form_id = $at_color_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_four'];

	    }

	    /*** for displaying image one  ***/
	    public function get_img_one2($img_one){
	    	$query = "SELECT at_img_one FROM judges_data_form WHERE form_id = $img_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_one'];

	    }

	    /*** for displaying image two  ***/
	    public function get_img_two2($img_two){
	    	$query = "SELECT at_img_two FROM judges_data_form WHERE form_id = $img_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_two'];

	    }

	    /*** for displaying image three  ***/
	    public function get_img_three2($img_three){
	    	$query = "SELECT at_img_three FROM judges_data_form WHERE form_id = $img_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_three'];

	    }
	    /*** for displaying image four  ***/
	    public function get_img_four2($img_four){
	    	$query = "SELECT at_img_four FROM judges_data_form WHERE form_id = $img_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_four'];

	    }

	    /*** for displaying athlete name one  ***/
	    public function get_at_one2($name_one){
	    	$query = "SELECT at_one FROM judges_data_form WHERE form_id = $name_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_one'];

	    }

	    /*** for displaying athlete name two  ***/
	    public function get_at_two2($name_two){
	    	$query = "SELECT at_two FROM judges_data_form WHERE form_id = $name_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_two'];

	    }

	    /*** for displaying athlete name three  ***/
	    public function get_at_three2($name_three){
	    	$query = "SELECT at_three FROM judges_data_form WHERE form_id = $name_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_three'];

	    }
	    /*** for displaying athlete name four  ***/
	    public function get_at_four2($name_four){
	    	$query = "SELECT at_four FROM judges_data_form WHERE form_id = $name_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_four'];

	    }


	    /*** for displaying athlete name four  ***/
	    public function get_tol_nameone2($tol_one){
	    	$query = "SELECT SUM(at_nameone) AS tol_one FROM judges_scores_given WHERE jsb_id = $tol_one";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['tol_one'];

	    }

	    /*** for displaying the background image  ***/
	    public function get_bg_img2($bgimg){
	    	$query = "SELECT bg_img FROM judges_data_form WHERE form_id = $bgimg";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['bg_img'];

	    }

        
        /*** for displaying the background image  ***/
	    public function get_logo2($logo){
	    	$query = "SELECT logo FROM judges_data_form WHERE form_id = $logo";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['logo'];

	    }	  


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////JUDGE NUMBER THREE PAGE FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	          
  //------------- function for all data from judges user ------------//

           /*** for displaying judge name  ***/
	    public function get_judge_username3($judge_name){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }


	    /*** for displaying judge status  ***/
	    public function get_judge_status3($judge_status){
	    	$query = "SELECT ju_status FROM judges_account WHERE judge_id = $judge_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_status'];

	    }

	    //------------- function for all data from scoring ------------//

	        /*** for displaying event title  ***/
	    public function get_event_title3($event_title){
	    	$query = "SELECT event_title FROM judges_data_form WHERE form_id = $event_title";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_title'];

	    }

	    /*** for displaying judge name  ***/
	    public function get_judge_name3($judge_name){
	    	$query = "SELECT ju_name FROM judges_data_form WHERE form_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	    /*** for displaying event division  ***/
	    public function get_division_name3($division){
	    	$query = "SELECT at_division FROM judges_data_form WHERE form_id = $division";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_division'];

	    }
               
          /*** for displaying date time  ***/
	    public function get_date3($date){
	    	$query = "SELECT event_date FROM judges_data_form WHERE form_id = $date";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_date'];

	    }
         

	     /*** for displaying event stage  ***/
	    public function get_stage_name3($at_stage){
	    	$query = "SELECT at_stage FROM judges_data_form WHERE form_id = $at_stage";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_stage'];

	    }

	    /*** for displaying athlete color one  ***/
	    public function get_color_one3($col_one){
	    	$query = "SELECT at_col_one FROM judges_data_form WHERE form_id = $col_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_one'];

	    }

	    /*** for displaying athlete color two  ***/
	    public function get_color_two3($at_color_two){
	    	$query = "SELECT at_col_two FROM judges_data_form WHERE form_id = $at_color_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_two'];

	    }
        
        /*** for displaying athlete color three  ***/
	    public function get_color_three3($at_color_three){
	    	$query = "SELECT at_col_three FROM judges_data_form WHERE form_id = $at_color_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_three'];

	    }

        /*** for displaying athlete color four  ***/
	    public function get_color_four3($at_color_four){
	    	$query = "SELECT at_col_four FROM judges_data_form WHERE form_id = $at_color_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_four'];

	    }

	    /*** for displaying image one  ***/
	    public function get_img_one3($img_one){
	    	$query = "SELECT at_img_one FROM judges_data_form WHERE form_id = $img_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_one'];

	    }

	    /*** for displaying image two  ***/
	    public function get_img_two3($img_two){
	    	$query = "SELECT at_img_two FROM judges_data_form WHERE form_id = $img_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_two'];

	    }

	    /*** for displaying image three  ***/
	    public function get_img_three3($img_three){
	    	$query = "SELECT at_img_three FROM judges_data_form WHERE form_id = $img_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_three'];

	    }
	    /*** for displaying image four  ***/
	    public function get_img_four3($img_four){
	    	$query = "SELECT at_img_four FROM judges_data_form WHERE form_id = $img_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_four'];

	    }

	    /*** for displaying athlete name one  ***/
	    public function get_at_one3($name_one){
	    	$query = "SELECT at_one FROM judges_data_form WHERE form_id = $name_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_one'];

	    }

	    /*** for displaying athlete name two  ***/
	    public function get_at_two3($name_two){
	    	$query = "SELECT at_two FROM judges_data_form WHERE form_id = $name_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_two'];

	    }

	    /*** for displaying athlete name three  ***/
	    public function get_at_three3($name_three){
	    	$query = "SELECT at_three FROM judges_data_form WHERE form_id = $name_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_three'];

	    }
	    /*** for displaying athlete name four  ***/
	    public function get_at_four3($name_four){
	    	$query = "SELECT at_four FROM judges_data_form WHERE form_id = $name_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_four'];

	    }


	    /*** for displaying athlete name four  ***/
	    public function get_tol_nameone3($tol_one){
	    	$query = "SELECT SUM(at_nameone) AS tol_one FROM judges_scores_given WHERE jsb_id = $tol_one";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['tol_one'];

	    }

	    /*** for displaying the background image  ***/
	    public function get_bg_img3($bgimg){
	    	$query = "SELECT bg_img FROM judges_data_form WHERE form_id = $bgimg";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['bg_img'];

	    }

        
        /*** for displaying the background image  ***/
	    public function get_logo3($logo){
	    	$query = "SELECT logo FROM judges_data_form WHERE form_id = $logo";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['logo'];

	    }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////JUDGE NUMBER FOUR PAGE FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	          
  //------------- function for all data from judges user ------------//

           /*** for displaying judge name  ***/
	    public function get_judge_username4($judge_name){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }


	    /*** for displaying judge status  ***/
	    public function get_judge_status4($judge_status){
	    	$query = "SELECT ju_status FROM judges_account WHERE judge_id = $judge_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_status'];

	    }

	    //------------- function for all data from scoring ------------//

	        /*** for displaying event title  ***/
	    public function get_event_title4($event_title){
	    	$query = "SELECT event_title FROM judges_data_form WHERE form_id = $event_title";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_title'];

	    }

	    /*** for displaying judge name  ***/
	    public function get_judge_name4($judge_name){
	    	$query = "SELECT ju_name FROM judges_data_form WHERE form_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	    /*** for displaying event division  ***/
	    public function get_division_name4($division){
	    	$query = "SELECT at_division FROM judges_data_form WHERE form_id = $division";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_division'];

	    }
               
          /*** for displaying date time  ***/
	    public function get_date4($date){
	    	$query = "SELECT event_date FROM judges_data_form WHERE form_id = $date";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_date'];

	    }
         

	     /*** for displaying event stage  ***/
	    public function get_stage_name4($at_stage){
	    	$query = "SELECT at_stage FROM judges_data_form WHERE form_id = $at_stage";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_stage'];

	    }

	    /*** for displaying athlete color one  ***/
	    public function get_color_one4($col_one){
	    	$query = "SELECT at_col_one FROM judges_data_form WHERE form_id = $col_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_one'];

	    }

	    /*** for displaying athlete color two  ***/
	    public function get_color_two4($at_color_two){
	    	$query = "SELECT at_col_two FROM judges_data_form WHERE form_id = $at_color_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_two'];

	    }
        
        /*** for displaying athlete color three  ***/
	    public function get_color_three4($at_color_three){
	    	$query = "SELECT at_col_three FROM judges_data_form WHERE form_id = $at_color_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_three'];

	    }

        /*** for displaying athlete color four  ***/
	    public function get_color_four4($at_color_four){
	    	$query = "SELECT at_col_four FROM judges_data_form WHERE form_id = $at_color_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_four'];

	    }

	    /*** for displaying image one  ***/
	    public function get_img_one4($img_one){
	    	$query = "SELECT at_img_one FROM judges_data_form WHERE form_id = $img_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_one'];

	    }

	    /*** for displaying image two  ***/
	    public function get_img_two4($img_two){
	    	$query = "SELECT at_img_two FROM judges_data_form WHERE form_id = $img_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_two'];

	    }

	    /*** for displaying image three  ***/
	    public function get_img_three4($img_three){
	    	$query = "SELECT at_img_three FROM judges_data_form WHERE form_id = $img_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_three'];

	    }
	    /*** for displaying image four  ***/
	    public function get_img_four4($img_four){
	    	$query = "SELECT at_img_four FROM judges_data_form WHERE form_id = $img_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_four'];

	    }

	    /*** for displaying athlete name one  ***/
	    public function get_at_one4($name_one){
	    	$query = "SELECT at_one FROM judges_data_form WHERE form_id = $name_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_one'];

	    }

	    /*** for displaying athlete name two  ***/
	    public function get_at_two4($name_two){
	    	$query = "SELECT at_two FROM judges_data_form WHERE form_id = $name_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_two'];

	    }

	    /*** for displaying athlete name three  ***/
	    public function get_at_three4($name_three){
	    	$query = "SELECT at_three FROM judges_data_form WHERE form_id = $name_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_three'];

	    }
	    /*** for displaying athlete name four  ***/
	    public function get_at_four4($name_four){
	    	$query = "SELECT at_four FROM judges_data_form WHERE form_id = $name_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_four'];

	    }


	    /*** for displaying athlete name four  ***/
	    public function get_tol_nameone4($tol_one){
	    	$query = "SELECT SUM(at_nameone) AS tol_one FROM judges_scores_given WHERE jsb_id = $tol_one";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['tol_one'];

	    }

	    /*** for displaying the background image  ***/
	    public function get_bg_img4($bgimg){
	    	$query = "SELECT bg_img FROM judges_data_form WHERE form_id = $bgimg";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['bg_img'];

	    }

        
        /*** for displaying the background image  ***/
	    public function get_logo4($logo){
	    	$query = "SELECT logo FROM judges_data_form WHERE form_id = $logo";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['logo'];

	    }	




	    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////JUDGE NUMBER FIVE PAGE FUNCTIONS///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	          
  //------------- function for all data from judges user ------------//

           /*** for displaying judge name  ***/
	    public function get_judge_username5($judge_name){
	    	$query = "SELECT ju_name FROM judges_account WHERE judge_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }


	    /*** for displaying judge status  ***/
	    public function get_judge_status5($judge_status){
	    	$query = "SELECT ju_status FROM judges_account WHERE judge_id = $judge_status";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_status'];

	    }

	    //------------- function for all data from scoring ------------//

	        /*** for displaying event title  ***/
	    public function get_event_title5($event_title){
	    	$query = "SELECT event_title FROM judges_data_form WHERE form_id = $event_title";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_title'];

	    }

	    /*** for displaying judge name  ***/
	    public function get_judge_name5($judge_name){
	    	$query = "SELECT ju_name FROM judges_data_form WHERE form_id = $judge_name";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['ju_name'];

	    }

	    /*** for displaying event division  ***/
	    public function get_division_name5($division){
	    	$query = "SELECT at_division FROM judges_data_form WHERE form_id = $division";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_division'];

	    }
               
          /*** for displaying date time  ***/
	    public function get_date5($date){
	    	$query = "SELECT event_date FROM judges_data_form WHERE form_id = $date";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['event_date'];

	    }
         

	     /*** for displaying event stage  ***/
	    public function get_stage_name5($at_stage){
	    	$query = "SELECT at_stage FROM judges_data_form WHERE form_id = $at_stage";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_stage'];

	    }

	    /*** for displaying athlete color one  ***/
	    public function get_color_one5($col_one){
	    	$query = "SELECT at_col_one FROM judges_data_form WHERE form_id = $col_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_one'];

	    }

	    /*** for displaying athlete color two  ***/
	    public function get_color_two5($at_color_two){
	    	$query = "SELECT at_col_two FROM judges_data_form WHERE form_id = $at_color_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_two'];

	    }
        
        /*** for displaying athlete color three  ***/
	    public function get_color_three5($at_color_three){
	    	$query = "SELECT at_col_three FROM judges_data_form WHERE form_id = $at_color_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_three'];

	    }

        /*** for displaying athlete color four  ***/
	    public function get_color_four5($at_color_four){
	    	$query = "SELECT at_col_four FROM judges_data_form WHERE form_id = $at_color_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_col_four'];

	    }

	    /*** for displaying image one  ***/
	    public function get_img_one5($img_one){
	    	$query = "SELECT at_img_one FROM judges_data_form WHERE form_id = $img_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_one'];

	    }

	    /*** for displaying image two  ***/
	    public function get_img_two5($img_two){
	    	$query = "SELECT at_img_two FROM judges_data_form WHERE form_id = $img_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_two'];

	    }

	    /*** for displaying image three  ***/
	    public function get_img_three5($img_three){
	    	$query = "SELECT at_img_three FROM judges_data_form WHERE form_id = $img_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_three'];

	    }
	    /*** for displaying image four  ***/
	    public function get_img_four5($img_four){
	    	$query = "SELECT at_img_four FROM judges_data_form WHERE form_id = $img_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_img_four'];

	    }

	    /*** for displaying athlete name one  ***/
	    public function get_at_one5($name_one){
	    	$query = "SELECT at_one FROM judges_data_form WHERE form_id = $name_one";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_one'];

	    }

	    /*** for displaying athlete name two  ***/
	    public function get_at_two5($name_two){
	    	$query = "SELECT at_two FROM judges_data_form WHERE form_id = $name_two";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_two'];

	    }

	    /*** for displaying athlete name three  ***/
	    public function get_at_three5($name_three){
	    	$query = "SELECT at_three FROM judges_data_form WHERE form_id = $name_three";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_three'];

	    }
	    /*** for displaying athlete name four  ***/
	    public function get_at_four5($name_four){
	    	$query = "SELECT at_four FROM judges_data_form WHERE form_id = $name_four";

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['at_four'];

	    }


	    /*** for displaying athlete name four  ***/
	    public function get_tol_nameone5($tol_one){
	    	$query = "SELECT SUM(at_nameone) AS tol_one FROM judges_scores_given WHERE jsb_id = $tol_one";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['tol_one'];

	    }

	    /*** for displaying the background image  ***/
	    public function get_bg_img5($bgimg){
	    	$query = "SELECT bg_img FROM judges_data_form WHERE form_id = $bgimg";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['bg_img'];

	    }

        
        /*** for displaying the background image  ***/
	    public function get_logo5($logo){
	    	$query = "SELECT logo FROM judges_data_form WHERE form_id = $logo";
	    	

	    	$result = $this->db->query($query) or die($this->db->error);

	    	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	    	echo $user_data['logo'];

	    }

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////EVENT RESULST FUNCTIONS////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


      public function get_t($tn){
        $query = "SELECT event_title FROM sisaph_event_results WHERE fs_id = $tn";
        

        $result = $this->db->query($query) or die($this->db->error);

        $user_data = $result->fetch_array(MYSQLI_ASSOC);
        echo $user_data['event_title'];

      }



 	    	   /*** for login process ***/
    public function check_id($id){
      //$judge_password = md5($judge_password);

      $query = "SELECT fs_id FROM sisaph_event_results WHERE fs_id='$id' "; 

      $result = $this->db->query($query) or die($this->db->error);


      $user_data = $result->fetch_array(MYSQLI_ASSOC);
      $count_row = $result->num_rows;

      if ($count_row == 1 ) {
              $_SESSION['link'] = true; // this login var will use for the session thing
              $_SESSION['event_title'] = $user_data['fs_id'];
              return true;
          }else{

            return false;
          }

      }




/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////SESSION LOGOUT IF NOT///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////	  

	    /*** starting the session ***/
	    public function get_session(){
	    	return $_SESSION['login'];
	    }

	    public function user_logout() {
	    	$_SESSION['login'] = FALSE;
	    	unset($_SESSION);
	    	session_destroy();
	    }



	}




?>