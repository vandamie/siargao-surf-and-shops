
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- SISA PH TAB ICON -->
    <link rel="icon" type="image" href="images/sisa-logo.jpg">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
    <link href="./view/css/style.css" type="text/css" rel="stylesheet" />


    <title>SISA PH Export data into MS excel</title>
</head>
<body>

        <?php
    if (empty($productResult)) {
        ?>
    <div class="empty-table">
    <div class="svg-icon">
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24"><circle cx="12" cy="19" r="2"/><path d="M10 3h4v12h-4z"/><path fill="none" d="M0 0h24v24H0z"/></svg>
    </div>
    No records found</div>
    </div>
    
    <?php
    }else{
    ?>

        <div class="table-responsive content">

        <table class="table-responsive" align="center">
            <?php
            foreach ($productResult as $key => $value) {
            ?>
            <thead>
                <tr>
                    <td colspan="4"><?php echo $productResult[$key]["date_time"]; ?></td>
                </tr>
                <tr>
                    <th><?php echo $productResult[$key]["division"]; ?></th>
                    <th><?php echo $productResult[$key]["stage"]; ?></th>
                    <th><?php echo $productResult[$key]["heat"]; ?></th>
                    <th></th>
                </tr>
                <tr>
                    <td><?php echo $productResult[$key]["at1"]; ?></td>
                    <td><?php echo $productResult[$key]["at2"]; ?></td>
                    <td><?php echo $productResult[$key]["at3"]; ?></td>
                    <td><?php echo $productResult[$key]["at4"]; ?></td>
                </tr>
            </thead>
            <tbody>
   
                <tr>
                    <td><?php echo $productResult[$key]["final1"]; ?></td>
                    <td><?php echo $productResult[$key]["final2"]; ?></td>
                    <td><?php echo $productResult[$key]["final3"]; ?></td>
                    <td><?php echo $productResult[$key]["final4"]; ?></td>
                </tr>
        <?php
        }
        ?>
            </tbody>
        </table>

        <div class="btn1">
            <form action="" method="post">
                <button type="submit" id="btnExport" name='export'
                    value="Export to Excel" class="btn btn-info" onclick="return confirm('Are you sure do you want to export data?')">Export
                    to Excel</button>
            </form>
       </div>

        <div class="btn2">
<?php

$html="

<!doctype html>
<html lang='en'>
  <head>
    <!-- Required meta tags -->
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <!-- SISA PH TAB ICON -->
    <link rel='icon' type='image' href='images/sisa-logo.jp'>

    <!-- Bootstrap CSS -->
    <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css' >
    <link href='./view/css/style.css' type='text/css' rel='stylesheet' />
    <link href='./view/css/style.css' type='text/css' rel='stylesheet' />

    <title>SISA PH printing the event results</title>
</head>
<body>

<div class='table-responsive content'>
<table class='table-responsive'>
<thead>
<tr>
<th>Division</th>
<th>Stage</th>
<th>Heat</th>
<th>Athlete 1</th>
<th>Athlete 2</th>
<th>Athlete 3</th>
<th>Athlete 4</th>
<th>Final Score Athlete 1</th>
<th>Final Score Athlete 2</th>
<th>Final Score Athlete 3</th>
<th>Final Score Athlete 4</th>
<th>Date and Time Saved</th>
</tr>
</thead>";

$conn = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island","id14326742_admin_cms");

$result = mysqli_query($conn,"SELECT division, stage, heat, at1, at2, at3, at4, final1, final2, final3, final4,                                        date_time 
                  FROM sisaph_event_results 
                  ORDER BY date_time");

while ($row = mysqli_fetch_array($result)) {
$html.="
<tbody>
<tr>
<td>".$row['division']."</td>
<td>".$row['stage']."</td>
<td>".$row['heat']."</td>
<td>".$row['at1']."</td>
<td>".$row['at2']."</td>
<td>".$row['at3']."</td>
<td>".$row['at4']."</td>
<td>".$row['final1']."</td>
<td>".$row['final2']."</td>
<td>".$row['final3']."</td>
<td>".$row['final4']."</td>
<td>".$row['date_time']."</td>
</tr>
</tbody>";
}

$html.="</table>
        </div>
 <script src='https://code.jquery.com/jquery-3.3.1.slim.min.js' ></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js' ></script>
    <script src='https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js' ></script>
  </body>
</html>

";

?>        
        <script type="text/javascript">     
        function PrintEventResults() {    
       var divToPrint = document.getElementById('divToPrint');
       var popupWin = window.open('', '_SISA PH Event Results', 'width=500,height=500');
       popupWin.document.open();
       popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
        popupWin.document.close();
            }
          </script>

  <div id="divToPrint" style="display:none;">
  <div style="width:auto; height:auto; margin:auto; background-color:lightgrey;">
           <?php echo $html; ?>      
  </div>
  </div>
   <div>
  <button type="button" id="btnExport" value="Print Overall Results" class="btn btn-info" onclick="PrintEventResults();" />Print Overall Results</button>
  </div>


   </div>
   
   <?php
    }
    ?>
    


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" ></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" ></script>
    
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
    
  </body>
</html>