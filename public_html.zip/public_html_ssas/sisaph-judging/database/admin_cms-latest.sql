-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3308
-- Generation Time: Aug 24, 2020 at 06:46 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `judges_account`
--

DROP TABLE IF EXISTS `judges_account`;
CREATE TABLE IF NOT EXISTS `judges_account` (
  `judge_id` int(11) NOT NULL AUTO_INCREMENT,
  `ju_name` varchar(100) DEFAULT NULL,
  `ju_password` varchar(100) DEFAULT NULL,
  `ju_active` varchar(100) NOT NULL,
  `ju_status` varchar(100) NOT NULL,
  `date_time` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`judge_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `judges_account`
--

INSERT INTO `judges_account` (`judge_id`, `ju_name`, `ju_password`, `ju_active`, `ju_status`, `date_time`) VALUES
(1, 'judge1', 'sisaph', 'Yes', 'Offline', '20-08-23 11:53:04am'),
(2, 'judge2', 'sisaph', 'Yes', 'Offline', '20-08-23 11:52:50am'),
(3, 'judge3', 'sisaph', 'Yes', 'Online', '20-08-23 11:53:04am'),
(4, 'judge4', 'sisaph', 'Yes', 'Offline', '20-08-23 11:53:04am'),
(5, 'judge5', 'sisaph', 'Yes', 'Offline', '20-08-23 11:53:04am');

-- --------------------------------------------------------

--
-- Table structure for table `judges_data_form`
--

DROP TABLE IF EXISTS `judges_data_form`;
CREATE TABLE IF NOT EXISTS `judges_data_form` (
  `form_id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(100) NOT NULL,
  `bg_img` varchar(100) NOT NULL,
  `event_title` varchar(250) NOT NULL,
  `ju_name` varchar(100) NOT NULL,
  `event_date` varchar(100) NOT NULL,
  `at_division` varchar(100) NOT NULL,
  `at_stage` varchar(100) NOT NULL,
  `at_col_one` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `at_col_two` varchar(100) NOT NULL,
  `at_col_three` varchar(100) NOT NULL,
  `at_col_four` varchar(100) NOT NULL,
  `at_img_one` varchar(100) NOT NULL,
  `at_img_two` varchar(100) NOT NULL,
  `at_img_three` varchar(100) NOT NULL,
  `at_img_four` varchar(100) NOT NULL,
  `at_one` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `at_two` varchar(100) NOT NULL,
  `at_three` varchar(100) NOT NULL,
  `at_four` varchar(100) NOT NULL,
  `date_time` varchar(100) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `judges_data_form`
--

INSERT INTO `judges_data_form` (`form_id`, `logo`, `bg_img`, `event_title`, `ju_name`, `event_date`, `at_division`, `at_stage`, `at_col_one`, `at_col_two`, `at_col_three`, `at_col_four`, `at_img_one`, `at_img_two`, `at_img_three`, `at_img_four`, `at_one`, `at_two`, `at_three`, `at_four`, `date_time`) VALUES
(1, '505902.jpg', '535001.jpg', 'Cloud Nine Masters', 'Vandamie', 'January 4, 2022', 'Men\'s Open', 'Quarter Final', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '20-08-25 02:28:22am'),
(2, '815803.jpg', '248254.jpg', 'Cloud Nine Masters', 'Vandamie', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '20-08-21 11:13:39pm'),
(3, 'cloud-9.jpg', '185704.jpg', 'Cloud Nine Masters', 'Vandamie', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '20-08-21 11:13:39pm'),
(4, 'cloud-9.jpg', '698032.jpg', 'Cloud Nine Masters', 'Vandamie', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '20-08-21 11:13:39pm'),
(5, 'cloud-9.jpg', '945435.jpg', 'Cloud Nine Masters', 'Vandamie', 'January 4, 2022', 'Women\'s Open', 'Quarter Final', '#FF0000 ', '#0000FF', '#FFFF00', '#FFFFFF', '824749.png', '297700.png', '668457.png', '418330.png', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', '20-08-21 11:13:39pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_five`
--

DROP TABLE IF EXISTS `judge_five`;
CREATE TABLE IF NOT EXISTS `judge_five` (
  `jsb_id` int(11) NOT NULL AUTO_INCREMENT,
  `at1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at3` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at4` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_date_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`jsb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_five`
--

INSERT INTO `judge_five` (`jsb_id`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(137, '2', '3', '4', '5', '20-08-23 05:40:54pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_four`
--

DROP TABLE IF EXISTS `judge_four`;
CREATE TABLE IF NOT EXISTS `judge_four` (
  `jsb_id` int(11) NOT NULL AUTO_INCREMENT,
  `at1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at3` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at4` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_date_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`jsb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_four`
--

INSERT INTO `judge_four` (`jsb_id`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(137, '10', '10', '10', '10', '20-08-23 05:40:54pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_one`
--

DROP TABLE IF EXISTS `judge_one`;
CREATE TABLE IF NOT EXISTS `judge_one` (
  `jsb_id` int(11) NOT NULL AUTO_INCREMENT,
  `at1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at3` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at4` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_date_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`jsb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_one`
--

INSERT INTO `judge_one` (`jsb_id`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(144, '1', '1', '1', '1', '20-08-25 12:52:18am'),
(145, '1', '1', '1', '1', '20-08-25 12:54:46am'),
(146, '3', '3', '3', '3', '20-08-25 12:55:36am');

-- --------------------------------------------------------

--
-- Table structure for table `judge_three`
--

DROP TABLE IF EXISTS `judge_three`;
CREATE TABLE IF NOT EXISTS `judge_three` (
  `jsb_id` int(11) NOT NULL AUTO_INCREMENT,
  `at1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at3` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at4` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_date_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`jsb_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_three`
--

INSERT INTO `judge_three` (`jsb_id`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(137, '10', '10', '10', '10', '20-08-23 05:40:54pm');

-- --------------------------------------------------------

--
-- Table structure for table `judge_two`
--

DROP TABLE IF EXISTS `judge_two`;
CREATE TABLE IF NOT EXISTS `judge_two` (
  `jsb_id` int(11) NOT NULL,
  `at1` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at2` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at3` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `at4` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_date_time` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`jsb_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `judge_two`
--

INSERT INTO `judge_two` (`jsb_id`, `at1`, `at2`, `at3`, `at4`, `event_date_time`) VALUES
(137, '10', '10', '10', '10', '20-08-23 05:40:54pm');

-- --------------------------------------------------------

--
-- Table structure for table `sisaph_event_results`
--

DROP TABLE IF EXISTS `sisaph_event_results`;
CREATE TABLE IF NOT EXISTS `sisaph_event_results` (
  `fs_id` int(11) NOT NULL AUTO_INCREMENT,
  `p1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `p2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `p3` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `p4` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `division` varchar(100) NOT NULL,
  `stage` varchar(100) NOT NULL,
  `at1` varchar(100) NOT NULL,
  `at2` varchar(100) NOT NULL,
  `at3` varchar(100) NOT NULL,
  `at4` varchar(100) NOT NULL,
  `final1` double(10,1) NOT NULL,
  `final2` double(10,1) NOT NULL,
  `final3` double(10,1) NOT NULL,
  `final4` double(10,1) NOT NULL,
  `date_time` varchar(100) NOT NULL,
  PRIMARY KEY (`fs_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sisaph_event_results`
--

INSERT INTO `sisaph_event_results` (`fs_id`, `p1`, `p2`, `p3`, `p4`, `division`, `stage`, `at1`, `at2`, `at3`, `at4`, `final1`, `final2`, `final3`, `final4`, `date_time`) VALUES
(11, '824749.png', '297700.png', '668457.png', '418330.png', 'Women\'s Open', 'Quarter Final', 'Philmar Alipayo', 'PJ Alipayo', 'Loloy Espejon', 'Edito Alcala Jr.', 6.0, 6.0, 6.0, 6.0, '20-08-24 09:56:35pm');

-- --------------------------------------------------------

--
-- Table structure for table `sisaph_scores`
--

DROP TABLE IF EXISTS `sisaph_scores`;
CREATE TABLE IF NOT EXISTS `sisaph_scores` (
  `total_id` int(11) NOT NULL AUTO_INCREMENT,
  `colors` varchar(100) NOT NULL,
  `athletes` varchar(100) NOT NULL,
  `scores` double(10,1) NOT NULL,
  `event_date_time` varchar(100) NOT NULL,
  PRIMARY KEY (`total_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `sisaph_scores`
--

INSERT INTO `sisaph_scores` (`total_id`, `colors`, `athletes`, `scores`, `event_date_time`) VALUES
(1, '#FF0000 ', 'Philmar Alipayo', 11.0, '20-08-22 05:05:08pm'),
(2, '#0000FF', 'PJ Alipayo', 9.0, '20-08-22 05:05:08pm'),
(3, '#FFFF00', 'Loloy Espejon', 9.0, '20-08-22 05:05:08pm'),
(4, '#FFFFFF', 'Edito Alcala Jr.', 9.0, '20-08-22 05:05:08pm');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_active` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_status` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `user_type` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_password`, `user_email`, `user_active`, `user_status`, `user_type`) VALUES
(39, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user@gmail.com', 'Yes', 'Offline', 'Secondary'),
(55, 'james', 'b4cc344d25a2efe540adbf2678e2304c', 'james@gmail.com', 'No', 'Offline', 'User'),
(45, 'yuval', '1cd9896ce04fd5a67a7961a8b819e63b', 'yuval@gmail.com', 'Yes', 'Offline', 'Primary'),
(46, 'admin', 'admin', 'admin@gmail.com', 'Yes', 'Offline', 'Secondary Admin'),
(47, 'admin1', 'admin1', 'admin1@gmail.com', 'Yes', 'Offline', 'Secondary Admin'),
(48, 'admin2', 'admin2', 'admin2@gmail.com', 'Yes', 'Offline', 'User'),
(49, 'admin3', 'admin3', 'admin3@gmail.com', 'Yes', 'Offline', 'User'),
(50, 'yosol', 'e2d6c30c96b5ef93ff7f49c53c498a5f', 'admin4@gmail.com', 'Yes', '45', 'Secondary'),
(64, 'gaffud', '25f9e794323b453885f5181f1b624d0b', 'gaffud@gmail.com', 'No', 'Offline', 'User'),
(63, 'jayson', '25f9e794323b453885f5181f1b624d0b', 'yuval@yahoo.com', 'No', 'Offline', 'User'),
(65, 'van', '25f9e794323b453885f5181f1b624d0b', 'vandamie.espadero@gmail.com', 'Yes', 'Offline', 'Primary');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
