<?php
// Report all errors
error_reporting(E_ALL);
//error_reporting(0);
ob_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();//connection to public User function

$error1='';
if (isset($_POST['submit-log'])) {  // posting data after submit button.
   session_start();//session_start
  extract($_POST); //extracting all data  from database.   
  $login = $user->check_login($cname, $cpassword); // calling function verification process.
  $error1='';
  if ($login) {
          // Login Success
   ?>
   <!doctype html>
   <html lang="en">
   <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed in successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='reg-ssas-community.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
          // Login Failed
    ?>
<!doctype html>
<html lang="en">
<head>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
<title></title>
</head>
<body>    
    <script>
      swal({
  title: "Wrong username or password or your account is need for the admin approval.",
  icon: "warning",
  button: "okay",
         }).then(function(isConfirm) {
    if (isConfirm) {
     location.reload();
    } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}
}
//-------------------------------Register------------------------------//
$error2= '';
if (isset($_POST['submit-reg'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$register = $user->reg_user($cus_name, $cus_password, $cus_email, $q_sec1,$sec_ans1,$q_sec2, $sec_ans2);
$error2= '';
if ($register) {
            // sending Success
      ?>
<!doctype html>
<html lang="en">
<head>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
<title></title>
</head>
<body>    
    <script>
      swal({
  title: "Registration successfully. You may now login to SSAS.",
  icon: "success",
  button: "okay",
         }).then(function(isConfirm) {
    if (isConfirm) {
     location.reload();
    } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
            // sending Failed
     ?>
<!doctype html>
<html lang="en">
<head>
<!-- Sweet Alert -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>    
<title></title>
</head>
<body>    
    <script>
      swal({
  title: "Registration failed. Email or Username already exist please try again.",
  icon: "warning",
  button: "okay",
         }).then(function(isConfirm) {
    if (isConfirm) {
     location.reload();
    } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}
}

//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // Registration Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // Registration Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
ob_end_flush();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
 <meta name="description" content="Siargao Surf and Shops Official Website, Community">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <meta name="description" content="Siargao Surf and Shops Official Website, Communities">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="sisa-images/ssas-logo.png">
    <!-- font-awesome icons link source -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="./sisa-css/style.css" rel="stylesheet">
  <title>SSAS Community</title>
  <style>
  /* Table CSS */
  table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 432px;
    border:1px black solid;
    border-radius:5px; 
    background-color: white;
    -ms-overflow-style: none;  /* Internet Explorer 10+ */
    scrollbar-width: none;  /* Firefox */
  }

  /* Hide scrollbar for Chrome, Safari and Opera */
  table::-webkit-scrollbar {
    display: none;
  }
  @media (max-width: 600px) {
    table{
      width: 323px;
      font-size: 12px;
      height: 412px;
    }
  }

  th, td {
    text-align: left;
    padding: 5px;
  }

  tr:nth-child(even){background-color: #f2f2f2}


  /**************** CSS for Community column **************/
  /* Create two equal columns that floats next to each other */
  .column {
    float: left;
    width: 100%;
    padding: 10px;
    height:auto; /* Should be removed. Only for demonstration */
  }
    @media screen and (max-width: 600px) {
    .column {
      font-size: 12px;
    }
  }

  /* Clear floats after the columns */
  .row:after {
    content: "";
    display: table;
    clear: both;
  }

  /* Content */
  .content {
    background-color:#edf1f8;
    padding:10px;
    width: 100%; 
    border-radius: 10px;
    font-family: Arial;
    font-size: 12px;
  }

  @media screen and (max-width: 500px;) {
  div.content {
      font-size: 12px;
      width:420px;
      border-radius:5px; 
    }
  }
  .inline-label{
    display: inline; /* the default for span */
    width: auto;
    height: auto;
    color: black; 
    text-align:left;
  }
    #inline-label-content-com{
    display: inline /* the default for span */
    width: 200px;
    height:auto;
    color: black; 
    text-align:left;
    padding:10px;
  }
    #inline-label-content-com:hover{
    display:inline; /* the default for span */
    text-decoration: underline;
    width:200px;
    height:auto;
    color:#4267B2; 
    text-align: left;
    padding:10px;
  }

#search_box_comm{
  background-color:white;
  color: black;
  padding: 5px;
  font-size: 12px;
  border-radius: 3px; 
  border: 1px solid #1E90FF;
  width: 50%;
}
#search_icon_comm{
  background-color:#edf1f8;
  color: black;
  padding: 5px;
  font-size: 14px;
  border-radius: 3px; 
  outline:none;
}
.inline {
    text-align: center;
    border-radius: 5px;
}
.wrap {
    display: inline-block;
    margin: 0 2%;
}
#wrap-color{
  color: black;
}
#wrap-color:hover{
  color: #4267B2;
  text-decoration: underline;
}
#wrap-color-comm{
  color: #4267B2;
}
#wrap-color-comm:hover{
  text-decoration: underline;
}
.rel{
  border-radius: 5px;
}
</style>
</head>
<body>
   <br><br><br><br><br>
  <!-- Header -->
  <?php include("header.php"); ?> 
  <div class="container">
  <main role="main">
 <div class="content">

    <div class="inline-label"><center><h5>Communities</h5></center></div>
  <hr>
<div class="inline-label"><a href="#" id="wrap-color-comm"> Siargao Surf and Shops Communities Guidelines.</a></div>
  <div class="row">
   <div class="column">
     <center>
      <h5>Find answers and ask questions.</h5>
      <input type="text" id="search_box_comm" name="search_data_comm" placeholder="Search questions..." aria-label="Search Questions" class="inline-label">
     <button type="submit" id="search_icon_comm" name="search_btn_comm" class="inline-label"><i class="fas fa-search"></i></button>
   </center><br><br>
   <center>
    <h5>Related communities</h5>
<div class="inline">     
            <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-pharmacies.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Pharmacies</a></p>        
            </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-resorts.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Resorts</a></p>  
            </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-t-pack.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Tour Packages</a></p> 
             </div>
              <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-groceries.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Groceries</a></p> 
             </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-vehicles.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Vehicle for Rent</a></p> 
             </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-s-souviner.jfif" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Surf Shops and Souviner</a></p> 
             </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-bar-resto.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Bar and Restaurant</a></p> 
             </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-bakeries.jfif" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Bakeries</a></p> 
             </div>
             <div class="wrap">
            <img class="rel" src="./sisa-images/sisa-coffee-s.jpg" height="80" width="80" alt="icon" />
            <p><a href="#" id="wrap-color"> Coffee Shops</a></p> 
             </div>
 </div>
   </center>
</div>


</div>
</div>


  <!-- Footer -->
  <?php include("footer.php"); ?>
        
</main>
</div>
</body>
</html>
