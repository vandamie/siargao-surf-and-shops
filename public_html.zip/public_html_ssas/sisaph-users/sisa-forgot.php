<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
    <!-- SISA PH TAB ICON -->
    <link rel="icon"  type="image" href="./sisa-images/sisa-logo.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="./sisa-css/sisaph-login.css" rel="stylesheet">

    <title>SISA PH Forgot Page</title>

  </head>
  <body class="text-center">
  <form class="form-login">
      <img class="mb-2 rounded-circle" src="./sisa-images/sisa-logo.jpg" alt="logo" width="50" height="50">
  <h1 class="h3 mb-3 font-weight-normal">Siargao Island Surfer's Association</h1>
    <i class="fa fa-envelope"></i>
  <input type="email" id="inputEmail" class="form-control" placeholder="Enter your email" required autofocus>
  <button class="btn btn-lg btn-primary btn-block" id="login" type="submit">Submit</button>

  <p class="mt-5 mb-3 ">&copy; 2020-2021</p>
</form>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  </body>
</html>