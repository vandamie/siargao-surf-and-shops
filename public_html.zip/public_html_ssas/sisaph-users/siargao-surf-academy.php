<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SISA TAB ICON -->
  <link rel="icon" type="image" href="sisa-images/sisa-logo.jpg">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Siargao Surf Academy, About</title>
</head>
<body>

  <!-- MAIN (Center website) -->
  <div class="main-surf-schools">

    <div class="bg-surf-schools" style="background-image:url('sisa-images/bg-surf-schools-sample.jpg');"><center><h5><img src="sisa-images/siargao-surf-academy.jpg" alt="Siargao Surf Academy.jpg" class="logo-in-surf-schools"> Siargao Surf Academy</h5></center></div><br>
    <div class="buttons-surf-schools"> 
    <button class="btn-surf-schools" id="1"> About</button>
    <button class="btn-surf-schools" id="2"> Certified Surfing Instructor</button>
    <button class="btn-surf-schools" id="3"> Surf Packages</button>
    <button class="btn-surf-schools" id="4"> Others</button>
  </div>
    

    <div class="row-surf-schools">
      <div class="content-surf-schools" id="content-show">
        <center><h5>About</h5></center>
        <p>We offer private surf lessons for all levels, group surf lessons, surf guiding, board rentals and kids surf lessons in the beautiful island of Siargao. Headed by ISA certified, professional surfer & Philippine Surf Athlete, Piso Alcala.</p>
      </div>
    </div> 

  </div>

  <!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
<!-- font-awesome icons link source -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>

  ///Load data from the page
  $(document).ready(function(){

    $("#1").click(function(){
      $("#content-show").load("sia-surf-about.php");
    });

    $("#2").click(function(){
      $("#content-show").load("sia-surf-cer-sur-ins.php");
    });

    $("#3").click(function(){
      $("#content-show").load("sia-surf-pac.php");
    });

    $("#4").click(function(){
      $("#content-show").load("sia-surf-others.php");
    });

  });
</script>

</body>
</html>

