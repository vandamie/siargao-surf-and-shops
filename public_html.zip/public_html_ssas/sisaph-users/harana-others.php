<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Harana Surf Resort Surf, Others</title>
</head>
<body>

   <div class="content">
    <center><h5>Others</h5></center>
     <p><strong>**JOIN OUR ULTIMATE SURF CAMP**</strong><br><br>  
8 Days / 7 Nights Ultimate Surf Training Camp in Siargao
Learning to surf is never easy. Regardless of how sporty or good you are with balance, you won’t be catching waves and looking awesome after your first, second, or even third session. It involves fitness, focus, patience, a good instructor, and most importantly, water time. If you’re really serious about learning to surf, Our 7-day Ultimate Surf Training Camp is meant for you. It involves not just one, but 5 surf lessons, both on land and in the water, accompanied by pre surf stretches and exercises that will help you paddle and pop up with more ease. We’ll also include post surf analysis so you can see what you can improve on for the next session.<br><br> 
Get in shape with our daily Surf Fit program and end your day with a deep tissue massage to help with recovery. The package also comes with 7-night accommodation in Harana Resort, lunch every day, roundtrip airport transfers, a gift bag, a USB filled with photos of the entire experience, a certificate of participation and welcome and goodbye dinners.<br> 
<strong>Whom This Camp For:</strong><br> 
<strong>This camp will be perfect for beginner surfers:</strong><br> 
<strong>You have never tried surfing</strong><br> 
You had several surf lessons but need more practice to be able to catch your own waves or start turning your board.
If you want to move from long board to shorter ones<br> 
What Is Included:<br> 
<strong>7 nights / 8 days accommodation with breakfast</strong><br> 
<strong>5 daily before surfing stretch</strong><br> 
<strong>5 daily surf lessons (theory, in the water)</strong><br> 
post surf analysis<br>
<strong>5 classes of surf fit</strong><br> 
<strong>every day lunch<br> 
<strong>1 deep tissue massage</strong><br> 
<strong>gift bag (rash guard, t-shirt, tumbler, cap, stickers)</strong><br> 
<strong>usb with photos from surfing & camp</strong><br> 
<strong>certificate of participation</strong><br> 
<strong>welcome & good-bye dinners</strong><br> 
<strong>What Is Not Included</strong><br> 
<strong>flights to Siargao</strong><br> 
<strong>Tours</strong><br> 
<strong>Surf Instruction</strong><br> 
Surf Training will be led by our experienced team of instructors, who know Siargao breaks as their 5 fingers. All of our instructors are certified by the local Surfing Association (SISA) and some had been trained by ISA (International Surfing Association). They have years of teaching experience in Siargao and will make sure that you have the smooth progression in the safe environment.<br><br> 
Each of surf lessons will include classroom lecture and one-on-one water training. After surf session our instructors will go thru video and photo analysis of your time in the water to help you understand what to improve during future lessons. After the course you will receive the certificate of participation, main highlights of the course with tips from our instructors what you need to work on further.<br><br>  
<strong>Surf Fit Classes</strong><br> 
Our Surf Fit lessons will become great addition to your surf training and will help you to develop strength and stamina which are much needed during surfing sessions. Work on the set of muscles you will need for strong paddling, work on your balance to be able to be on top of your board for longer.<br> <br> 
<strong>Accommodation</strong><br> 
You will stay in Harana’s Community Villa, good for up to 10 people. If you come as a couple we have deluxe villa available for some of dates. Please, send an inquiry to check availability. Learn more about accommodation here.</p>
   </div>

</body>
</html>

