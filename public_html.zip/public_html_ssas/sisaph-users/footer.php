  
   <!-- Modal Info-->
<div class="modal fade" id="info" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
<center><img class="mb-4" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>          
 <center><h5 class="modal-title">How can we help you?</h5></center>
  <ul id="inf">
  <li><a href="" id="inf">How to change my password?</a></li>
    <li><a href="" id="inf">How to link my bank card?</a></li>
      <li><a href="" id="inf">How to chat with my instructor?</a></li>
      <li><a href="" id="inf">Can I pay them cash on hand?</a></li>
   </ul>
  <dl>
  <dt>Email Us:</dt>
  <dd>siargao.web.protocol@gmail.com</dd>
</dl>
<center><h5>Contact Us:</h5></center>
<form class="form-login" method="POST" name="">
<center><h6><?php echo $error3; ?></h6></center>
  <label for="inputEmail" class="sr-only">Complete Name</label>
  <center><i class="fas fa-user"></i></center>
  <input type="text" name="c_name" class="form-control" placeholder="Complete Name" required autofocus>
  <label for="inputEmail" class="sr-only">Email Address</label>
  <center><i class="fas fa-envelope"></i></center>
  <input type="email" name="c_email" class="form-control" placeholder="Email Address" required autofocus>
   <label for="inputEmail" class="sr-only">Subject</label>
   <center><i class="fas fa-book-open"></i></center>
  <input type="text" name="c_subject" class="form-control" placeholder="Write Subject" required autofocus>
  <label for="message" class="sr-only">Message</label>
  <center><i class="fas fa-edit"></i></center>
<textarea type="message" name="c_message" class="form-control" placeholder="Write Message" required autofocus></textarea>
      </div>
      <div class="modal-footer">
        <button id="color" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input id="color" type="submit" class="btn btn-primary" name="submit-con" value="Submit">
      </div>
      </form>
    </div>
  </div>
</div>


<!-- Modal Register-->
<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="register" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
 <form class="form-login" method="post" name="reg">
  <center><img class="mb-4" style="border-radius: 7px;" src="sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>
  <center><h5 class="modal-title" style="text-align:center;">Register</h5></center>
  <spa><?php echo $error2; ?></spa>
  <center><i class="fas fa-user"></i></center>
  <label for="inputUser" class="sr-only">User Name</label>
  <input type="text" type="text" name="cus_name"  class="form-control" placeholder="User Name" required autofocus>
  <center><i class="fas fa-envelope"></i></center>
    <center><label for="inputEmail" class="sr-only">Email Address</label>
  <input type="email" name="cus_email"  class="form-control" placeholder="Email Address" required autofocus>
  <i class="fas fa-key"></i></center>
  <center><label for="inputPassword" class="sr-only">Password</label>
   <input type="password" name="cus_password"  class="form-control" placeholder="Password" required autofocus>
 <br>
  <div class="checkbox mb-3">
   <center><label>
<input type="checkbox" id="check_agree" value="remember-me"> I agree to Siargao Surf and Shops&nbsp;<a id="inf" href="#" data-toggle="modal" data-target="#pri-pol">Privacy Policy</a>&nbsp;and&nbsp;<a id="inf" href="#" data-toggle="modal" data-target="#con">Terms and Conditions</a>
    </label></center>
  </div>
      </div>
      <div class="modal-footer">
        <button id="color" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input id="color" type="submit" class="btn btn-primary" name="submit-reg" value="Submit">
        </form>
      </div>
    </div>
  </div>
</div>

   <!-- The Modal of Privacy Policy -->
   <div class="modal fade bd-example-modal-lg" id="pri-pol" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Siargao Surf and Shops Privacy Policy</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <center><p>Ongoing Development</p></center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>

   <!-- The Modal of Conditions -->
   <div class="modal fade bd-example-modal-lg" id="con" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Siargao Surf and Shops Conditions</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <center><p>Ongoing Development</p></center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>
  

<!-- Modal Sign In-->
<div class="modal fade" id="signin" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
       <form class="form-login" method="post" name="login">
  <center><img class="mb-4" style="border-radius: 7px;" src="sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>
  <span><?php echo "$error1"; ?></span>
  <label for="inputEmail" class="sr-only">User Name</label>
  <center><i class="fas fa-user"></i></center>
  <input type="text" id="cname" name="cname" class="form-control" placeholder="User Name" required>
  <label for="inputPassword" class="sr-only">Password</label>
 <center><i class="fas fa-key"></i></center>
  <input type="password" name="cpassword"  class="form-control" placeholder="Password" required>
  <br>
  <div class="checkbox mb-3">
   <center><label><input type="checkbox" id="check_login" value="remember-me"> Remember me</label></center>
   <center><p>You can't login? <a id="inf" href="" data-toggle="modal" data-target="#sec">forgot password.</a></p></center>
      </div>
      </div>
      <div class="modal-footer">
        <button id="color" type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input id="color" type="submit" class="btn btn-primary" name="submit-log" value="Sign In">
        </form>
      </div>
    </div>
  </div>
</div>


<!-- Modal Security-->
<div class="modal fade" id="sec" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
        <form class="form-login">
          <center><img class="mb-2" style="border-radius: 7px;" src="sisa-images/ssas-logo.png" alt="logo" width="50" height="50"></center>
          <h5 class="modal-title" style="text-align:center;">Siargao Surf and Shops</h5>

          <center><i class="fa fa-envelope"></i></i>&nbsp;why&nbsp;<i class="fa fa-question-circle" data-toggle="tooltip" data-placement="bottom" title="We need your valid email address to verify your account and to send the recovery link for your account."></i></center>
          <input type="email" id="inputEmail" class="form-control" placeholder="Enter your email" required autofocus>
          <br>
          <button class="btn btn-lg btn-primary btn-block" id="login" type="submit">Submit</button>

          <center><p class="mt-5 mb-3 ">&copy; 2020-2021</p></center>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="submit-log" value="Submit">
      </form>
    </div>
  </div>
</div>
</div>


<!-- FOOTER -->
<footer class="pt-4 my-md-5 pt-md-5 border-top">
  <div class="row">
    <div class="col-12 col-md">
      <img class="mb-2" src="./sisa-images/ssas-logo.png" alt="" width="25" height="25">
      <small class="d-block mb-3 text-muted">&copy; 2020-2021</small>
      <small class="d-block mb-3">Social Media Links</small>
      <ul class="list-unstyled text-small">
        <a href="https://web.facebook.com/SIARGAOISA"><i id="fb" class="fa fa-facebook"></i></a>
        <a href="https://youtu.be/IVlVlFC79cI"><i id="yt" class="fa fa-youtube"></i></a>
        <a href="https://www.instagram.com/sisa.siargao/"><i id="ig" class="fa fa-instagram"></i></a>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Features</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="sisaph_events_og.php">SISA Events</a></li>
        <li><a class="text-muted" href="sisaph_rankings.php">SISA Rankings</a></li>
        <li><a class="text-muted" href="http://sisaph.000webhostapp.com/sisaph-judging/">SISA Live Score</a></li>
        <li><a class="text-muted" href="iao-surf-schools.php">SI Accridited Surf Schools</a></li>
        <li><a class="text-muted" href="iao-surf-spots.php">Surf Spots</a></li>
        <li><a class="text-muted" href="sisa-p-merchants.php">Partner Merchants</a></li>
        <li><a class="text-muted" href="ssas-community.php">SSAS Community</a></li>
        <li><a class="text-muted" href="#">Supported Foundation - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
        <li><a class="text-muted" href="#">Job Offers - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Sponsor</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="http://siargao-web-protocol.000webhostapp.com/">Siargao Web Protocol</a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Siargao Surf and Shops</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="sisaph-about.php">About</a></li>
        <li><a class="text-muted" href="sisaph-history.php">History</a></li>
        <li><a class="text-muted" href="sisaph-privacy-policy.php">Privacy Policy</a></li>
        <li><a class="text-muted" href="sisaph-conditions.php">Terms and Conditions</a></li>
        <li><a class="text-muted" href="#">Terms of Service</a></li>
        <li><a class="text-muted" href="#">Return and Refund</a></li>
        <li><a class="text-muted" href="#">Cookies Policy</a></li>
        <li><a class="text-muted" href="#">Disclaimer</a></li>
      </ul>
    </div>
  </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

<script>
  //showing data from  logo when focus
  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
  });
  //Avoid resubmitting the form confirmation
  if ( window.history.replaceState ) {
    window.history.replaceState( null, null, window.location.href );
  }
</script>

<?php 
  //Set a cookies when checked the remember me checkbox
if(isset($_COOKIE['cname'])){
$cname = $_COOKIE['cname'];
echo "
<script>
document.getElementById('cname').value = '$cname';
</script>
";
}
?>
