    <!-- Modal Info-->
<div class="modal fade" id="reg-info" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
 <center><img class="mb-4" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>           
 <center><h2 class="h3 mb-3 font-weight-normal">How can we help you?</h2></center>
  <ul style="text-align:left;">
  <li><a href="">How to change my password?</a></li>
    <li><a href="">How to link my bank card?</a></li>
      <li><a href="">How to chat with my instructor?</a></li>
      <li><a href="">Can I pay them cash on hand?</a></li>
   </ul>
  <dl>
  <dt>Email Us:</dt>
  <dd>siargao.web.protocol@gmail.com</dd>
</dl>
<center><h5>Contact Us:</h5></center>
<form class="form-login" method="POST" name="">
<center><h6><?php echo $error3; ?></h6></center>
  <label for="inputEmail" class="sr-only">Complete Name</label>
  <center><i class="fas fa-user"></i></center>
  <input type="text" name="c_name" class="form-control" placeholder="Complete Name" required autofocus>
  <label for="inputEmail" class="sr-only">Email Address</label>
  <center><i class="fas fa-envelope"></i></center>
  <input type="email" name="c_email" class="form-control" placeholder="Email Address" required autofocus>
   <label for="inputEmail" class="sr-only">Subject</label>
   <center><i class="fas fa-book-open"></i></center>
  <input type="text" name="c_subject" class="form-control" placeholder="Write Subject" required autofocus>
  <label for="message" class="sr-only">Message</label>
  <center><i class="fas fa-edit"></i></center>
<textarea type="message" name="c_message" class="form-control" placeholder="Write Message" required autofocus></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="submit-con" value="Submit">
      </div>
      </form>
    </div>
  </div>
</div>