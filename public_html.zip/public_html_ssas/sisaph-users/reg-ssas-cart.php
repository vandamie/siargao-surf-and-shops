<?php 
session_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();
ob_start();
$cus_name = $_SESSION['customer_id'];
$cus_stat = $_SESSION['customer_id'];
$cus_status = $_SESSION['customer_id'];
//$user_profile = $_SESSION['id'];

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:../index.php");
}else{
  $sql = "UPDATE customers SET cus_status = 'Online' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../sisaph-history.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php  
session_destroy();
session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] >900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
    ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully for security reason.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}else {
  $_SESSION['cus_name'] = time();
}


//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops Official Website, History">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisa-images/ssas-logo.png">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
    <title>Siargao Surf and Shops Checkout Form</title>>
</head>
<body>
  <br><br><br><br><br>
  <!-- Header -->
  <?php include("reg-header.php"); ?>

<div class="container">
    <main role="main">  
 <div class="container">
  <div class="py-5 text-center">
    <img class="d-block mx-auto mb-4" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="50" height="50">
    <h2>Checkout form</h2>
    <p class="lead">We need your personal information to deliver your order into your place, if you have any complain don't hesitate to <a href="contact us" data-toggle="modal" data-target="#reg-info">contact us</a>.</p>
  </div>

  <div class="row">
    <div class="col-md-4 order-md-2 mb-4">
      <h4 class="d-flex justify-content-between align-items-center mb-3">
        <span class="text-muted">Your cart</span>
        <span class="badge badge-secondary badge-pill">0</span>
      </h4>
      <ul class="list-group mb-3">
        <li class="list-group-item d-flex justify-content-between">
          <span>Total (USD)</span>
          <strong>$0</strong>
        </li>
      </ul>

      <form class="card p-2">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Promo code">
          <div class="input-group-append">
            <button type="submit" class="btn btn-secondary">Redeem</button>
          </div>
        </div>
      </form>
    </div>
    <div class="col-md-8 order-md-1">
      <h4 class="mb-3">Billing address</h4>
      <form class="needs-validation" novalidate>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="firstName">First name</label>
            <input type="text" class="form-control" id="firstName" placeholder="" value="" required autofocus>
            <div class="invalid-feedback">
              Valid first name is required.
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="lastName">Last name</label>
            <input type="text" class="form-control" id="lastName" placeholder="" value="" required autofocus>
            <div class="invalid-feedback">
              Valid last name is required.
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label for="username">Username</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <span class="input-group-text">@</span>
            </div>
            <input type="text" class="form-control" id="username" placeholder="Username" required autofocus>
            <div class="invalid-feedback" style="width: 100%;">
              Your username is required.
            </div>
          </div>
        </div>

        <div class="mb-3">
          <label for="email">Email</label>
          <input type="email" class="form-control" id="email" placeholder="you@example.com" required autofocus>
          <div class="invalid-feedback">
            Please enter a valid email address for shipping updates.
          </div>
        </div>

        <div class="mb-3">
          <label for="address">Address</label>
          <input type="text" class="form-control" id="address" placeholder="1234 Main St" required autofocus>
          <div class="invalid-feedback">
            Please enter your shipping address.
          </div>
        </div>

        <div class="mb-3">
          <label for="address2">Address 2 <span class="text-muted">(Optional)</span></label>
          <input type="text" class="form-control" id="address2" placeholder="Apartment or suite">
        </div>

        <div class="row">
          <div class="col-md-5 mb-3">
            <label for="country">Country</label>
            <select class="custom-select d-block w-100" id="country" required autofocus>
              <option value="">Choose...</option>
              <option>United States</option>
            </select>
            <div class="invalid-feedback">
              Please select a valid country.
            </div>
          </div>
          <div class="col-md-4 mb-3">
            <label for="state">State</label>
            <select class="custom-select d-block w-100" id="state" required autofocus>
              <option value="">Choose...</option>
              <option>California</option>
            </select>
            <div class="invalid-feedback">
              Please provide a valid state.
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <label for="zip">Zip</label>
            <input type="text" class="form-control" id="zip" placeholder="" required autofocus>
            <div class="invalid-feedback">
              Zip code required.
            </div>
          </div>
        </div>
        <hr class="mb-4">
        <div class="custom-control custom-checkbox">
          <input type="checkbox" class="custom-control-input" id="same-address">
          <label class="custom-control-label" for="same-address">Shipping address is the same as my billing address</label>
        </div>
        <div class="custom-control custom-checkbox">
          <input type="checkbox" class="custom-control-input" id="save-info">
          <label class="custom-control-label" for="save-info">Save this information for next time</label>
        </div>
        <hr class="mb-4">

        <h4 class="mb-3">Payment</h4>

        <div class="d-block my-3">
          <div class="custom-control custom-radio">
            <input id="credit" name="paymentMethod" type="radio" class="custom-control-input" required autofocus>
            <label class="custom-control-label" for="credit">Credit card</label>
          </div>
          <div class="custom-control custom-radio">
            <input id="debit" name="paymentMethod" type="radio" class="custom-control-input" required autofocus>
            <label class="custom-control-label" for="debit">Debit card</label>
          </div>
          <div class="custom-control custom-radio">
            <input id="paypal" name="paymentMethod" type="radio" class="custom-control-input" required autofocus>
            <label class="custom-control-label" for="paypal">PayPal</label>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="cc-name">Name on card</label>
            <input type="text" class="form-control" id="cc-name" placeholder="" required autofocus>
            <small class="text-muted">Full name as displayed on card</small>
            <div class="invalid-feedback">
              Name on card is required
            </div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="cc-number">Credit card number</label>
            <input type="text" class="form-control" id="cc-number" placeholder="" required autofocus>
            <div class="invalid-feedback">
              Credit card number is required
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 mb-3">
            <label for="cc-expiration">Expiration</label>
            <input type="text" class="form-control" id="cc-expiration" placeholder="" required autofocus>
            <div class="invalid-feedback">
              Expiration date required
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <label for="cc-cvv">CVV</label>
            <input type="text" class="form-control" id="cc-cvv" placeholder="" required autofocus>
            <div class="invalid-feedback">
              Security code required
            </div>
          </div>
        </div>
        <hr class="mb-4">
        <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
      </form>
    </div>
  </div>
  
</div>



<!-- Modal Info-->
<div class="modal fade" id="reg-info" tabindex="-5" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
       <center><img class="mb-2" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>      
       <center><h3 class="h3 mb-3 font-weight-normal">How can we help you?</h3></center>
       <ul id="inf">
        <li><a href="#" id="inf">How to change my password?</a></li>
        <li><a href="#" id="inf">How to link my bank card?</a></li>
        <li><a href="#" id="inf">How to chat with my instructor?</a></li>
        <li><a href="#" id="inf">Can I pay them cash on hand?</a></li>
      </ul>
      <dl>
        <dt>Email Us:</dt>
        <dd>siargao.web.protocol@gmail.com</dd>
      </dl>
      <center><h5>Contact Us:</h5></center>
      <form class="form-login" method="POST" name="">
        <center><h6><?php echo $error3; ?></h6></center>
        <label for="inputEmail" class="sr-only">Complete Name</label>
        <center><i class="fas fa-user"></i></center>
        <input type="text" name="c_name" class="form-control" placeholder="Complete Name" required autofocus>
        <label for="inputEmail" class="sr-only">Email Address</label>
        <center><i class="fas fa-envelope"></i></center>
        <input type="email" name="c_email" class="form-control" placeholder="Email Address" required autofocus>
        <label for="inputEmail" class="sr-only">Subject</label>
        <center><i class="fas fa-book-open"></i></center>
        <input type="text" name="c_subject" class="form-control" placeholder="Write Subject" required autofocus>
        <label for="message" class="sr-only">Message</label>
        <center><i class="fas fa-edit"></i></center>
        <textarea type="message" name="c_message" class="form-control" placeholder="Write Message" required autofocus></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="submit-con" value="Submit">
      </div>
    </form>
  </div>
</div>
</div> 

<?php include("reg-footer.php"); ?>
 
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <!-- font-awesome icons link source -->
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function user_drop() {
  document.getElementById("my_user_drop").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}


//Avoid resubmitting the form confirmation

if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

      </main>
    </div>     
</body>
</html>