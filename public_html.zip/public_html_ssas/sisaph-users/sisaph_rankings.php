
<?php
session_unset(); 
// Report all errors
error_reporting(E_ALL);
//error_reporting(0);
ob_start();
require_once ("./include/db-con.php"); // database.
require_once ("./include/class.user.php");//connection to database and public functions
$user = new User();//connection to public User function
//----------------------SQL 2021 LOOP-------------------------//
require_once("sql_data_ranking.php");

//----------------------YEAR 2021 LOOP-------------------------//
require_once("loop_rankings.php");
?>


<?php
//-------------------------------Log in------------------------------//
$error1='';
if (isset($_POST['submit-log'])) {  // posting data after submit button.
  session_start(); // session start means you are setting the name of user to next page after click logi.
  extract($_POST); //extracting all data  from database.   
  $login = $user->check_login($cname, $cpassword); // calling function verification process.
  $error1='';
  if ($login) {
          // Login Success
   ?>
   <!doctype html>
   <html lang="en">
   <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed in successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='reg_sisaph_rankings.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
          // Login Failed
 $error1 = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Wrong <strong>user name or password</strong> or your <strong>account</strong> is need for the <strong>admin approval.</strong>
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Register------------------------------//
$error2= '';
if (isset($_POST['submit-reg'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$register = $user->reg_user($cus_name, $cus_password, $cus_email);
$error2= '';
if ($register) {
            // Registration Success
 $error2= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Registration successfully. <a href="" data-toggle="modal" data-target="#login">Click here</a> to login
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
} else {
            // Registration Failed
 $error2= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Registration failed. <strong>Email or Username</strong> already exist please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops Official Website, SISA Rankings">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisa-images/ssas-logo.png">
    <!-- font-awesome icons link source -->
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
  <title>SSAS, SISA Rankings</title>
</head>
<body> 
  <?php include("header.php"); ?>

  <div class="container">
    <main role="main">     
     <div class="container" style="padding:105px 10px 50px 10px;">
      <center><h5>The Rankings</h5></center>
      <form method="GET">
        Select: <select name="rankings" id="c_rankings">
          <option value="All Years">All Division</option>
          <option value="Men's Shortboard">Men's Shortboard</option>
          <option value="Women's Shortboard">Women's Shortboard</option>
          <option value="Junior Shortboard">Junior Shortboard</option>
          <option value="Grommet Women Shortboard">Grommet Women Shortboard</option>
          <option value="Grommet Men Shortboar">Grommet Men Shortboard</option>
          <option value="Men's Longboard">Men's Longboard</option>
          <option value="Women's Longboard">Women's Longboard</option>
        </select>
      </form>
      <table class="table table-hover table-borderless" id="d_rankings">
        <?php print "$sql_rank_head".""."$sql_rank_bod"; ?>
        <?php print "$sql_rank_head_womens_short".""."$sql_rank_bod_womens_short"; ?>
        <?php print "$sql_rank_head_junior_short".""."$sql_rank_bod_junior_short"; ?>
        <?php print "$sql_rank_head_grommet_women_short".""."$sql_rank_bod_grommet_women_short"; ?>
        <?php print "$sql_rank_head_grommet_men_short".""."$sql_rank_bod_grommet_men_short"; ?>
        <?php print "$sql_rank_head_mens_long".""."$sql_rank_bod_mens_long"; ?>
        <?php print "$sql_rank_head_womens_long".""."$sql_rank_bod_womens_long"; ?>
      </table>
    </div>

    <script type="text/javascript">
            //Load data rankings on the page
            $(document).ready(function(){  
              $("select").change(function(){

                var rankings = $("select").val();  
                $.ajax({
                  url:"load_sisaph_rankings.php",  
                  method:"GET",  
                  data_rankings:{c_rankings:rankings},  
                  success:function(data_rankings){  
                    $("#d_rankings").html(data_rankings);

                  }  
                });  
              });  
            });
          </script>


          <?php include("footer.php"); ?>

        </main>
      </div>
    </body>
    </html> 