<?php 
// Report all errors
error_reporting(E_ALL);
//error_reporting(0);
ob_start();
session_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();
$cus_name = $_SESSION['customer_id'];
$cus_stat = $_SESSION['customer_id'];
$cus_status = $_SESSION['customer_id'];
//$user_profile = $_SESSION['id'];

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:../index.php");
}else{
  date_default_timezone_set('Asia/Manila');
  $todays_date = date("y-m-d,h:i:sa");

  $sql = "UPDATE customers SET cus_status = 'Online', time_in = '$todays_date' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  date_default_timezone_set('Asia/Manila');
  $todays_date = date("y-m-d,h:i:sa");

  $sql = "UPDATE customers SET cus_status = 'Offline', time_out = '$todays_date' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        }
});
</script>
</body>
</html>
<?php
session_destroy();
session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['cus_name']) && ($t - $_SESSION['cus_name'] >900)) { 
  session_destroy();
  session_unset();
  date_default_timezone_set('Asia/Manila');
  $todays_date = date("y-m-d,h:i:sa");

  $sql = "UPDATE customers SET cus_status = 'Offline', time_out = '$todays_date' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
    ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully for security reason.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}else {
  $_SESSION['cus_name'] = time();
}


//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

?>



<?php
//////////////  QUERY THE MEMBER DATA INITIALLY LIKE YOU NORMALLY WOULD
$sql = mysqli_query($conn,"SELECT * FROM sisa_events ORDER BY ev_year ASC");
//////////////////////////////////// Pagination Logic ////////////////////////////////////////////////////////////////////////
$nr = mysqli_num_rows($sql); // Get total of Num rows from the database query
if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
    $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
    //$pn = ereg_replace("[^0-9]", "", $_GET['pn']); // filter everything but numbers for security(deprecated)
} else { // If the pn URL variable is not present force it to be value of page number 1
  $pn = 1;
}
//This is where we set how many database items to show on each page
$itemsPerPage = 2;
// Get the value of the last page in the pagination result set
$lastPage = ceil($nr / $itemsPerPage);
// Be sure URL variable $pn(page number) is no lower than page 1 and no higher than $lastpage
if ($pn < 1) { // If it is less than 1
    $pn = 1; // force if to be 1
} else if ($pn > $lastPage) { // if it is greater than $lastpage
    $pn = $lastPage; // force it to be $lastpage's value
  }
// This creates the numbers to click in between the next and back buttons
// This section is explained well in the video that accompanies this script
  $centerPages = "";
  $sub1 = $pn - 1;
  $sub2 = $pn - 2;
  $add1 = $pn + 1;
  $add2 = $pn + 2;
  if ($pn == 1) {
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
  } else if ($pn == $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
  } else if ($pn > 2 && $pn < ($lastPage - 1)) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
  } else if ($pn > 1 && $pn < $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
  }
// This line sets the "LIMIT" range... the 2 values we place to choose a range of rows from database in our query
  $limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage;
// Now we are going to run the same query as above but this time add $limit onto the end of the SQL syntax
// $sql2 is what we will use to fuel our while loop statement below
  require_once("sql_data.php");
//////////////////////////////// END Pagination Logic ////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////// Pagination Display Setup /////////////////////////////////////////////////////////////////////
$paginationDisplay = ""; // Initialize the pagination output variable
// This code runs only if the last page variable is ot equal to 1, if it is only 1 page we require no paginated links to display
if ($lastPage != "1"){
    // This shows the user what page they are on, and the total number of pages
  $paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
    // If we are not on page 1 we can place the Back button
  if ($pn != 1) {
    $previous = $pn - 1;
    $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"><i class="fa fa-chevron-circle-left" style="font-size:24px"></i></a> ';
  }
    // Lay in the clickable numbers display here between the Back and Next links
  $paginationDisplay .= '<span class="paginationNumbers">' . $centerPages . '</span>';
    // If we are not on the very last page we can place the Next button
  if ($pn != $lastPage) {
    $nextPage = $pn + 1;
    $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"><i class="fa fa-chevron-circle-right" style="font-size:24px"></i></a> ';
  }
}
///////////////////////////////////// END Pagination Display Setup ///////////////////////////////////////////////////////////////////////////
// Build the Output Section Here
//----------------------YEAR 2021 LOOP-------------------------//
require_once("loop_2021.php");

ob_end_flush();
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
   <meta name="description" content="Siargao Surf and Shops Official Website, SISA Events"> 
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SISA TAB ICON -->
  <link rel="icon" type="image" href="./sisa-images/ssas-logo.png">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="./sisa-css/style.css" rel="stylesheet">
  <title>SSAS, SISA Events</title>
</head>
<body>

  <?php include("reg-header.php"); ?>
  
  <div class="container" id="color">
    <main role="main">     
     <div class="container" style="padding:105px 10px 50px 10px;">
      <center><h5>The Events</h5></center>
      <form method="GET">
        Select: <select name="text" id="text">
          <option value="All Years">All Years</option>
          <option value="2021">2021</option>
        </select>
      </form>
      <table class="table table-hover table-borderless" id="d1">
        <?php print "$sql_2021_jan".""."$sql_j2"; ?>
        <?php print "$sql_2021_feb".""."$sql_f2"; ?>
        <?php print "$sql_2021_mar".""."$sql_m2"; ?>
        <?php print "$sql_2021_apr".""."$sql_a2"; ?>
        <?php print "$sql_2021_may".""."$sql_ma2"; ?>
        <?php print "$sql_2021_jun".""."$sql_ju2"; ?>
        <?php print "$sql_2021_jul".""."$sql_jl2"; ?>
        <?php print "$sql_2021_aug".""."$sql_au2"; ?>
        <?php print "$sql_2021_sep".""."$sql_sp2"; ?>
        <?php print "$sql_2021_oct".""."$sql_oc2"; ?>
        <?php print "$sql_2021_nov".""."$sql_no2"; ?>
        <?php print "$sql_2021_dec".""."$sql_de2"; ?>
      </table>
      <div class="page-item page-link" style="text-align:center;"><?php echo $paginationDisplay; ?></div>
    </div>


    <!-- AVOID RESUBMITTING -->
    <script>
      if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
      }
    </script> 

    <script>  
      $(document).ready(function(){  
        $("select").change(function(){

          var text = $("select").val();  
          $.ajax({  
            url:"load_sisaph_events_og.php",  
            method:"GET",  
            data:{text:text},  
            success:function(data){  
              $("#d1").html(data);

            }  
          });  
        });  
      });

    </script>

    <?php include("reg-footer.php"); ?>

  </main>
</div>
</body>
</html> 