<?php
//---------------------GET YEARS LOOPS-------------------------------//
//--------------------------YEAR 2021----------------------------//
//----------------------Months LOOP--------------------------------//
while($row = mysqli_fetch_array($sql_21_jan)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_jan2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_feb)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_feb2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_mar)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_mar2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_apr)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_apr2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_may)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_may2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_jun)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_jun2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_jul)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_jul2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_aug)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_aug2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_sep)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_sep2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_oct)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_oct2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_nov)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_nov2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_21_dec)){

    echo '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_dec2)){

    echo '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop

?>