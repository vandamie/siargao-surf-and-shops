<?php
//---------------------GET years and months LOOP-------------------------------//
while($row = mysqli_fetch_array($sql_jan1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Jan LOOP
while($row = mysqli_fetch_array($sql_jan2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_feb1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Feb LOOP
while($row = mysqli_fetch_array($sql_feb2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_mar1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_mar2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_apr1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_apr2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_may1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_may2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_jun1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_jun2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_jul1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_jul2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_aug1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_aug2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_sep1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_sep2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_oct1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_oct2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_nov1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_nov2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
while($row = mysqli_fetch_array($sql_dec1)){

    echo'
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
//for Mar LOOP
while($row = mysqli_fetch_array($sql_dec2)){

    echo'
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
 ?>