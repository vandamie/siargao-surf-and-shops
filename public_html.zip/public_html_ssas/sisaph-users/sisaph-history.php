<?php
session_start();
//-------------------------------Log in------------------------------//
require_once ("include/class.user.php");//connection to database and public functions
require_once ("../admin-sisaph-cms/classes/function.php"); // class of functions of User.
$user = new User();//connection to public User function
require_once ("../admin-sisaph-cms/classes/db-con.php"); // class of functions of User.




$error1='';
if (isset($_POST['submit-log'])) {  // posting data after submit button.
  extract($_POST); //extracting all data  from database.   
  $login = $user->check_login($cname, $cpassword); // calling function verification process.
  $error1='';
  if ($login) {
          // Login Success
   ?>
   <!doctype html>
   <html lang="en">
   <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed in successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='reg-sisaph-history.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
          // Login Failed
 $error1 = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Wrong <strong>user name or password</strong> or your <strong>account</strong> is need for the <strong>admin approval.</strong>
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Register------------------------------//
$error2= '';
if (isset($_POST['submit-reg'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$register = $user->reg_user($cus_name, $cus_password, $cus_email, $q_sec1,$sec_ans1,$q_sec2, $sec_ans2);
$error2= '';
if ($register) {
            // Registration Success
 $error2= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Registration successfully. <a href="" data-toggle="modal" data-target="#login">Click here</a> to login
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
} else {
            // Registration Failed
 $error2= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Registration failed. <strong>Email or Username</strong> already exist please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}



//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops Official Website, History">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="sisa-images/ssas-logo.png">
  <!-- font-awesome icons link source -->
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
  <title>SSAS History</title>
  <style>
   /* Table CSS */
   table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 450px;
  }

  th, td {
    text-align: left;
    padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
  <br><br><br><br><br>
  <!-- Header -->
  <?php include("header.php"); ?>

  <div class="container">
    <main role="main">

      <div class="bg-about" style="background-image: url('sisa-images/bg-history.jpg');">Siargao Surf and Shops. (or SSAS), History.</div><br>


         <div class="row featurette">
          <div class="col-md-12 order-md-15" style="overflow-x:auto;">

           <table class="table-responsive" id="events-img">
             <thead>
              <tr>
                <th>
                  <p><center><h5>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;History</h5></center></p><hr><br>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td> 
                  <P><h2 class="text-muted">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ongoing Development</h3></p>
                  </td>
                </tr>
              </tbody>
            </table>

          </div>
        </div>


        <!-- FOOTER -->
        <?php include("footer.php"); ?>


      </main>
    </div>
  </body>
  </html>
