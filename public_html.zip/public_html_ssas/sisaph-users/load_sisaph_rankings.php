<?php
//Load data
// Custom PHP MySQL Pagination 
$con = mysqli_connect("localhost", "id14326742_admin_sisaph", "S1@rg@0island", "id14326742_admin_cms");

if($_GET["text"]!='All Division'){
//---------------------GET MYSQL QUERY-------------------------------//
//---------------------Division-------------------------------//
// $sql2 for month January
$sql_data1 = mysqli_query($con,"SELECT * FROM sisaph_rankings WHERE r_division = '".$_GET["text"]."' ");


//---------------------GET MYSQL QUERY-------------------------------//
//---------------------Data-------------------------------//
// $sql2 for month January
$sql_data2 = mysqli_query($con,"SELECT * FROM sisaph_rankings WHERE  r_division = '".$_GET["text"]."' ");

//----------------------Rankings Loop for Men's Shortboard-------------------------//
while($row = mysqli_fetch_array($sql_data1)){

    echo'
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"].'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop


while($row = mysqli_fetch_array($sql_data2)){

     echo'
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop


}else{
$men_short1 = mysqli_query($con,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$men_short2 = mysqli_query($con,"SELECT * FROM sisaph_rankings"); 
require_once("loop_rankings.php");
}
?>