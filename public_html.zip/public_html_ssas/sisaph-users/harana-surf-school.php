<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SISA TAB ICON -->
  <link rel="icon" type="image" href="sisa-images/sisa-logo.jpg">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Harana Surf Resort, About</title>
</head>
<body>

  <!-- MAIN (Center website) -->
  <div class="main-surf-schools">

    <div class="bg-surf-schools" style="background-image:url('sisa-images/bg-surf-schools-sample.jpg');"><center><h5><img src="sisa-images/harana-surf-school.jpg" alt="Harana Surf School" class="logo-in-surf-schools"> Harana Surf School</h5></center></div><br>
    <div class="buttons-surf-schools"> 
    <button class="btn-surf-schools" id="1"> About</button>
    <button class="btn-surf-schools" id="2"> Certified Surfing Instructor</button>
    <button class="btn-surf-schools" id="3"> Surf Packages</button>
    <button class="btn-surf-schools" id="4"> Others</button>
  </div>
    

    <div class="row-surf-schools">
      <div class="content-surf-schools" id="content-show">
        <center><h5>About</h5></center>
        <p style="text-decoration:justify;">To be the best, you should learn from the best. We’ve put together some of the best surfers and instructors born and raised in Siargao Island to teach you all you need to be confident in the water.<br><br>

Our courses for beginners involve a detailed theory sessions every day in our classroom to help students understand the complex elements involved such as gear selection, reading the tides, swells, and of course, safety. After theory, step into the water and learn how to read and select the right waves, pop up with ease, and paddle into your own waves. If you want to get serious about surfing we recommend to take our 5-days beginner course. This course will teach you the basics you will need to become an independent surfer in the future. After finishing our 5-day course you will receive a certificate of participation and notes with main highlights of the course.<br><br>

If you take 5 days course we will arrange videographer to take videos of you during surfing  so you can see where to improve during post surf analysis. You have an option of hiring photographer yourself for shorter courses. The course follows the standard curriculum certified by ISA (International Surfing Association) and moderated by members of SISA (Siargao Island Surfers Association).<br><br>

For intermediate surfers we offer guiding to different local breaks as well as advance surfing lessons with our pro surfers.</p>
      </div>
    </div> 

  </div>

  <!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
<!-- font-awesome icons link source -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>

  ///Load data from the page
  $(document).ready(function(){

    $("#1").click(function(){
      $("#content-show").load("harana-about.php");
    });

    $("#2").click(function(){
      $("#content-show").load("harana-cer-sur-ins.php");
    });

    $("#3").click(function(){
      $("#content-show").load("harana-sur-pac.php");
    });

    $("#4").click(function(){
      $("#content-show").load("harana-others.php");
    });

  });
</script>

</body>
</html>

