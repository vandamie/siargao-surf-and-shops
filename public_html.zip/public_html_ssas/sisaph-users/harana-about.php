<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Harana Surf Resort Surf, About</title>
</head>
<body>

   <div class="content">
    <center><h5>About</h5></center>
     <p style="text-decoration:justify;">To be the best, you should learn from the best. We’ve put together some of the best surfers and instructors born and raised in Siargao Island to teach you all you need to be confident in the water.<br><br>

Our courses for beginners involve a detailed theory sessions every day in our classroom to help students understand the complex elements involved such as gear selection, reading the tides, swells, and of course, safety. After theory, step into the water and learn how to read and select the right waves, pop up with ease, and paddle into your own waves. If you want to get serious about surfing we recommend to take our 5-days beginner course. This course will teach you the basics you will need to become an independent surfer in the future. After finishing our 5-day course you will receive a certificate of participation and notes with main highlights of the course.<br><br>

If you take 5 days course we will arrange videographer to take videos of you during surfing  so you can see where to improve during post surf analysis. You have an option of hiring photographer yourself for shorter courses. The course follows the standard curriculum certified by ISA (International Surfing Association) and moderated by members of SISA (Siargao Island Surfers Association).<br><br>

For intermediate surfers we offer guiding to different local breaks as well as advance surfing lessons with our pro surfers.</p>
   </div>

</body>
</html>

