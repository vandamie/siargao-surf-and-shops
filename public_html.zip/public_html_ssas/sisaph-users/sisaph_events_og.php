
<?php
session_unset();
// Report all errors
error_reporting(E_ALL);
//error_reporting(0);
ob_start();
require_once ("./include/class.user.php");//connection to database and public functions
require_once ("./include/db-con.php"); // database.
$user = new User();//connection to public User function
//////////////  QUERY THE MEMBER DATA INITIALLY LIKE YOU NORMALLY WOULD
$sql = mysqli_query($conn,"SELECT * FROM sisa_events ORDER BY ev_year ASC");
//////////////////////////////////// Pagination Logic ////////////////////////////////////////////////////////////////////////
$nr = mysqli_num_rows($sql); // Get total of Num rows from the database query
if (isset($_GET['pn'])) { // Get pn from URL vars if it is present
    $pn = preg_replace('#[^0-9]#i', '', $_GET['pn']); // filter everything but numbers for security(new)
    //$pn = ereg_replace("[^0-9]", "", $_GET['pn']); // filter everything but numbers for security(deprecated)
} else { // If the pn URL variable is not present force it to be value of page number 1
  $pn = 1;
}
//This is where we set how many database items to show on each page
$itemsPerPage = 2;
// Get the value of the last page in the pagination result set
$lastPage = ceil($nr / $itemsPerPage);
// Be sure URL variable $pn(page number) is no lower than page 1 and no higher than $lastpage
if ($pn < 1) { // If it is less than 1
    $pn = 1; // force if to be 1
} else if ($pn > $lastPage) { // if it is greater than $lastpage
    $pn = $lastPage; // force it to be $lastpage's value
  }
// This creates the numbers to click in between the next and back buttons
// This section is explained well in the video that accompanies this script
  $centerPages = "";
  $sub1 = $pn - 1;
  $sub2 = $pn - 2;
  $add1 = $pn + 1;
  $add2 = $pn + 2;
  if ($pn == 1) {
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
  } else if ($pn == $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
  } else if ($pn > 2 && $pn < ($lastPage - 1)) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub2 . '">' . $sub2 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add2 . '">' . $add2 . '</a> &nbsp;';
  } else if ($pn > 1 && $pn < $lastPage) {
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $sub1 . '">' . $sub1 . '</a> &nbsp;';
    $centerPages .= '&nbsp; <span class="pagNumActive">' . $pn . '</span> &nbsp;';
    $centerPages .= '&nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $add1 . '">' . $add1 . '</a> &nbsp;';
  }
// This line sets the "LIMIT" range... the 2 values we place to choose a range of rows from database in our query
  $limit = 'LIMIT ' .($pn - 1) * $itemsPerPage .',' .$itemsPerPage;
// Now we are going to run the same query as above but this time add $limit onto the end of the SQL syntax
// $sql2 is what we will use to fuel our while loop statement below
  require_once("sql_data.php");
//////////////////////////////// END Pagination Logic ////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////// Pagination Display Setup /////////////////////////////////////////////////////////////////////
$paginationDisplay = ""; // Initialize the pagination output variable
// This code runs only if the last page variable is ot equal to 1, if it is only 1 page we require no paginated links to display
if ($lastPage != "1"){
    // This shows the user what page they are on, and the total number of pages
  $paginationDisplay .= 'Page <strong>' . $pn . '</strong> of ' . $lastPage. '&nbsp;  &nbsp;  &nbsp; ';
    // If we are not on page 1 we can place the Back button
  if ($pn != 1) {
    $previous = $pn - 1;
    $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '"><i class="fa fa-chevron-circle-left" style="font-size:24px"></i></a> ';
  }
    // Lay in the clickable numbers display here between the Back and Next links
  $paginationDisplay .= '<span class="paginationNumbers">' . $centerPages . '</span>';
    // If we are not on the very last page we can place the Next button
  if ($pn != $lastPage) {
    $nextPage = $pn + 1;
    $paginationDisplay .=  '&nbsp;  <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $nextPage . '"><i class="fa fa-chevron-circle-right" style="font-size:24px"></i></a> ';
  }
}
///////////////////////////////////// END Pagination Display Setup ///////////////////////////////////////////////////////////////////////////
// Build the Output Section Here
//----------------------YEAR 2021 LOOP-------------------------//
require_once("loop_2021.php");
?>


<?php
//-------------------------------Log in------------------------------//
$error1='';
if (isset($_POST['submit-log'])) {  // posting data after submit button.
  session_start(); // session start means you are setting the name of user to next page after click login.
  extract($_POST); //extracting all data  from database.   
  $login = $user->check_login($cname, $cpassword); // calling function verification process.
  $error1='';
  if ($login) {
          // Login Success
   ?>
   <!doctype html>
   <html lang="en">
   <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed in successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='reg_sisaph_rankings.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
          // Login Failed
 $error1 = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Wrong <strong>user name or password</strong> or your <strong>account</strong> is need for the <strong>admin approval.</strong>
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Register------------------------------//
$error2= '';
if (isset($_POST['submit-reg'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$register = $user->reg_user($cus_name, $cus_password, $cus_email);
$error2= '';
if ($register) {
            // sending Success
 $error2= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Registration successfully. <a href="" data-toggle="modal" data-target="#login">Click here</a> to login
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
} else {
            // Registration Failed
 $error2= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Registration failed. <strong>Email or Username</strong> already exist please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops Official Website, SISA Events">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisa-images/ssas-logo.png">
  <!-- font-awesome icons link source -->
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="./sisa-css/style.css" rel="stylesheet">
  <title>SSAS,SISA Events</title>
</head>
<body>   
  <?php include("header.php"); ?>

  <div class="container">
    <main role="main">     
     <div class="container" style="padding:105px 10px 50px 10px;">
      <center><h5>The Events</h5></center>
      <form method="GET">
        Select: <select name="events" id="c_events">
          <option value="All Years">All Years</option>
          <option value="2021">2021</option>
        </select>
      </form>
      <table class="table table-hover table-borderless" id="d_events">
        <?php print "$sql_2021_jan".""."$sql_j2"; ?>
        <?php print "$sql_2021_feb".""."$sql_f2"; ?>
        <?php print "$sql_2021_mar".""."$sql_m2"; ?>
        <?php print "$sql_2021_apr".""."$sql_a2"; ?>
        <?php print "$sql_2021_may".""."$sql_ma2"; ?>
        <?php print "$sql_2021_jun".""."$sql_ju2"; ?>
        <?php print "$sql_2021_jul".""."$sql_jl2"; ?>
        <?php print "$sql_2021_aug".""."$sql_au2"; ?>
        <?php print "$sql_2021_sep".""."$sql_sp2"; ?>
        <?php print "$sql_2021_oct".""."$sql_oc2"; ?>
        <?php print "$sql_2021_nov".""."$sql_no2"; ?>
        <?php print "$sql_2021_dec".""."$sql_de2"; ?>
      </table>
      <div class="page-item page-link" style="text-align:center;"><?php echo $paginationDisplay; ?></div>
    </div>
    
    <script type="text/javascript">
           //Load data events on the page
           $(document).ready(function(){  
            $("select").change(function(){

              var events = $("select").val();  
              $.ajax({  
                url:"load_sisaph_events_og.php",  
                method:"GET",  
                data_events:{c_events:events},  
                success:function(data_events){  
                  $("#d_events").html(data_events);

                }  
              });  
            });  
          });
        </script>

 
        <?php include("footer.php"); ?>

      </main>
    </div>
  </body>
  </html> 