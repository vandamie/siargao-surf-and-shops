

<div class="container">
  <main role="main">

    <!-- Youtube Videos -->
    <iframe src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2FSIARGAOISA%2Fvideos%2F259024914963682%2F&show_text=true&width=1020" width="560" height="429" style="border:none;overflow:hidden;width:100%;" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen="true"></iframe>


    <!-- The events by division -->
    <hr class="featurette-divider">
    <div class="container marketing">
      <div class="row">
        <div class="col-lg-4">
          <img id="events-img" src="sisa-images/sisa-event-7.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
          <center><h3>Grommet Division</h3></center>
          <p>With Toby Espejon, Mark Kent Hucay, Jayward Alciso at Kai Alcala.</p>
          <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img id="events-img" src="sisa-images/sisa-event-4.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
          <center><h3>Women's Open Division</h3></center>
          <p>With Nildie Espejon Blancada, Ana Mae Alipayo, Shelamae Arjona at Manette Alcala.</p>
          <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img id="events-img" src="sisa-images/sisa-event-5.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
          <center><h3>Men's Open Division</h3></center>
          <p>With Marvin Delamide, Philmar Alipayo, Gabriel Lerog at Eduardo Dizon Alciso.</p>
          <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img id="events-img" src="sisa-images/sisa-event-3.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
          <center><h3>Master's Division</h3></center>
          <p>With Aye Catulay, Eloy Nogalo, Glenn Turner at Edito Jr Alcala.</p>
          <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
        </div><!-- /.col-lg-4 -->
        <div class="col-lg-4">
          <img id="events-img" src="sisa-images/sisa-event-6.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
          <center><h3>AirBorne Division</h3></center>
          <p>With Edito Jr Alcala, PJ Alipayo, Philmar Alipayo, Jefferson Espejon at Loloy Espejon.</p>
          <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
        </div><!-- /.col-lg-4 -->

      </div><!-- /.row -->


      <!-- All surfing events -->
      <br><br>
      <hr class="featurette-divider">

      <div class="row featurette">
        <div class="col-md-7 order-md-15" style="overflow-x:auto;">
          
         <table class="table-responsive">
           <thead>
            <tr>
              <th>
                <center><h5>Cloud 9 Master</h5></center>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                  <p style="font-size: 12px; text-align: justify; text-justify: inter-word;">SISA Siargao Island Surfers Association is at Siargao Island, Philippines.
                    May 27, 2019  · Catangnan  ·<br> 
                    It’s ON! Siargao Island Surfers’ Association (SISA) in cooperation with Brgy. Catangnan is bringing back 2019 CLOUD 9 MASTERS!<br> 
                    Please see some IMPORTANT ANNOUNCEMENTS you need to know prior❗<br> 
                    📍 Registration is on June 1-2, 2019 ONLY! Since we are all busy during high tide, we’ll be having the registration from 8:00AM-12:00NN on these days at the First tower. 
                    📍 This competition is ONLY open to Siargao residents living in the island from 5 years and above.<br><br>
                    Registration fee is as below:<br>
                      Foreigners : 700php<br>
                      Non-Foreigners / Locals : 500php<br>
                      Grommet : 300php<br>
                      📍For competitors 17 years old and below, kindly present your previous report card and enrollment to be able to join the competition. Those not enrolled this year will not be allowed to join the competition. <br>
                      📍For grommet category, kindly have your parents / guardian sign the waiver during the registration. <br>
                      📍 For those joining the airborne category, you need to pay another registration fee as this is a special category and slots are limited only. <br>
                      📍This competition is part of your surfing skills training to be able to have / renew your SISA ID as surf instructors. We will do a separate training for the first aid and customer orientation to be announced soon. <br>
                      Please do not forget to like our Facebook and Instagram page to be able to get updates about the competition 😊 <br>
                      Please use the hashtag #2019cloud9masters for your posts / photos about this event 🙏🏽
                    See you! 🤙🏽</p>
                </td>
              </tr>
            </tbody>
          </table>

        </div>
        <div class="col-md-5">
         <img id="events-img" src="sisa-images/sisa-event-8.jpg" alt="Cloud 9 Master 2019" style="width:100%; max-width:100%; border-radius: 5%;">
       </div>
     </div>
   </div>
   <br><br>