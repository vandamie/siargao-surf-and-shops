<?php
//---------------------GET MYSQL QUERY-------------------------------//
// $sql for rankings men's shortboard
$m_short=addslashes("Men's Shortboard");
$men_short1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings  LIMIT 1");
$men_short2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$m_short'");

// $sql for rankings Women's shortboard
$wm_short=addslashes("Women's Shortboard");
$womens_short1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$womens_short2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$wm_short'");

// $sql for rankings Junior Shortboard
$mj_short=addslashes("Junior Shortboard");
$junior_short1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$junior_short2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$mj_short'");

// $sql for rankings Groomet Women Shortboard
$gwm_short=addslashes("Grommet Women Shortboard");
$grommet_women_short1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$grommet_women_short2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$gwm_short'");

// $sql for rankings Groomet Men Shortboard
$gm_short=addslashes("Grommet Men Shortboard");
$grommet_men_short1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$grommet_men_short2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$gm_short'");

// $sql for rankings Men's Longboard
$m_longboard=addslashes("Men's longboard");
$mens_long1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$mens_long2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$m_longboard'");

// $sql for rankings Women's Longboard
$wm_longboard=addslashes("Women's longboard");
$womens_long1 = mysqli_query($conn,"SELECT r_name FROM sisaph_rankings LIMIT 1");
$womens_long2 = mysqli_query($conn,"SELECT * FROM sisaph_rankings WHERE r_division = '$wm_longboard'");
 ?>