<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Siargao Surf Academy, Certified Surfing Instructor</title>
  <style>
   /* Table CSS */
   #table1 {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 465px;
    border:1px black solid;
    border-radius:5px; 
    background-color: white;
    -ms-overflow-style: none;  /* Internet Explorer 10+ */
    scrollbar-width: none;  /* Firefox */
  }

  /* Hide scrollbar for Chrome, Safari and Opera */
  #table1::-webkit-scrollbar {
    display: none;
  }
  @media (max-width: 600px) {
    #table1{
      width: 210px;
    }
  }
  /* Table CSS */
  #table2 {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 400px;
    border:1px black solid;
    border-radius:5px; 
    background-color: white;
    -ms-overflow-style: none;  /* Internet Explorer 10+ */
    scrollbar-width: none;  /* Firefox */
  }

  /* Hide scrollbar for Chrome, Safari and Opera */
  #table2::-webkit-scrollbar {
    display: none;
  }
  @media (max-width: 600px) {
    #table2{
      width: 323px;
    }
  }

  th, td {
    text-align: left;
    padding: 5px;
  }

  tr:nth-child(even){background-color: #f2f2f2}


  /**************** CSS instructors and student Chat form **************/

  .form-inline {  
    display: flex;
    flex-flow: row wrap;
    align-items: center;
  }

  .form-inline textarea {
    vertical-align: middle;
    margin: 5px 10px 5px 0;
    padding: 10px;
    background-color: #fff;
    border: 1px solid #ddd;
    width: 85%;
  }

  .form-inline button {
    padding: 10px 20px;
    background-color: dodgerblue;
    border: 1px solid #ddd;
    border-radius: 5px;
    color: white;
    cursor: pointer;
  }

  .form-inline button:hover {
    background-color: royalblue;
  }

  @media (max-width: 800px) {
    .form-inline textarea {
      margin: 10px 0;
      width: 100%;
    }

    .form-inline {
      flex-direction: column;
      align-items: stretch;
    }
  }

  * {
    box-sizing: border-box;
  }

  /* Create two equal columns that floats next to each other */
  .column1 {
    float: left;
    width: 25%;
    padding: 5px;
    height: 550px; /* Should be removed. Only for demonstration */
  }

  .column2 {
    float: left;
    width: 75%;
    padding: 5px;
    height: 550px; /* Should be removed. Only for demonstration */
  }
    @media screen and (max-width: 600px) {
    .column2 {
      font-size: 12px;
      padding-left:81px;
    }
  }

  /* Clear floats after the columns */
  .row1:after {
    content: "";
    display: table;
    clear: both;
  }


  /**************** CSS chatbox button of instructors and content **************/
  .insdropbtn {
    color: black;
    padding: 5px;
    font-size: 12px;
    cursor: pointer;
    border-radius: 3px;
    border:none;
    background-color:#d9d9d9;
  }

  .insdropbtn:hover, .insdropbtn:focus {
    background-color:#cccccc;
  }

  .ins-dropdown{
    position: relative;
    display: inline-block;
    width: 220px;
  }

  .ins-img-size {
    border: 2px solid green;
    border-radius: 100%;
    padding: 1px;
    width: 30px;
    height: 30px;
  }

  .ins-img-size:hover {
    box-shadow: 0 0 2px 1px #1E90FF;
  }

  .container1 {
    border: 2px solid #dedede;
    background-color: #f1f1f1;
    border-radius: 5px;
    padding: 1px;
    margin: 10px 0;
    width: 710px;
  }

  @media screen and (max-width: 600px) {
    div.container1 {
      font-size: 12px;
      width: 310px
    }
  }

  .darker1{
    border-color: #ccc;
    background-color: #ddd;
  }

  .container1::after {
    content: "";
    clear: both;
    display: table;
  }

  .container1 img {
    float: left;
    max-width: 40px;
    width: 100%;
    margin-right: 20px;
    border-radius: 50%;
  }

  .container1 img.right1 {
    float: right;
    margin-left: 20px;
    margin-right:0;
  }

  .time-right1 {
    float: right;
    color: #aaa;
  }

  .time-left1 {
    float: left;
    color: #999;
  }
  .inline-reports-ins {
    display: inline; /* the default for span */
    width: auto;
    height: auto;
  }
  .inline-label {
    display: inline; /* the default for span */
    width: auto;
    height: auto; 
  }

  /**************** CSS for harana-cer-sur-ins and the rest pages with images ******************/
  /* Content */
  .content {
    background-color: #f2f2f2;
    padding:10px;
    width: 100%; 
    border-radius: 10px;
    font-family: Arial;
    font-size: 12px;
  }

  @media screen and (max-width: 600px) {
    div.content {
      font-size: 12px;
      width:570px; 
    }
  }

  .ins-img-column{
    width: 160px;
    padding: 5px;
    background-color: #f2f2f2;
  }

  /* Clearfix (clear floats) */
  .ins-img-row::after {
    content: "";
    clear: both;
    display: table;
  }
</style>
</head>
<body>
 <div class="content">

  <center><p><i>"&nbsp;Reminder: Please show some respect to each other for the healthy community.&nbsp;"</i></p></center>

  <div class="row1">
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <div class="column1">
    <p>

      <div class="ins-img-row">

        <center><h6 class="inline-label">Available</h6></center>
        &nbsp;
        <span class="a"><font color="red" class="inline-label">Offline</font>: 0</span>,
        &nbsp;
        <span class="a"><font color="green" class="inline-label">Online</font>: 9</span>

        <table class="table-responsive" id="table1">
          <tbody>

            <tr>
              <td>
                <div class="ins-img-column">
                  <div class="ins-dropdown">

                    <div style="border-radius:5px;">
                      <button class="insdropbtn">
                        <img src="sisa-images/avatar.jpg" alt="Instructor" class="ins-img-size"> 
                        &nbsp;Edito Alcala Jr.&nbsp;
                      </button>&nbsp;
                      <a href="#">
                        <i style="font-size: 12px;color:black;" class="fas fa-comment"></i>
                      </a>
                      &nbsp; 
                      <span style="color:#1E90FF; font-size: 14px; font-weight: bold;">3</span>
                    </div>

                  </div>
                </div>
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </p>
  </div>



  <div class="column2">
    <p>
     <div style="width: 100%; text-align: right;"> 
       <center><h6>Chat Box</h6></center>
       <select name="reports_from_stud" class="inline-reports-ins">
        <option value="">Rate or Report</option>
        <option value="Report the instructor">Report the instructor</option>
        <option value="Rate the instructor">Rate the instructor</option>
      </select>
    </div>
    <table class="table-responsive"  id="table2">
      <tbody>


        <tr>
          <td>

            <div class="container1">
              <img src="sisa-images/avatar.jpg" alt="Avatar" style="width:100%;">
              <p>Hello. How are you today?</p>
              <span class="time-right1">11:00</span>
            </div>

            <div class="container1 darker1">
              <img src="sisa-images/avatar.jpg" alt="Avatar" class="right1" style="width:100%;">
              <p>Hey! I'm fine. Thanks for asking!</p>
              <span class="time-left1">11:01</span>
            </div>

            <div class="container1">
              <img src="sisa-images/avatar.jpg" alt="Avatar" style="width:100%;">
              <p>Sweet! So, what do you wanna do today?</p>
              <span class="time-right1">11:02</span>
            </div>

            <div class="container1 darker1">
              <img src="sisa-images/avatar.jpg" alt="Avatar" class="right1" style="width:100%;">
              <p>Nah, I dunno. How to surf.. or learn more drinking alcohol perhaps?</p>
              <span class="time-left1">11:05</span>
            </div>


          </td>
        </tr>

      </tbody>
    </table>

    <form method="post" class="form-inline">
      <textarea type="text" name="stud-chats" style="height:45px;border-radius:5px;">Type...</textarea>
      <button type="submit" name="chats"><i class="fa fa-send-o"></i> Send</button>
    </form>

  </p>
</div>


</div>
</div>

</body>
</html>



