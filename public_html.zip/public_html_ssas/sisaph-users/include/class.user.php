<?php 
include "db_config.php";
class User{
	protected $db;
	public function __construct(){
		$this->db = new DB_con();
		$this->db = $this->db->ret_obj();
	}

	/*** for registration process ***/

	public function reg_user($cus_name,$cus_password,$cus_email){
			//echo "k";
		date_default_timezone_set('Asia/Manila');
		$todays_date = date("y-m-d,h:i:sa");
		$cus_active = "Yes";
		$cus_status = "Offline";
		$cus_type = "User";
		$cus_password = md5($cus_password);
		$cus_name = filter_var($cus_name, FILTER_SANITIZE_STRING);
		$cus_password = filter_var($cus_password, FILTER_SANITIZE_STRING);
		$cus_email = filter_var($cus_email, FILTER_SANITIZE_STRING);
		
			//checking if the username or email is available in db
		$query = "SELECT * FROM customers WHERE cus_name='$cus_name' OR cus_email='$cus_email'";

		$result = $this->db->query($query) or die($this->db->error);

		$count_row = $result->num_rows;

			//if the username is not in db then insert to the table

		if($count_row == 0){
			$query = "INSERT INTO customers SET cus_name='$cus_name', cus_password='$cus_password', cus_email='$cus_email', time_in='$todays_date',time_out='null', cus_active='$cus_active', cus_status='$cus_status', cus_type='$cus_type'";

			$result = $this->db->query($query) or die($this->db->error);

			return true;
		}else{

			return false;}
			
			
		}


		/*** for login process ***/
		public function check_login($cname, $cpassword){
			$cpassword = md5($cpassword);
			$cname = filter_var($cname, FILTER_SANITIZE_STRING);
			$cpassword = filter_var($cpassword, FILTER_SANITIZE_STRING);
			$query = "SELECT customer_id FROM customers WHERE cus_name='$cname' AND cus_password='$cpassword' AND cus_approval ='Yes' AND cus_type ='User' "; 

			$result = $this->db->query($query) or die($this->db->error);


			$user_data = $result->fetch_array(MYSQLI_ASSOC);
			$count_row = $result->num_rows;

			if ($count_row == 1 ) {
	            $_SESSION['login'] = true; // this login var will use for the session thing
	            $_SESSION['customer_id'] = $user_data['customer_id'];
	            
	            //Set a cookies when checked the remember me checkbox
	            if(isset($_POST['remember-me'])){ 
	            	// 3600 * 24 = 1 Day
	            	// 3600 = 1 hour 
                   setcookie('cname', $cname,time() + (3600 * 24), "/"); // 24 hrs
               }
               return true;
           }else{

           	return false;
           }

       }


       /*** for Sending Email process ***/

       public function send_email($c_name, $c_email, $c_subject, $c_message){
			//echo "k";
       	date_default_timezone_set('Asia/Manila');
       	$todays_date = date("y-m-d,h:i:sa");

       	if(is_string($c_name) && is_string($c_email)){
       		$query = "INSERT INTO customer_message SET cu_name='$c_name', cu_email='$c_email', cu_subject='$c_subject',cu_message='$c_message', cu_date_time='$todays_date'";

       		$result = $this->db->query($query) or die($this->db->error);

       		return true;
       	}else{

       		return false;}


       	}	    


       	/*** for displaying username  ***/
       	public function get_user_name($cus_name){
       		$query = "SELECT cus_name FROM customers WHERE customer_id = $cus_name";

       		$result = $this->db->query($query) or die($this->db->error);

       		$user_data = $result->fetch_array(MYSQLI_ASSOC);
       		echo $user_data['cus_name'];

       	}

       	/*** for displaying user profile image ***/
	    //public function get_user_profile($user_profile){
	    //	$query = "SELECT user_profile FROM admin_personnel WHERE id = $user_profile";

	    //	$result = $this->db->query($query) or die($this->db->error);
//	$user_data = $result->fetch_array(MYSQLI_ASSOC);
	   // 	echo $user_data['user_profile'];

	   // }
       	/*** for displaying user status ***/
       	public function get_user_status($cus_stat){
       		$query = "SELECT customer_id FROM customers WHERE customer_id = $cus_stat";

       		$result = $this->db->query($query) or die($this->db->error);

       		$user_data = $result->fetch_array(MYSQLI_ASSOC);
       		echo $user_data['customer_id'];

       	}

       	/*** for displaying user status ***/
       	public function get_status($cus_status){
       		$query = "SELECT cus_status FROM customers WHERE customer_id = $cus_status";

       		$result = $this->db->query($query) or die($this->db->error);

       		$user_data = $result->fetch_array(MYSQLI_ASSOC);
       		echo $user_data['cus_status'];

       	}

       	/*** starting the session ***/
       	public function get_session(){
       		return $_SESSION['login'];
       	}

       	public function user_logout() {
       		$_SESSION['login'] = FALSE;
       		unset($_SESSION);
       		session_destroy();
       	}



       }


       ?>