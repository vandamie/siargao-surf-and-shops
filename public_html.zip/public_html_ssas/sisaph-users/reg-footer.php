    


<!-- Modal Info-->
<div class="modal fade" id="reg-info" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
       <center><img class="mb-2" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>      
       <center><h5 class="modal-title">How can we help you?</h5></center>
       <ul id="inf">
        <li><a href="#" id="inf">How to change my password?</a></li>
        <li><a href="#" id="inf">How to link my bank card?</a></li>
        <li><a href="#" id="inf">How to chat with my instructor?</a></li>
        <li><a href="#" id="inf">Can I pay them cash on hand?</a></li>
      </ul>
      <dl>
        <dt>Email Us:</dt>
        <dd>siargao.web.protocol@gmail.com</dd>
      </dl>
      <center><h5>Contact Us:</h5></center>
      <form class="form-login" method="POST" name="">
        <center><h6><?php echo $error3; ?></h6></center>
        <label for="inputEmail" class="sr-only">Complete Name</label>
        <center><i class="fas fa-user"></i></center>
        <input type="text" name="c_name" class="form-control" placeholder="Complete Name" required autofocus>
        <label for="inputEmail" class="sr-only">Email Address</label>
        <center><i class="fas fa-envelope"></i></center>
        <input type="email" name="c_email" class="form-control" placeholder="Email Address" required autofocus>
        <label for="inputEmail" class="sr-only">Subject</label>
        <center><i class="fas fa-book-open"></i></center>
        <input type="text" name="c_subject" class="form-control" placeholder="Write Subject" required autofocus>
        <label for="message" class="sr-only">Message</label>
        <center><i class="fas fa-edit"></i></center>
        <textarea type="message" name="c_message" class="form-control" placeholder="Write Message" required autofocus></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="submit-con" value="Submit">
      </div>
    </form>
  </div>
</div>
</div>

<!-- Modal Account Profile-->
<div class="modal fade" id="acc-pro" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Account Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
       <center><img style="border-radius: 7px; border-radius: 50%;" src="./sisa-images/ssas-logo.png" alt="" width="70" height="70"></center>      
       <center><h5 class="modal-title" style="text-align:center; display: inline;">James Van</h5>&nbsp;&nbsp;
        <i id="edit-profile" data-toggle="modal" data-target="#acc-pro-update" class="fas fa-pencil-square-o"></i></center>

      <form class="form-login" method="POST">
        <center><h6><?php echo $error3; ?></h6></center>
        <center style="display: inline;"><i class="fas fa-calendar"></i>&nbsp;
        <span><b>Birth Date:</b> <u>Oct. 20,  1992</u></span></center>
        <br>
        <center style="display: inline;"><i class="fas fa-flag"></i>&nbsp;
        <span><b>Nationality:</b> <u>Israeli</u></span></center>
        <br>
        <center style="display: inline;"><i class="fas fa-envelope"></i></i>&nbsp;
        <span><b>Email:</b> <u>james.van@gmail.com</u></span>&nbsp;&nbsp;<span class="not-verified">Not Verified</span></center>
        <br>
        <center style="display: inline;"><i class="fas fa-map-marker"></i>&nbsp;
        <span><b>Current Address:</b> <u>Barangay 2, General Luna, Surigao del Norte</u></span></center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </form>
  </div>
</div>
</div>


<!-- Modal Account Profile-->
<div class="modal fade" id="acc-pro-update" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Update Account Profile</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
      <form class="form-login" method="POST">
        <center><h6><?php echo $error3; ?></h6></center>
        <span style="display:block; padding: 5px 5px 5px 5px;">
        <center><i class="fas fa-image"></i>&nbsp;
        <input type="file" name="acc-name" value="" class="acc-pro-up" required autofocus></center>
        &nbsp;
        <center><i class="fas fa-user"></i>&nbsp;
        <input type="text" name="acc-bir-dat" value="" class="acc-pro-up" required autofocus></center>
         &nbsp;
        <center><i class="fas fa-calendar"></i>&nbsp;
        <input type="text" name="acc-nat" value="" class="acc-pro-up" required autofocus></center>
         &nbsp;
        <center><i class="fas fa-flag"></i>&nbsp;
        <input type="text" name="acc-add" value="" class="acc-pro-up" required autofocus></center>
        &nbsp;
        <center><i class="fas fa-envelope"></i>&nbsp;
        <input type="text" name="acc-add" value="" class="acc-pro-up" required autofocus></center>
        &nbsp;
        <center><i class="fas fa-map-marker"></i>&nbsp;
        <input type="text" name="acc-add" value="" class="acc-pro-up" required autofocus></center>
      </span>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="save-info" value="Save Changes">
      </div>
    </form>
  </div>
</div>
</div> 

<!-- Modal of Messages-->
<?php
include('reg-inbox.php');
?> 

<!-- FOOTER -->
<footer class="pt-4 my-md-5 pt-md-5 border-top">
  <div class="row">
    <div class="col-12 col-md">
      <img class="mb-2" style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="" width="25" height="25">
      <small class="d-block mb-3 text-muted">&copy; 2020-2021</small>
      <small class="d-block mb-3">Social Media Links</small>
      <ul class="list-unstyled text-small">
        <a href="https://web.facebook.com/SIARGAOISA"><i id="fb" class="fa fa-facebook"></i></a>
        <a href="https://youtu.be/IVlVlFC79cI"><i id="yt" class="fa fa-youtube"></i></a>
        <a href="https://www.instagram.com/sisa.siargao/"><i id="ig" class="fa fa-instagram"></i></a>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Features</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="reg_sisaph_events_og.php">SISA Events</a></li>
        <li><a class="text-muted" href="reg_sisaph_rankings.php">SISA Rankings</a></li>
        <li><a class="text-muted" href="http://sisaph.000webhostapp.com/sisaph-judging/">SISA Live Score</a></li>
        <li><a class="text-muted" href="reg-iao-surf-schools.php">SI Accridited Surf Schools</a></li>
        <li><a class="text-muted" href="reg-iao-surf-spots.php">Surf Spots</a></li>
        <li><a class="text-muted" href="reg-sisa-p-merchants.php">Partner Merchants</a></li>
        <li><a class="text-muted" href="reg-ssas-community.php">SSAS Community</a></li>
        <li><a class="text-muted" href="#">Supported Foundation - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
        <li><a class="text-muted" href="#">Job Offers - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Sponsor</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="http://siargao-web-protocol.000webhostapp.com/">Siargao Web Protocol</a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>Siargao Surf and Shops</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="reg-sisaph-about.php">About</a></li>
        <li><a class="text-muted" href="reg-sisaph-history.php">History</a></li>
        <li><a class="text-muted" href="reg-sisaph-privacy-policy.php">Privacy Policy</a></li>
        <li><a class="text-muted" href="reg-sisaph-conditions.php">Terms and Conditions</a></li>
        <li><a class="text-muted" href="#">Terms of Service</a></li>
        <li><a class="text-muted" href="#">Return and Refund</a></li>
        <li><a class="text-muted" href="#">Cookies Policy</a></li>
        <li><a class="text-muted" href="#">Disclaimer</a></li>
      </ul>
    </div>
  </div>
</footer>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
<!-- font-awesome icons link source -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function user_drop() {
  document.getElementById("my_user_drop").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

//Avoid resubmitting the form confirmation

if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>

