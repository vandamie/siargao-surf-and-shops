
<style type="text/css">
  .a-link{
  color: white;
}
/* mouse over link */
.a-link:hover {
  color: #1E90FF;
}
</style>
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background-color:#4267B2;">
    <ul class="navbar-nav mr-auto">
     <a class="nav-link" id="brand"><img style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="logo" width="35" height="35"> Siargao Surf and Shops</a></ul>
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-link">
            <a href="index.php" class="a-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-link">
            <a href="reg-sisa-p-merchants.php" class="a-link"><i class="fas fa-store"></i> Partner Merchants</a>
          </li>
        <li class="nav-link">
          <a href="?" class="a-link" data-toggle="modal" data-target="#reg-info"><i class="fas fa-info"></i> Help</a>
        </li>
        <li class="nav-link">
          <a href="reg-ssas-cart.php" class="a-link"><i class="fas fa-shopping-cart"></i></a>
        </li>
      </ul>
      <div class="dropdown">
        <font color="white"><?php $user->get_status($cus_status); ?></font>
        <button onclick="user_drop()" class="dropbtn">
          <i class="fa fa-user-circle-o"></i> <?php $user->get_user_name($cus_name); ?> <i class="fa fa-angle-down"></i></button>
          <div id="my_user_drop" class="dropdown-content">
            <a href="#" data-toggle="modal" data-target="#acc-pro"><i class="fa fa-user-circle-o"></i> Account Profile</a>
            <a href="#" id="user-Btn"><i class="fas fa-envelope"></i> Inbox</a>
            <a href="#" data-toggle="modal" data-target="#lin-acc"><i class="fas fa-users"></i> Linked Accounts</a>
            <a href="#" data-toggle="modal" data-target="#sett"><i class="fas fa-gear"></i> Settings</a>
            <a href="index.php?q=Sign Out"><i class="fa fa-power-off"></i> Sign Out</a>
          </div>
        </div>
        <form method="GET" class="form-inline mt-2 mt-md-0">
          <input type="text" id="search_box" name="search_data" placeholder="Search" aria-label="Search">
          <button type="submit" id="search_icon" name="search_btn" class="btn btn-primary my-2 my-sm-0"><i class="fas fa-search"></i></button>
        </form>
      </div>
    </nav>
  </header><br>
