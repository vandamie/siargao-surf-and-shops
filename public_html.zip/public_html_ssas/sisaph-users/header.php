<style type="text/css">
  .a-link{
  color: white;
}
/* mouse over link */
.a-link:hover {
  color: #1E90FF;
}
</style>
<header>
  <nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background-color:#4267B2;">
    <ul class="navbar-nav mr-auto">
      <a class="nav-link" id="brand"><img style="border-radius: 7px;" src="./sisa-images/ssas-logo.png" alt="logo" width="35" height="35"> Siargao Surf and Shops</a></ul>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-link">
            <a href="../index.php" class="a-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-link">
            <a href="./sisa-p-merchants.php" class="a-link"><i class="fas fa-store"></i> Partner Merchants</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#register"><i class="fas fa-user"></i> Register</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#signin"><i class="fas fa-key"></i> Sign In</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#info"><i class="fas fa-info"></i> Help</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" class="nav-link" data-toggle="tooltip" data-html="true" data-placement="bottom" title="You have to register first, thank you."><i class="fas fa-shopping-cart"></i></a>
          </li>
        </ul>
        <form method="GET" class="form-inline mt-2 mt-md-0">
          <input type="text" id="search_box" name="search_data" placeholder="Search" aria-label="Search">
          <button type="submit" id="search_icon" name="search_btn" class="btn btn-primary my-2 my-sm-0"><i class="fas fa-search"></i></button>
        </form>
      </div>
    </nav>
  </header>


