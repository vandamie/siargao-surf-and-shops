<?php
//----------------------Rankings Loop for Men's Shortboard-------------------------//
while($row = mysqli_fetch_array($sql_data1)){

    echo'
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"].'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop


while($row = mysqli_fetch_array($sql_data2)){

     echo'
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop

 ?>