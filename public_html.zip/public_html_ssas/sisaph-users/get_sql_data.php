<?php
//---------------------GET MYSQL QUERY-------------------------------//
//---------------------months and year-------------------------------//
// $sql2 for month January
$sql_jan1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'January' AND  ev_year = '".$_GET["text"]."'ORDER BY ev_year ASC LIMIT 1");
// $sql for month February
$sql_feb1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'February' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month March
$sql_mar1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'March' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month April
$sql_apr1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'April' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month May
$sql_may1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE  ev_month = 'May' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month June
$sql_jun1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'June' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month July
$sql_jul1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'July' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month August
$sql_aug1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'August' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month September
$sql_sep1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'September' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month October
$sql_oct1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'October' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month November
$sql_nov1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'November' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");
// $sql for month December
$sql_dec1 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'December' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC LIMIT 1");


//---------------------GET MYSQL QUERY-------------------------------//
//---------------------months-------------------------------//
// $sql2 for month January
$sql_jan2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'January' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month February
$sql_feb2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'February' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month March
$sql_mar2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'March' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month April
$sql_apr2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'April' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month May
$sql_may2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE  ev_month = 'May' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month June
$sql_jun2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'June' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month July
$sql_jul2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'July' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month August
$sql_aug2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'August' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month September
$sql_sep2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'September' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month October
$sql_oct2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'October' AND ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month November
$sql_nov2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'November' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");
// $sql for month December
$sql_dec2 = mysqli_query($con,"SELECT * FROM sisa_events WHERE ev_month = 'December' AND  ev_year = '".$_GET["text"]."' ORDER BY ev_year ASC");

 ?>