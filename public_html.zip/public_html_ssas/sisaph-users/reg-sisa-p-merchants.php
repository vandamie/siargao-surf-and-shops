<?php 
session_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();
ob_start();
$cus_name = $_SESSION['customer_id'];
$cus_stat = $_SESSION['customer_id'];
$cus_status = $_SESSION['customer_id'];
//$user_profile = $_SESSION['id'];

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:../index.php");
}else{
  $sql = "UPDATE customers SET cus_status = 'Online' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php  
session_destroy();
session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] >900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
    ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully for security reason.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}else {
  $_SESSION['cus_name'] = time();
}


//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // Registration Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops Official Website, Partner Merchants">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisa-images/ssas-logo.png">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
  <title>SSAS Partner Merchants</title>
  <style type="text/css">
    /**************** CSS for SSAS Users Account Profile ******************/

#edit-profile{
  font-size: 16px;
  color: black;
}

#edit-profile:hover{
  font-size: 16px;
  color: #1E90FF;
}
.acc-pro-up{
  width: 90%;
  height: 30px;
  font-size: 12px;
  padding: 5px;
}
/**************** CSS not verified on account profile ******************/
.not-verified{
  color: orange; 
  font-size: 10px; 
  font-weight: bold;
}
  </style>
</head>
<body><br>
  <?php include("reg-header.php"); ?><br>

  <div class="container">
    <main role="main">
      <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <h2>Categories</h2>
        <p class="lead">It is your choice.</p>
      </div>

      <div class="container" id="color">
        <div class="card-deck mb-3 text-center">
          <div class="card mb-4 shadow-sm">
            <div class="card-body">
              <h1 class="card-title pricing-card-title">%5 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-pharmacies.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Pharmacies</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-groceries.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Groceries</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-bar-resto.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Bar and Restaurant</button>
            </div>
          </div>
          <div class="card mb-4 shadow-sm">

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%10 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-resorts.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Resorts</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-vehicles.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Vehicles for Rent</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%5 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-bakeries.jfif" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Bakeries</button>
            </div>
          </div>
          <div class="card mb-4 shadow-sm">

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-t-pack.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Tour Packages</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-s-souviner.jfif" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Surf Shops and Souviners</button>
            </div>

            <div class="card-body">
              <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
              <img src="./sisa-images/sisa-coffee-s.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
              background-position: center;
              background-repeat: no-repeat;
              background-size: cover;">
              <button type="button" class="btn btn-lg btn-block btn-outline-primary">Coffee Shops</button>
            </div>
          </div>
        </div>
        
        <?php include("reg-footer.php"); ?>
      </main>
    </div>  
  </body>
  </html>