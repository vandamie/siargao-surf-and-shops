<?php
//----------------------Rankings Loop for Men's Shortboard-------------------------//
$sql_rank_head = '';
while($row = mysqli_fetch_array($men_short1)){

    $sql_rank_head .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Men's Shortboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod = '';
while($row = mysqli_fetch_array($men_short2)){

    $sql_rank_bod .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop

//----------------------Rankings Loop for Women's Shortboard-------------------------//
$sql_rank_head_womens_short= '';
while($row = mysqli_fetch_array($womens_short1)){

    $sql_rank_head_womens_short .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Women's Shortboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_womens_short = '';
while($row = mysqli_fetch_array($womens_short2)){

    $sql_rank_bod_womens_short .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop

//----------------------Rankings Loop for Junior Shortboard-------------------------//
$sql_rank_head_junior_short= '';
while($row = mysqli_fetch_array($junior_short1)){

    $sql_rank_head_junior_short .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Junior Shortboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_junior_short = '';
while($row = mysqli_fetch_array($junior_short2)){

    $sql_rank_bod_junior_short .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop

//----------------------Rankings Loop for Grommet Women Shortboard-------------------------//
$sql_rank_head_grommet_women_short= '';
while($row = mysqli_fetch_array($grommet_women_short1)){

    $sql_rank_head_grommet_women_short .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Grommet Women Shortboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_grommet_women_short = '';
while($row = mysqli_fetch_array($grommet_women_short2)){

    $sql_rank_bod_grommet_women_short .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop


//----------------------Rankings Loop for Grommet Men Shortboard-------------------------//
$sql_rank_head_grommet_men_short= '';
while($row = mysqli_fetch_array($grommet_men_short1)){

    $sql_rank_head_grommet_men_short .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Grommet Men Shortboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_grommet_men_short = '';
while($row = mysqli_fetch_array($grommet_men_short2)){

    $sql_rank_bod_grommet_men_short .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop


//----------------------Rankings Loop for Men's longboard-------------------------//
$sql_rank_head_mens_long= '';
while($row = mysqli_fetch_array($mens_long1)){

    $sql_rank_head_mens_long .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Men's longboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_mens_long = '';
while($row = mysqli_fetch_array($mens_long2)){

    $sql_rank_bod_mens_long .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop


//----------------------Rankings Loop for Women's longboard-------------------------//
$sql_rank_head_womens_long= '';
while($row = mysqli_fetch_array($womens_long1)){

    $sql_rank_head_womens_long .= '
    <thead>
    <tr>
    <th colspan="5">'.$row["r_division"]="Women's longboard".'</th>
    </tr>
    <tr>
    <th>Rank</th>
    <th>Name</th>
    <th>Points</th>
    <th>Earnings</th>
    <th>Event Name</th>
    </tr>
    </thead>
    ';

} // close while loop

$sql_rank_bod_womens_long = '';
while($row = mysqli_fetch_array($womens_long2)){

    $sql_rank_bod_womens_long .= '
    <tbody>
    <tr>
    <td>'.$row["r_number"].'</td>
    <td>'.$row["r_name"].'</td>
    <td>'.$row["r_points"].'</td>
    <td>'.$row["r_earnings"].'</td>
    <td>'.$row["r_name_leag"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
 ?>