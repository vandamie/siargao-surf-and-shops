<?php
//---------------------GET MYSQL QUERY-------------------------------//
//---------------------Division-------------------------------//
// $sql2 for month January
$sql_data1 = mysqli_query($con,"SELECT * FROM sisaph_rankings WHERE r_division = '".$_GET["text"]."' LIMIT 1");


//---------------------GET MYSQL QUERY-------------------------------//
//---------------------Data-------------------------------//
// $sql2 for month January
$sql_data2 = mysqli_query($con,"SELECT * FROM sisaph_rankings WHERE  r_division = '".$_GET["text"]."' ");


 ?>