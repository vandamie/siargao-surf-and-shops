<?php 
session_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();
ob_start();
$cus_name = $_SESSION['customer_id'];
$cus_stat = $_SESSION['customer_id'];
$cus_status = $_SESSION['customer_id'];
//$user_profile = $_SESSION['id'];

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:../index.php");
}else{
  $sql = "UPDATE customers SET cus_status = 'Online' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../sisaph-conditions.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php  
session_destroy();
session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] >900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
    ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully for security reason.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}else {
  $_SESSION['cus_name'] = time();
}


//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops, Conditions">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="sisa-images/ssas-logo.png">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
  <title>SSAS Conditions</title>
  <style>
   /* Table CSS */
   table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 450px;
  }

  th, td {
    text-align: left;
    padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>
  <br><br><br><br><br>
  <!-- Header -->
  <?php include("reg-header.php"); ?>

  <div class="container">
    <main role="main">

      <div class="bg-about" style="background-image: url('sisa-images/bg-conditions.jpg');">Siargao Surf and Shops. (or SSAS), Conditions.</div><br>

      <div class="row featurette">
        <div class="col-md-12 order-md-15" style="overflow-x:auto;">

           <table class="table-responsive" id="events-img">
             <thead>
              <tr>
                <th>
                  <p><center><h5>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Conditions</h5></center></p><hr><br>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td> 
                  <P><h2 class="text-muted">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ongoing Development</h3></p>
                  </td>
                </tr>
              </tbody>
            </table>

        </div>
      </div>


      <!-- FOOTER -->
      <?php include("reg-footer.php"); ?>


    </main>
  </div>
</body>
</html>
