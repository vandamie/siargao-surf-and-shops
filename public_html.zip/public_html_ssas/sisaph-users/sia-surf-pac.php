<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Siargao Surf Academy, Surf Packages</title>
</head>
<body>

 <div class="content">
  <h5>Surf Packages</h5>
  <p>
    <strong>Board Rentals</strong><br>
    Duration Varies · Php 300- Php 500 per day<br>
    We offer high quality performance longboards (sizes: 8'0 - 9'0 ) for rentals by FreePig Movement Bali. | Half day- Php 300 | 1-3 days- Php 500 per day | 4-7 days- Php 400 per day | 8- 15 days- Php 350 per day | 16-30 days- Php 300 per day | Note: Please bring valid ID. We'll give less price per day than you expected.<br><br>

    <strong>1 Day Surf Package</strong><br>
    4 hours 30 minutes and up · Php 2,500<br>
    With ISA certified or SISA Level 2 certified instructor, rashguard and equipment (longboard and leash), surf theory (basic and etiquette). Good for all levels. Student can surf TWICE a day- 2 hours per session (maximum 4.5 hrs per day in the water), transportation (pick up and drop off only- by motorbike). Boat fee is INCLUDED. Choice of surf spot.<br><br>

    <strong>Surf Guide 101</strong><br>
    2 hours and up · Php 1,500/session<br>
    with ISA certified or SISA Level 2 certified instructor, 2 hours per session, rashguard and equipment (longboard and leash), transportation by motorbike (pick up and drop off only). Boat fee is NOT INCLUDED. Choice of surf spot. For intermediate to advanced students only.<br><br>

    <strong>Group Surf Lessons (minimum of 6 pax)</strong><br>
    2 hours · Php 900/student<br>
    Headed by ISA certified and professional surfer Piso Alcala. Students will have each SISA certified instructor. Rashguards and longboards are provided. Boat is not included in the price (ranging from Php150- Php 250).<br><br>

    <strong>Private Surf Lessons</strong><br>
    2 hours · Php 1,000<br>
    Php 500/hr- with SISA Level 1 certified instructor, rashguard and equipment (longboard and leash). Transportation is included- pick up and drop off only (by motorbike). Boat fee is NOT INCLUDED (ranging from Php150- Php250). Minimum 2hrs per session to avail.<br>
  </p>
</div>

</body>
</html>

