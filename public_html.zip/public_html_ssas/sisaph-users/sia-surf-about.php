<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association Official Website, SI Accridited Surf Schools">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <link href="sisa-css/surf-schools.css" rel="stylesheet">
  <title>SISA PH Siargao Surf Academy, About</title>
</head>
<body>

   <div class="content">
    <h5>About</h5>
     <p>We offer private surf lessons for all levels, group surf lessons, surf guiding, board rentals and kids surf lessons in the beautiful island of Siargao. Headed by ISA certified, professional surfer & Philippine Surf Athlete, Piso Alcala.</p>
   </div>

</body>
</html>

