    

<!-------------Partner Merchants-------------->
<div class="container">
<main role="main">
<div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
  <h2>Categories</h2>
  <p class="lead">It is your choice.</p>
</div>
<div class="container" id="color">
  <div class="card-deck mb-3 text-center">
    <div class="card mb-4 shadow-sm">
      <div class="card-body">
        <h1 class="card-title pricing-card-title">%5 <small class="text-muted">Off</small></h1>
       <img src="./sisa-images/sisa-pharmacies.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Pharmacies</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
        <img src="./sisa-images/sisa-groceries.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Groceries</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-bar-resto.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Bar and Restaurant</button>
      </div>
    </div>
    <div class="card mb-4 shadow-sm">

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%10 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-resorts.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Resorts</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-vehicles.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Vehicles for Rent</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%5 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-bakeries.jfif" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Bakeries</button>
      </div>
    </div>
    <div class="card mb-4 shadow-sm">

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-t-pack.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Tour Packages</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%2 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-s-souviner.jfif" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Surf Shops and Souviners</button>
      </div>

      <div class="card-body">
        <h1 class="card-title pricing-card-title">%3 <small class="text-muted">Off</small></h1>
<img src="./sisa-images/sisa-coffee-s.jpg" alt="Lights" style="width:100%; max-width:100%; background-attachment: fixed;
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;">
        <button type="button" class="btn btn-lg btn-block btn-outline-primary">Coffee Shops</button>
      </div>
    </div>
  </div>


