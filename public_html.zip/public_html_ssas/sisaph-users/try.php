<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
<title>Customize Modal With CSS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<link href="sisa-css/inbox.css" rel="stylesheet">
</head>
<body>
<!-- Trigger/Open The Modal -->
<button id="user-Btn">Open Modal</button>

<!-- Modal for User Messages -->
<div id="user-Inbox" class="modal-messages">

  <!-- Modal content -->
  <div class="modal-content-messages">

     <div class="modal-header">
    <center><h4>Inbox</h4></center>
    <span class="close-messages">&times;</span>
      </div>
  
  <!---- Senders Table  ---->
    <table class="table-contact">
    <tbody>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
      <tr>
        <td></td>
      </tr>
      <tr>
        <td class="name-sender">
          <span><b>James Van</b></span>
          <i class="fas fa-envelope"></i> 
          <span class="num">3</span>
        </td>
      </tr>
    </tbody>
    </table>

<!---- Chat Responses Table  ---->
    <table class="table-message">
    <tbody>
      <tr>
        <td>
     <form method="POST" enctype="multipart/form-data">
      <table class="table-output-message">
        <tbody>
           <tr>
           <td>
            <center>
              <img src="./sisa-images/ssas-logo.png" alt="pro-pic" style="width: 35px; height: 35px; border-radius:50%;">
              <br>
              <b style="font-weight: bold; font-size: 12px;"><u>James Van</u></b>
            </center>
          </td>
           </tr>
           <tr>
           <td>
            <span style="font-size: 12px;">Oct. 10, 2021</span><br>
            <p class="rep-mes-them"><span>10:33 pm</span><br>
            In today’s digital world, marketing methods are constantly changing. With the rise of technology use and our increasing dependence on mobile phones, SMS marketing is the way to go. SMS marketing is effective in increasing engagement for many reasons.</p>
            &nbsp;
            <p class="rep-mes-you"><span style="float: right;">10:43 pm</span><br>
            In today’s digital world, marketing methods are constantly changing. With the rise of technology use and our increasing dependence on mobile phones, SMS marketing is the way to go. SMS marketing is effective in increasing engagement for many reasons.</p>
            &nbsp;
            <p class="rep-mes-you"><span style="float: right;">10:43 pm</span><br>
            In today’s digital world, marketing methods are constantly changing. With the rise of technology use and our increasing dependence on mobile phones, SMS marketing is the way to go. SMS marketing is effective in increasing engagement for many reasons.</p>
            &nbsp;
            <p class="rep-mes-you"><span style="float: right;">10:43 pm</span><br>
            In today’s digital world, marketing methods are constantly changing. With the rise of technology use and our increasing dependence on mobile phones, SMS marketing is the way to go. SMS marketing is effective in increasing engagement for many reasons.</p>
            &nbsp;
            <p class="rep-mes-them"><span>10:33 pm</span><br>  
            In today’s digital world, marketing methods are constantly changing. With the rise of technology use and our increasing dependence on mobile phones, SMS marketing is the way to go. SMS marketing is effective in increasing engagement for many reasons.</p>
            &nbsp;
           </td>
           </tr>
         </tbody>
      </table>

        </td>
      </tr>

    <!---- Chat Response Textarea,Attachment and Buttons ---->
      <tr class="inline-boxes-btn">
        <td>
          <textarea type="text" name="rep-mes" class="chat-res-you"></textarea>
        </td>
        <td>
        <label for="fileInput" class="btn btn-secondary">
        <i id="send-hover" class="fa fa-paperclip"></i> 
        </label>
        <input type="file" name="att-fil" style="display:none;" id="fileInput" />
        </td>
        <td>
         <label for="submit" class="btn btn-secondary">
        <i id="send-hover" class="fa fa-send"></i>
        </label>
        <input type="submit" name="send-reps" style="display:none;" id="submit" />
      </tr>
    </tbody>
    </table>

  </form>
  </div>

</div>

<script type="text/javascript">
  // Get the modal
var modal = document.getElementById("user-Inbox");

// Get the button that opens the modal
var btn = document.getElementById("user-Btn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close-messages")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
/* window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
} */
</script>
            
</body>
</html>

