<?php 
session_start();
require_once ("./include/class.user.php"); // class of functions of User.
require_once ("./include/db-con.php"); // database.
$user = new User();
ob_start();
$cus_name = $_SESSION['customer_id'];
$cus_stat = $_SESSION['customer_id'];
$cus_status = $_SESSION['customer_id'];
//$user_profile = $_SESSION['id'];

if (!$user->get_session()){  // session_start(); getting the user_name and user_password from the moment login.
 header("location:../index.php");
}else{
  $sql = "UPDATE customers SET cus_status = 'Online' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
}

if (isset($_GET['q'])){   // logout session_destroy(); it will link directly to login page.
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
  ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php  
session_destroy();
session_unset();
}

    //time for active user and it will automatically logout by setting time frame.
    //credit for this page.https://stackoverflow.com/questions/20516969/automatic-logout-after-15-minutes-of-inactive-in-php

$t=time();
if (isset($_SESSION['user_name']) && ($t - $_SESSION['user_name'] >900)) { 
  session_destroy();
  session_unset();
  $sql = "UPDATE customers SET cus_status = 'Offline' WHERE customer_id = '$cus_status'";
  mysqli_query($conn,$sql);
    ?>
  <!doctype html>
  <html lang="en">
  <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed out successfully for security reason.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='../index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
}else {
  $_SESSION['cus_name'] = time();
}


//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_POST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_POST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // sending Success
 $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Email delivery was succeed, thank you for contacting us.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';

 $to       = 'siargao.web.protocol@gmail.com';
 $name  = $_POST['c_name'];
 $subject  = $_POST['c_subject'];

 $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_POST['c_message'];
 $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
 $headers = "MIME-Version: 1.0" . "\r\n";
 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
 $headers  = 'From:'. $_POST['c_email'] . "\r\n" .
 'MIME-Version: 1.0' . "\r\n" .
 'Content-type: text/html; charset=utf-8';
 $headers .= 'Cc: '. $_POST['c_email'] . "\r\n";

 mail($to, $subject, $message, $headers);

} else {
            // sending Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Island Surfer's Association, SI Surf Spots">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisaph-users/sisa-images/ssas-logo.png">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="sisa-css/style.css" rel="stylesheet">
  <title>SSAS SI Surf Spots</title>
    <style>
   /* Table CSS */
   table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    /*border: 1px solid #ddd;*/
    height: 1080px;
  }

  th, td {
    text-align: left;
    padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}
</style>

<style>
  * {box-sizing: border-box}
  .surf-spots-etiquette {display: none}
  img {vertical-align: middle;}

  /* Slideshow container */
  .slideshow-container {
    max-width: 520px;
    position: relative;
    margin: auto;
  }

  /* Next & previous buttons */
  .prev, .next {
    cursor: pointer;
    position: absolute;
    top: 50%;
    width: auto;
    padding: 16px;
    margin-top: -22px;
    color: #1E90FF;
    font-weight: bold;
    font-size: 28px;
    transition: 0.3s ease;
    border-radius: 0 3px 3px 0;
    user-select: none;
  }

  /* Position the "next button" to the right */
  .next {
    right: 0;
    border-radius: 3px 0 0 3px;
  }

  /* On hover, add a grey background color */
  .prev:hover, .next:hover {
    background-color: #f1f1f1;
    color: black;
  }
</style>
</head>
<body>
  <br><br><br><br><br>
  <!-- Header -->
  <?php include("reg-header.php"); ?>

  <div class="container">
    <main role="main">

      <div id="googleMap" style="width:100%;height:400px;"></div>
      <hr>

      <div class="row featurette">

       <div class="col-md-6">

         <div class="slideshow-container">
          <div class="surf-spots-etiquette">
            <img id="events-img" src="././sisa-images/siargao-surf-spot.jpg" alt="Surf Spots" style="width:100%">
          </div>
          <div class="surf-spots-etiquette">
            <img id="events-img" src="././sisa-images/surf-etiquette.jpg" alt="Surf Etiquette" style="width:100%">
          </div>
          <a class="prev" onclick="plusSlides(-1, 0)"><span style="color:#1E90FF;">&#10094;</span></a>
          <a class="next" onclick="plusSlides(1, 0)"><span style="color:#1E90FF;">&#10095;</span></a>
        </div>

      </div> 

      <div class="col-md-6 order-md-15" style="overflow-x:auto;">

       <table class="table-responsive" id="events-img">
         <thead>
          <tr>
            <th>
              <center><h5>SIARGAO SURF SPOTS</h5></center>
            </th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <p>
                <strong>CLOUD 9</strong><br>

                800 meters from Harana. A world class wave. It’s been called a perfect barrelling right hander. Can boast that it made Siargao famous. The wave breaks over a spongy reef. Best to be surf during mid to high tide. Works best in the months of August to November, though it still works from April to August.  Best with eastern swell and western shift winds. Although it is a relatively short wave, it barrels nearly the whole way and guarantees high satisfaction. Gets crowded a lot due to its accessibility and its consistency. Take turns and respect locals. Expert surfers only.<br><br>

                <strong>QUICKSILVER</strong><br>

                Sometimes called Cloud 9s little brother due to the fact that it’s next to it and is also quite similar. It is mainly a right-handed wave with a short left working on occasions. When it get’s big it can be very heavy. Best to be surf during mid to high tide and even better when it’s peak high tide as it breaks on shallow reef. There main section barrels sometimes when its not closing out. The peak is normally experts only. The shoulder section can be a good learning spot for beginner to intermediates.<br><br>

                <strong>JACKING HORSE</strong><br>

                The peak of Jacking horse is a quick right hander that explodes on to a shallow reef can be surfed all tides. The inner section is the main beginner’s learning wave named Little Pony. The beginner’s area is always crowded for beginner surf lessons.  Jacking horse has a constant current that seems like you’re paddling on a water treadmill. However, when you are able to fight the current and get to the peak you can sometimes be rewarded by a very long right.<br><br>

                <strong>CEMETERY PESANGAN LEFT</strong><br>

                Pesangan is also commonly referred to as Cemetery. The reason being that the jump off point is in fact located at the cemetery of the General Luna town. It is possible to walk/paddle there (20 min), however it’s a long paddle, probably 400 meters. The easier way is by boat (3 min). The boats will park until you would still have to walk another 50 meters to get past the outer reef. The Left of Pesangan is still actually A Frame with a longer left section. Sometimes it can barrel in the inside when the wind is offshore. It holds size very well. Best mid to low tide. Perfect intermediate wave when not too big because the drop is not so steep and its.<br><br>

                <strong>CEMETERY PESANGAN RIGHT</strong><br>

                Pesangan is also commonly referred to as Cemetery. The reason being that the jump off point is in fact located at the cemetery of the General Luna town. It is possible to walk/paddle there (20 min), however it’s a long paddle, probably 400 meters. The easier way is by boat (3 min). The boats will park until you would still have to walk another 50 meters to get past the outer reef. The Right of pesangan is still an A Frame with a longer Right section. The left wave of Pesangan Right can sometimes get you stuck in a rip current. It holds size very well. Best mid to low tide. Perfect intermediate wave when not too big because the drop is not so steep and its.<br><br>

                <strong>DAKO SURF BREAK</strong><br>

                Accessible by boat from General Luna of the resort (10 min ride). It’s a fun and gentle breaking Right hander perfect for intermediates. There is a also a short left. The wave breaks over a deep coral reef and can become big during the winter season. It can only be surfed it Mid to high tide and needs strong North Eastern Swell.<br><br>

                <strong>SALVACION</strong><br>

                Nice Right hander point break in the town of Pilar. It gets its name from the baranggay which you take a boat from to get to the break. The town of salvation is about 10-minute bike ride to get to. It is a scenic drive with an off-road section climbing in to the mountain entering the village. Salvacion is a gentle right hander good for intermediates when small to medium sized swell. When its big it’s a very heavy wave, fast and has multiple sections. Best surfed low to medium tide.<br><br>

                <strong>PACIFICO</strong><br>

                A long barreling left wave that breaks over a rocky reef. Surfed all tides. Low tide can be quite shallow and you have to jump out the last final section because breaking over dry reef. On big swell it is very heavy. 1h motorbike drive from General Luna.<br><br>

                <strong>TUASON LEFT</strong><br>

                Harana’s home break. This break is found right in front of the resort. There is a channel in which you may enter the shape reef shelf on the left hand side of Harana’s beach front. Tuason break is a very powerful, technical A frame wave. Tuason Left has a longer left side but it’s right can be just as good. When the conditions are good, the wave is a world class barreling wave and can reward you with some awesome rides. Best in peak high tide as the reef is shallow and has lots of huge holes you can get stuck into if you wipe out weird. Will work from medium to high tide. Experts only on the wave unless its flat season (May – July). Even in flat season, it’s a very fast wave that sometimes closes out.<br><br>

                <strong>TUASON RIGHT</strong><br>

                Harana’s home break. This break is found right in front of the resort. There is a channel in which you may enter the shape reef shelf on the left hand side of Harana’s beach front. Breaking in between Cloud 9 and Tuason Left Tuason Right is a very powerful, technical A frame wave. Tuason Right has a longer left side but it’s right can be just as good. When the conditions are good, the wave is a world class barreling wave and can reward you with some awesome rides. Best in peak high tide as the reef is shallow and has lots of huge holes you can get stuck into if you wipe out weird. Will work from medium to high tide. Experts only on the wave unless its flat season (May – July). Even in flat season, it’s a very fast wave that sometimes closes out.<br><br>

                <strong>STIMPIES</strong><br>

                Stimpies a 10-minute boat ride away from Brgy. Catangnan jump off point. Its a first class left handed point break. When it’s big, it has strong left handed barrels. Has 2 sections and is a quick take off. Stimpies back drop is. A jagged edged mountain that is very scenic. Most of the time the water splashes against the jagged island making a very dramatic show. Best during low to medium tide but can work during high tide. This wave is intermediate when small but expert only when it is big. It along with rock island can have the heaviest hold downs of all waves in Siargao.<br><br>

                <strong>ROCK ISLAND</strong><br>

                Rock Island is a 10-minute boat ride away from Brgy. Catangnan jump off point. It’s a very long right handed point break. Its take of is quite gentle and can connect 3 sections of the wave when conditions are good. Best during low to medium tide but can work during high tide. This wave is intermediate when small but expert only when its is big. Rock Island and Stimpies can have the heaviest hold downs of all waves in Siargao.<br><br>

                <strong>OTHER WAVES</strong><br>

                There are many other breaks around the island. Some are further out and uncrowded due to distance. There are also some guarded secret spots that can be found if you’re lucky enough to find them or be brought there.<br><br><strong>Written by: Harana Surf Resort</strong>


              </p>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

  </div>


<script>
  var slideIndex = [1];
  var slideId = ["surf-spots-etiquette"]
  showSlides(1, 0);
  showSlides(1, 1);

  function plusSlides(n, no) {
    showSlides(slideIndex[no] += n, no);
  }

  function showSlides(n, no) {
    var i;
    var x = document.getElementsByClassName(slideId[no]);
    if (n > x.length) {slideIndex[no] = 1}    
      if (n < 1) {slideIndex[no] = x.length}
        for (i = 0; i < x.length; i++) {
         x[i].style.display = "none";  
       }
       x[slideIndex[no]-1].style.display = "block";  
     }
   </script>

   <script>
    function myMap() {
      var mapProp= {
        center:new google.maps.LatLng(51.508742,-0.120850),
        zoom:5,
      };
      var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
    }
  </script>

  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY&callback=myMap"></script>


    <!-- Footer -->
    <?php include("reg-footer.php"); ?>
  </main>
</div>
</body>
</html>
