<?php
//---------------------GET MYSQL QUERY-------------------------------//
//-------------------------YEAR 2021-----------------------------------//
// $sql for year 2021
$sql_21_jan = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'January' ORDER BY ev_year ASC LIMIT 1");
$sql_21_feb = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'February' ORDER BY ev_year ASC LIMIT 1");
$sql_21_mar = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'March' ORDER BY ev_year DESC LIMIT 1");
$sql_21_apr = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'April' ORDER BY ev_year ASC LIMIT 1");
$sql_21_may = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'May' ORDER BY ev_year DESC LIMIT 1");
$sql_21_jun = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'June' ORDER BY ev_year ASC LIMIT 1");
$sql_21_jul = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'July' ORDER BY ev_year ASC LIMIT 1");
$sql_21_aug = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'August' ORDER BY ev_year ASC LIMIT 1");
$sql_21_sep = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'September' ORDER BY ev_year ASC LIMIT 1");
$sql_21_oct = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'October' ORDER BY ev_year ASC LIMIT 1");
$sql_21_nov = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'November' ORDER BY ev_year ASC LIMIT 1");
$sql_21_dec = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'December' ORDER BY ev_year ASC LIMIT 1");
//-----------------------Months----------------------------//
// $sql2 for month January
$sql_jan2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'January' ORDER BY ev_day ASC $limit");
// $sql for month February
$sql_feb2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'February' ORDER BY ev_day ASC $limit");
// $sql for month March
$sql_mar2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'March' ORDER BY ev_day ASC $limit");
// $sql for month April
$sql_apr2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'April' ORDER BY ev_day ASC $limit");
// $sql for month May
$sql_may2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'May' ORDER BY ev_day ASC $limit");
// $sql for month June
$sql_jun2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'June' ORDER BY ev_day ASC $limit");
// $sql for month July
$sql_jul2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'July' ORDER BY ev_day ASC $limit");
// $sql for month August
$sql_aug2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'August' ORDER BY ev_day ASC $limit");
// $sql for month September
$sql_sep2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'September' ORDER BY ev_day ASC $limit");
// $sql for month October
$sql_oct2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'October' ORDER BY ev_day ASC $limit");
// $sql for month November
$sql_nov2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'November' ORDER BY ev_day ASC $limit");
// $sql for month December
$sql_dec2 = mysqli_query($conn,"SELECT * FROM sisa_events WHERE ev_year = '2021' and ev_month = 'December' ORDER BY ev_day ASC $limit");
 ?>