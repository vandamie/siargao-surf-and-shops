<?php
//----------------------YEARS LOOP-------------------------//
$sql_2021_jan = '';
while($row = mysqli_fetch_array($sql_21_jan)){

    $sql_2021_jan .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_feb = '';
while($row = mysqli_fetch_array($sql_21_feb)){

    $sql_2021_feb .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_mar = '';
while($row = mysqli_fetch_array($sql_21_mar)){

    $sql_2021_mar .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_apr = '';
while($row = mysqli_fetch_array($sql_21_apr)){

    $sql_2021_apr .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_may = '';
while($row = mysqli_fetch_array($sql_21_may)){

    $sql_2021_may .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_jun = '';
while($row = mysqli_fetch_array($sql_21_jun)){

    $sql_2021_jun .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_jul = '';
while($row = mysqli_fetch_array($sql_21_jul)){

    $sql_2021_jul .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_aug = '';
while($row = mysqli_fetch_array($sql_21_aug)){

    $sql_2021_aug .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_sep = '';
while($row = mysqli_fetch_array($sql_21_sep)){

    $sql_2021_sep .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_oct = '';
while($row = mysqli_fetch_array($sql_21_oct)){

    $sql_2021_oct .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_nov = '';
while($row = mysqli_fetch_array($sql_21_nov)){

    $sql_2021_nov .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop
$sql_2021_dec = '';
while($row = mysqli_fetch_array($sql_21_dec)){

    $sql_2021_dec .= '
    <thead>
    <tr>
    <th colspan="3">'.$row["ev_month"].'&nbsp;&nbsp;'.$row["ev_year"].'</th>
    </tr>
    </thead>
    ';

} // close while loop

//----------------------Months LOOP--------------------------------//
$sql_j2 = '';//for Jan LOOP
while($row = mysqli_fetch_array($sql_jan2)){

    $sql_j2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a class="ev-link" href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_f2 = '';//for Feb LOOP
while($row = mysqli_fetch_array($sql_feb2)){

    $sql_f2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_m2 = '';//for Mar LOOP
while($row = mysqli_fetch_array($sql_mar2)){

    $sql_m2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_a2 = '';
while($row = mysqli_fetch_array($sql_apr2)){

    $sql_a2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_ma2 = '';
while($row = mysqli_fetch_array($sql_may2)){

    $sql_ma2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_ju2 = '';
while($row = mysqli_fetch_array($sql_jun2)){

    $sql_ju2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_jl2 = '';
while($row = mysqli_fetch_array($sql_jul2)){

    $sql_jl2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a  href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_au2 = '';
while($row = mysqli_fetch_array($sql_aug2)){

    $sql_au2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_sp2 = '';
while($row = mysqli_fetch_array($sql_sep2)){

    $sql_sp2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_oc2 = '';
while($row = mysqli_fetch_array($sql_oct2)){

    $sql_oc2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_no2 = '';
while($row = mysqli_fetch_array($sql_nov2)){

    $sql_no2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
$sql_de2 = '';
while($row = mysqli_fetch_array($sql_dec2)){

    $sql_de2 .= '
    <tbody>
    <tr>
    <td>'.$row["ev_month"].'&nbsp;'.$row["ev_day"].'</td>
    <td><a href="">'.$row["ev_name"].'</a><br>'.$row["ev_address"].'</td>
    <td>'.$row["ev_class"].'</td>
    <td>'.$row["ev_status"].'</td>
    </tr>
    </tbody>
    ';

} // close while loop
 ?>