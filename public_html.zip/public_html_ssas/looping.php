


<!DOCTYPE html>
<html>
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<!-- SSAS TAB ICON -->
	<link rel="icon" type="image" style="border-radius:50%;" href="./sisaph-users/sisa-images/ssas-logo.png">
	<title>Testing</title>
	<style type="text/css">
		.judge-table{
			border-collapse: separate; 
			border-spacing: 5px;
			text-align:center; 
			font-size:12px;
		}
		.btn{
			font-size:12px;
			background-color:grey;
			color: white;
		}

		#ath-red{
			color:red; 
			width:25px; 
			border-radius:5px;
			padding: 2px;
		}
		#ath-blue{
			color:blue; 
			width:25px; 
			border-radius:5px;
			padding: 2px;
		}
		#ath-yellow{
			color:yellow; 
			width:25px; 
			border-radius:5px;
			padding: 2px;
		}
		#ath-green{
			color:green; 
			width:25px; 
			border-radius:5px;
			padding: 2px;
		}
		.res-table{
			border-collapse: separate; 
			border-spacing: 7px;
			text-align:left; 
			font-size:12px;
		}
		.logo-s{
			width:35px;
			height:35px;
			border-radius:5px;
			border-radius:50%;
		}
		.in-one{
			border:1px <?php printf($bor_col_a); ?> solid;
			width: 120px;
		}
		.in-one:hover{
			border:1px red solid;
		}
		.in-two{
			border:1px <?php printf($bor_col_b); ?> solid;
			width: 120px;
		}
		.in-two:hover{
			border:1px blue solid;
		}
		.in-three{
			border:1px <?php printf($bor_col_c); ?> solid;
			width: 120px;
		}
		.in-three:hover{
			border:1px yellow solid;
		}
		.in-four{
			border:1px <?php printf($bor_col_d); ?> solid;
			width: 120px;
		}
		.in-four:hover{
			border:1px green solid;
		}
	</style>
</head>
<body>
<br><br><br><br><br>

	<center>
		<form style="width:auto;">
			<table class="res-table">
				<thead>

<?php
    $val_ned_fir = "0.00";
	$val_ned_sec = "0.00"; 
	$val_ned_thi = "0.00";
	$val_ned_fou = "0.00";

	$fir ="0.00";
    $sec ="0.00";
    $thi ="1.00";
    $fou ="9.00"; 

// global code that can calculate deduction from the leading participants 
if(
	$fir > $sec && $fir > $thi  && $fir > $fou 
	&&
	$sec > $thi  && $sec> $fou
	&& 
	$thi > $fou
){ 
	$a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $thi + 1;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>'.
	'<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

	}elseif($fir < $sec && $fir > $thi && $fir > $fou && $thi == 0.00 && $fou == 0.00){
    $a = $sec - $fir + 1;
	$b = $fir - $thi + 1;
	$c = $fir - $fou + 1;

	$val_ned_sec = number_format($a,2); //===================1st edit done=====================================//
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';


	}elseif($fir < $thi && $fir > $sec && $fir > $fou && $sec == 0.00 && $fou == 0.00){
    $a = $thi - $fir + 1;
	$b = $fir - $sec + 1;
	$c = $fir - $fou + 1;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2); //=================== 2nd edit done=====================================//

	 echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

	}elseif($fir < $fou && $fir > $sec && $fir > $thi && $sec == 0.00 && $thi == 0.00){ 

	$a = $fou - $fir + 1;
	$b = $fir - $sec + 1;
	$c = $fir - $thi + 1;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 3rd edit done=====================================//
	$val_ned_fou = number_format($c,2);

	 echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

	}elseif( $sec > $fir && $sec > $thi && $sec > $fou && $fir == 0.00 && $thi == 0.00 && $fou == 0.00){ 

	$a = $sec - $fir + 1;
	$b = $sec - $thi + 1;
	$c = $sec - $fou + 1;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 4th edit not done=====================================//
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

		}elseif( $sec > $fir && $sec > $fou && $thi > $fir && $thi > $fou
			 && 
			$sec == $thi  
			&& 
			$fir == 0.00 && $fou == 0.00
		){ 

	$a = $sec - $thi + 1;
	$b = $sec - $fir + 1;
	$c = $sec - $fou + 1;
   
	$val_ned_fir = number_format($a,2); 
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 5th edit done=====================================//
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_fir.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

	}elseif( $sec > $fir && $thi > $fir && $fou > $fir 
	&& 
	$sec == $thi &&  $sec == $fou
	&& 
	$fir == 0.00 
){ 

	$a = $sec - $thi + 1;
	$b = $sec - $fou + 1;
	$c = $sec - $fir + 1;
    
    $val_ned_fir = number_format($a,2);
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 6th edit done=====================================//
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_fir.' '.'nd</td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';


	}elseif( $fou > $thi && $fou > $sec && $fou > $fir 
	&& 
	$thi !== $sec
	&& 
	$thi > $fir && $sec > $fir
	&& 
	$fir == 0.00 
){ 

	$a = $thi - $sec + 1;
	$b = $fou - $thi + 1;
	$c = $fou - $fir;
    
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 7th edit done=====================================//
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

		}elseif( $fou > $thi && $fou > $sec && $fou > $fir 
	&& 
	$thi == $sec
	&& 
	$thi > $fir && $sec > $fir
	&& 
	$fir == 0.00 
){ 

	$a = $sec - $fir + 1;
	$b = $sec - $fir + 1;
	$c = $fou - $sec + 1;
    
    $val_ned_fir = number_format($a,2);
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);//=================== 8th edit done=====================================//
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fir.' '.'nd</td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';        
      

}elseif(
	$sec > $fir && $sec > $thi  && $sec > $fou 
	&&
	$fir > $thi  && $fir > $fou
	&& 
	$thi > $fou 
){

	$a = $sec - $fir + 1;
	$b = $fir - $thi + 1;
	$c = $sec - $fou;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

 }elseif(
	$thi > $fir && $thi > $sec  && $thi > $fou 
	&&
	$sec > $fir  && $sec > $fou
	&& 
	$fir > $fou
){

	$a = $thi- $sec + 1;
	$b = $sec - $fir + 1;
	$c = $thi - $fou;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	 echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

  }elseif(
	$fou > $fir && $fou > $sec  && $fou > $thi 
	&&
	$thi > $sec  && $thi > $fir
	&& 
	$sec > $fir
){

	$a = $fou - $thi + 1;
	$b = $thi - $sec + 1;
	$c = $fou - $fir;

	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	 echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

 }elseif(
	$fir == $sec && $fir !== $thi  && $fir !== $fou 
	&&
	$sec !== $thi  && $sec !== $fou
	&& 
	$thi !== $fou
){
    $a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $fou;
	//$d = $thi - $fou + 1;
    
    //$val_ned_fir = number_format($a,2);
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

     echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

}elseif(
	$fir == $sec && $fir == $thi  && $fir !== $fou 
	&& 
	$fou !== $sec && $fou !== $thi
){
    $a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $fou + 1;
	//$d = $thi - $fou + 1;
    
    //$val_ned_fir = number_format($a,2);
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	  echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

}elseif($fir == $sec && $fir == $thi  && $fir == $fou){
    $a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $fou + 1;
   
    $val_ned_fir = number_format($a,2);
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	  echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fir.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

	}elseif($fir !== 0.00 && $sec == 0.00  && $thi == 0.00 && $fou == 0.00){
    $a = $fir - $sec + 1;
	$b = $sec - $thi;
	$c = $fir - $fou;
	//$d = $thi - $fou + 1;
    
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	  echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

}elseif($fir !== 0.00 && $sec !== 0.00  && $thi == 0.00 && $fou == 0.00
         or
         $fir !== 0.00 && $sec !== 0.00  && $thi == 0.00 && $fou == 0.00
){
    $a = $fir - $sec + 1;
	$b = $sec - $thi;
	$c = $fir - $fou;
	//$d = $thi - $fou + 1;
    
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	  echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	}elseif($fir !== 0.00 && $sec !== 0.00  && $thi !== 0.00 && $fou == 0.00){
    $a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $fou + 1;
	//$d = $thi - $fou + 1;
    
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	  echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td></td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';
  

}else{

	$a = $fir - $sec + 1;
	$b = $sec - $thi + 1;
	$c = $fir - $fou + 1;
    
    $val_ned_fir = number_format($a,2); 
	$val_ned_sec = number_format($a,2); 
	$val_ned_thi = number_format($b,2);
	$val_ned_fou = number_format($c,2);

	 echo '<tr>
	<td><i id="ath-red" class="fas fa-tshirt"></i></td>
	<td>Philmar Alipayo</td>
	<td>'.$fir.'</td>
	<td>'.$val_ned_fir.' '.'nd</td>
	</tr>';

	echo '<tr>
	<td><i id="ath-blue" class="fas fa-tshirt"></i></td>
	<td>PJ Alipayo</td>
	<td>'.$sec.'</td>
	<td>'.$val_ned_sec.' '.'nd </td>
	</tr>';

	echo '<tr>'.
	'<td><i id="ath-yellow" class="fas fa-tshirt"></i></td>
	<td>Edito Alcala Jr.</td>
	<td>'.$thi.'</td>
	<td>'.$val_ned_thi.' '.'nd </td>
	</tr>';

	echo '<tr>
	<td><i id="ath-green" class="fas fa-tshirt"></i></td>
	<td>Aroyo Espejon</td>
	<td>'.$fou.'</td>
	<td>'.$val_ned_fou.' '.'nd </td>
	</tr>';

}

 ?>

</tbody>
</table>
</form>
<!--------- Script Codes --------->
	<script src='https://kit.fontawesome.com/a076d05399.js'></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>


