<?php
//error_reporting(0);
error_reporting(E_ALL);
session_start();
//-------------------------------Log in------------------------------//
require_once ("sisaph-users/include/class.user.php");//connection to database and public functions
require_once("sisaph-users/include/db-con.php");  // PHP functions file
require_once ("sisaph-users/include/functions.php"); // class of functions of User.
$user = new User();//connection to public User function
require_once ("admin-sisaph-cms/classes/db-con.php"); // class of functions of User.

date_default_timezone_set('Asia/Manila');
$page_id = 1;
$month= date("M");
$day= date("D");
$year= date("Y");
$time= date("h:i:s a");
    $visitor_ip = $_SERVER['REMOTE_ADDR']; // stores IP address of visitor in variable
    add_view($conn, $visitor_ip, $page_id,$month, $day, $year, $time);
  //$total_page_views = total_views($con, $page_id); // Returns total views of this page


    $error1='';
if (isset($_REQUEST['submit-log'])) {  // posting data after submit button.
  extract($_REQUEST); //extracting all data  from database.   
  $login = $user->check_login($cname, $cpassword); // calling function verification process.
  $error1='';
  if ($login) {
          // Login Success
   ?>
   <!doctype html>
   <html lang="en">
   <head>
    <!-- Sweet Alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title></title>
  </head>
  <body> 
    <script>
      swal({
        title: "You have been signed in successfully.",
        icon: "success",
        button: "Proceed",
      }).then(function(isConfirm) {
        if (isConfirm) {
          window.location='sisaph-users/index.php'
        } else {
    //if no clicked => do something else
  }
});
</script>
</body>
</html>
<?php
} else {
          // Login Failed
 $error1 = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Wrong <strong>user name or password</strong> or your <strong>account</strong> is need for the <strong>admin approval.</strong>
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}
//-------------------------------Register------------------------------//
$error2= '';
if (isset($_REQUEST['submit-reg'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$register = $user->reg_user($cus_name, $cus_password, $cus_email);
$error2= '';
if ($register) {
            // sending Success
 $error2= '<div class="alert alert-success alert-dismissible fade show" role="alert">
 Registration successfully. <a href="" data-toggle="modal" data-target="#login">Click here</a> to login
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
} else {
            // sending Failed
 $error2= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Registration failed. <strong>Email or Username</strong> already exist please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}



//-------------------------------Send Email------------------------------//
$error3= '';
if (isset($_REQUEST['submit-con'])){  // $_POST['submit'] getting all inputted data on the page and save to database after click submit button.
extract($_REQUEST);
$send = $user->send_email($c_name, $c_email, $c_subject, $c_message);
$error3= '';
if ($send) {
            // Registration Success
  $error3= '<div class="alert alert-success alert-dismissible fade show" role="alert">
  Email delivery was succeed, thank you for contacting us.
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
  <span aria-hidden="true">&times;</span>
  </button>
  </div>';

  $to       = 'siargao.web.protocol@gmail.com';
  $name  = $_REQUEST['c_name'];
  $subject  = $_REQUEST['c_subject'];

  $message = "His/Her&nbsp;name:&nbsp;".$name."<br>"."Message:<br>".$_REQUEST['c_message'];
  $message = wordwrap($message, 70);

// Always set content-type when sending HTML email
  $headers = "MIME-Version: 1.0" . "\r\n";
  $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
  $headers  = 'From:'. $_REQUEST['c_email'] . "\r\n" .
  'MIME-Version: 1.0' . "\r\n" .
  'Content-type: text/html; charset=utf-8';
  $headers .= 'Cc: '. $_REQUEST['c_email'] . "\r\n";

  mail($to, $subject, $message, $headers);

} else {
            // Registration Failed
 $error3= '<div class="alert alert-warning alert-dismissible fade show" role="alert">
 Email delivery failed, please try again.
 <button type="button" class="close" data-dismiss="alert" aria-label="Close">
 <span aria-hidden="true">&times;</span>
 </button>
 </div>';
}
}

$query = "SELECT * FROM news_article";
$result2 =mysqli_query($conn,$query);
$nr = mysqli_num_rows($result2); // Get total of Num rows from the database query
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="description" content="Siargao Surf and Shops, Official Website, Home">
  <meta name="viewport" content="width=device-width, initial-scale=0.86, maximum-scale=5.0, minimum-scale=0.86">
  <!-- SSAS TAB ICON -->
  <link rel="icon" type="image" href="./sisaph-users/sisa-images/ssas-logo.png">
  <!-- font-awesome icons link source -->
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <!-- font-awesome social media icons link source -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="./sisaph-users/sisa-css/style.css" rel="stylesheet">
  <title>SSAS Home</title>
  <!-- css for the page and dark mode -->
  <style>
    /* Table CSS */
    table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      /*border: 1px solid #ddd;*/
      height: 435px;
      -ms-overflow-style: none;  /* Internet Explorer 10+ */
      scrollbar-width: none;  /* Firefox */
    }
    
    table::-webkit-scrollbar { 
      display: none;  /* Safari and Chrome */
    }

    th, td {
      text-align: left;
      padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}

    .a-link{
      color: white;
    }
    /* mouse over link */
    .a-link:hover {
      color: #1E90FF;
    }
  </style>
</head>
<body>
  <br><br><br><br><br>
  <header>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top" style="background-color:#4267B2;">
      <ul class="navbar-nav mr-auto">
       <a class="nav-link" id="brand"><img style="border-radius: 7px;" src="./sisaph-users/sisa-images/ssas-logo.png" alt="logo" width="35" height="35"> Siargao Surf and Shops</a></ul>
       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-link">
            <a href="index.php" class="a-link"><i class="fas fa-home"></i> Home</a>
          </li>
          <li class="nav-link">
            <a href="./sisaph-users/sisa-p-merchants.php" class="a-link"><i class="fas fa-store"></i> Partner Merchants</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#register"><i class="fas fa-user"></i> Register</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#signin"><i class="fas fa-key"></i> Sign In</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" data-toggle="modal" data-target="#info"><i class="fas fa-info"></i> Help</a>
          </li>
          <li class="nav-link">
            <a href="?" class="a-link" class="nav-link" data-toggle="tooltip" data-html="true" data-placement="bottom" title="You have to register first, thank you."><i class="fas fa-shopping-cart"></i></a>
          </li>
        </ul>
        <form method="GET" class="form-inline mt-2 mt-md-0">
          <input type="text" id="search_box" name="search_data" placeholder="Search" aria-label="Search">
          <button type="submit" id="search_icon" name="search_btn" class="btn btn-primary my-2 my-sm-0"><i class="fas fa-search"></i></button>
        </form>
      </div>
    </nav>
  </header><br>

  <div class="container">
    <main role="main">

      <!-- Youtube Videos -->
      <iframe src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2FSIARGAOISA%2Fvideos%2F259024914963682%2F&show_text=true&width=1020" width="560" height="429" style="border:none;overflow:hidden;width:100%;" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen="true"></iframe>


      <!-- The events by division -->
      <hr class="featurette-divider">
      <div class="container marketing">
        <div class="row">
          <div class="col-lg-4">
            <img id="events-img" src="./sisaph-users/sisa-images/sisa-event-7.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
            <center><h3>Grommet Division</h3></center>
            <p>With Toby Espejon, Mark Kent Hucay, Jayward Alciso at Kai Alcala.</p>
            <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img id="events-img" src="./sisaph-users/sisa-images/sisa-event-4.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
            <center><h3>Women's Open Division</h3></center>
            <p>With Nildie Espejon Blancada, Ana Mae Alipayo, Shelamae Arjona at Manette Alcala.</p>
            <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img id="events-img" src="./sisaph-users/sisa-images/sisa-event-5.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
            <center><h3>Men's Open Division</h3></center>
            <p>With Marvin Delamide, Philmar Alipayo, Gabriel Lerog at Eduardo Dizon Alciso.</p>
            <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img id="events-img" src="./sisaph-users/sisa-images/sisa-event-3.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
            <center><h3>Master's Division</h3></center>
            <p>With Aye Catulay, Eloy Nogalo, Glenn Turner at Edito Jr Alcala.</p>
            <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
          </div><!-- /.col-lg-4 -->
          <div class="col-lg-4">
            <img id="events-img" src="./sisaph-users/sisa-images/sisa-event-6.jpg" alt="Lights" style="width:100%; max-width:100%; border-radius: 5%;">
            <center><h3>AirBorne Division</h3></center>
            <p>With Edito Jr Alcala, PJ Alipayo, Philmar Alipayo, Jefferson Espejon at Loloy Espejon.</p>
            <center><p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p></center>
          </div><!-- /.col-lg-4 -->

        </div><!-- /.row -->

        <!-- All surfing events -->
        <br><br>
        <hr class="featurette-divider">
        <?php 
        if($nr !== 0){
                    // fetch records
          $article = "SELECT * FROM news_article ORDER BY newsart_title ASC";
          $data = mysqli_query($conn,$article);
          while($res = mysqli_fetch_array($data)){ 
            ?>
            <div class="row featurette" style="overflow-y:auto;">
              <div class="col-md-12 order-md-15">

                <table class="table-responsive">
                 <thead>
                  <tr>
                    <th colspan="2">
                      <center><h5><?php echo html_entity_decode($res['newsart_title']); ?></h5></center>
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>
                      <p><?php echo html_entity_decode($res['newsart_details']); ?></p>
                    </td>
                    <td style="vertical-align: text-top;">
                      <img id="events-img" src="./admin-sisaph-cms/images/<?php echo $res['newsart_image']; ?>" alt="Cloud 9 Master 2019" style="width:100%; max-width:100%; border-radius: 5%;">
                    </td>
                  </tr>
                </tbody>
              </table>

            </div>
          </div>
          <br>
          <?php
        } 
      }else{
        ?>
        <div class="row featurette">
          <div class="col-md-12 order-md-15" style="overflow-x:auto;">

            <table class="table-responsive">
             <thead>
              <tr>
                <th>
                  <center><h5>Updating...</h5></center>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <p>Updating...</p>
                </td>
              </tr>
            </tbody>
          </table>

        </div>
      </div>
      <br>
      <?php
    }
    ?>



    <!-- Modal Info-->
    <div class="modal fade" id="info" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"></h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body" id="color">
           <center><img class="mb-4" style="border-radius: 7px;" src="./sisaph-users/sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>      
           <center><h5 class="modal-title" style="text-align:center;">How can we help you?</h5></center>
           <ul id="inf">
            <li><a href="" id="inf">How to change my password?</a></li>
            <li><a href="" id="inf">How to link my bank card?</a></li>
            <li><a href="" id="inf">How to chat with my instructor?</a></li>
            <li><a href="" id="inf">Can I pay them cash on hand?</a></li>
          </ul>
          <dl>
            <dt>Email Us:</dt>
            <dd>siargao.web.protocol@gmail.com</dd>
          </dl>
          <center><h5>Contact Us:</h5></center>
          <form class="form-login" method="POST" name="">
            <center><h6><?php echo $error3; ?></h6></center>
            <label for="inputEmail" class="sr-only">Complete Name</label>
            <center><i class="fas fa-user"></i></center>
            <input type="text" name="c_name" class="form-control" placeholder="Complete Name" required autofocus>
            <label for="inputEmail" class="sr-only">Email Address</label>
            <center><i class="fas fa-envelope"></i></center>
            <input type="email" name="c_email" class="form-control" placeholder="Email Address" required autofocus>
            <label for="inputEmail" class="sr-only">Subject</label>
            <center><i class="fas fa-book-open"></i></center>
            <input type="text" name="c_subject" class="form-control" placeholder="Write Subject" required autofocus>
            <label for="message" class="sr-only">Message</label>
            <center><i class="fas fa-edit"></i></center>
            <textarea type="message" name="c_message" class="form-control" placeholder="Write Message" required autofocus></textarea>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <input type="submit" class="btn btn-primary" name="submit-con" value="Submit">
          </div>
        </form>
      </div>
    </div>
  </div>


  <!-- Modal Register-->
  <div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="register" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel"></h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" id="color">
         <form class="form-login" method="post" name="reg">
          <center><img class="mb-4" style="border-radius: 7px;" src="./sisaph-users/sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>
          <center><h5 class="modal-title" style="text-align:center;">Register</h5></center>
          <center><span><?php echo $error2; ?></span>
            <span style="text-align: center; color: orange;" id="error_msg"></span>
          </center>
          <center><i class="fas fa-user"></i></center>
          <label for="inputUser" class="sr-only">User Name</label>
          <input type="text" type="text" name="cus_name" id="textbox" class="form-control" placeholder="User Name" required autofocus>
          <center><i class="fas fa-envelope"></i></center>
          <center><label for="inputEmail" class="sr-only">Email Address</label>
            <input type="email" name="cus_email" class="form-control" placeholder="Email Address" required autofocus>
            <i class="fas fa-key"></i></center>
            <center><label for="inputPassword" class="sr-only">Password</label>
             <input type="password" name="cus_password"  class="form-control" placeholder="Password" required autofocus>
             <br>
             <div class="checkbox mb-3">
               <center><label>
                <input type="checkbox" id="check_agree" value="remember-me"> I agree to Siargao Surf and Shops&nbsp;<a id="inf" href="#" data-toggle="modal" data-target="#pri-pol">Privacy Policy</a>&nbsp;and&nbsp;<a id="inf" href="#" data-toggle="modal" data-target="#con">Terms and Conditions</a>
              </label></center>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <input type="submit" class="btn btn-primary" name="submit-reg" value="Submit">
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- The Modal of Privacy Policy -->
  <div class="modal fade bd-example-modal-lg" id="pri-pol" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Siargao Surf and Shops Privacy Policy</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <center><p>Ongoing Development</p></center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- The Modal of Conditions -->
<div class="modal fade bd-example-modal-lg" id="con" tabindex="-1" role="dialog" aria-labelledby="info" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Siargao Surf and Shops Conditions</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <center><p>Ongoing Development</p></center>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </form>
  </div>
</div>
</div>


<!-- Modal Sign in-->
<div class="modal fade" id="signin" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
       <form class="form-login" method="post" name="login">
        <center><img class="mb-4" style="border-radius: 7px;" src="./sisaph-users/sisa-images/ssas-logo.png" alt="" width="50" height="50"></center>
        <center><?php echo "$error1"; ?>
        <span style="text-align: center; color: orange;" id="error_msg"></span>
      </center>
      <label for="inputEmail" class="sr-only">User Name</label>
      <center><i class="fas fa-user"></i></center>
      <input type="text" id="cname" name="cname" id="textbox" class="form-control" placeholder="User Name" required>
      <label for="inputPassword" class="sr-only">Password</label>
      <center><i class="fas fa-key"></i></center>
      <input type="password" name="cpassword"  class="form-control" placeholder="Password" required>
      <div class="checkbox mb-3">
        <br>        
        <center><label><input type="checkbox" id="check_login" name="remember-me"> Remember me</label></center>
        <center><p>You can't login? <a id="inf" href="#" data-toggle="modal" data-target="#sec">forgot password.</a></p></center>
      </div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <input type="submit" class="btn btn-primary" name="submit-log" value="Sign In">
    </form>
  </div>
</div>
</div>
</div>


<!-- Modal Security-->
<div class="modal fade" id="sec" tabindex="-1" role="dialog" aria-labelledby="login" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel"></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="color">
        <form class="form-login">
          <center><img class="mb-2" style="border-radius: 7px;" src="./sisaph-users/sisa-images/ssas-logo.png" alt="logo" width="50" height="50"></center>
          <h3 class="modal-title" style="text-align:center;">Siargao Surf and Shops</h3>

          <center><i class="fa fa-envelope"></i></i>&nbsp;why&nbsp;<i class="fa fa-question-circle" data-toggle="tooltip" data-placement="bottom" title="We need your valid email address to verify your account and to send the recovery link for your account."></i></center>
          <input type="email" id="inputEmail" class="form-control" placeholder="Enter your email" required autofocus>
          <br>
          <button class="btn btn-lg btn-primary btn-block" id="login" type="submit">Submit</button>

          <center><p class="mt-5 mb-3 ">&copy; 2020-2021</p></center>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="submit-log" value="Submit">
      </form>
    </div>
  </div>
</div>
</div>


<div class="container">
  <main role="main">
    <!-- FOOTER -->
    <footer class="pt-4 my-md-5 pt-md-5 border-top" id="footer">
      <div class="row">
        <div class="col-12 col-md">
          <img class="mb-2" src="./sisaph-users/sisa-images/ssas-logo.png" alt="" width="25" height="25">
          <small class="d-block mb-3 text-muted">&copy; 2020-2021</small>
          <small class="d-block mb-3">Social Media Links</small>
          <ul class="list-unstyled text-small">
            <a href="https://web.facebook.com/SIARGAOISA"><i id="fb" class="fa fa-facebook"></i></a>
            <a href="https://youtu.be/IVlVlFC79cI"><i id="yt" class="fa fa-youtube"></i></a>
            <a href="https://www.instagram.com/sisa.siargao/"><i id="ig" class="fa fa-instagram"></i></a>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Features</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="sisaph-users/sisaph_events_og.php">SISA Events</a></li>
            <li><a class="text-muted" href="sisaph-users/sisaph_rankings.php">SISA Rankings</a></li>
            <li><a class="text-muted" href="http://sisaph.000webhostapp.com/sisaph-judging/">SISA Live Score</a></li>
            <li><a class="text-muted" href="sisaph-users/iao-surf-schools.php">SI Accridited Surf Schools</a></li>
            <li><a class="text-muted" href="sisaph-users/iao-surf-spots.php">Surf Spots</a></li>
            <li><a class="text-muted" href="sisaph-users/sisa-p-merchants.php">Partner Merchants</a></li>
            <li><a class="text-muted" href="sisaph-users/ssas-community.php">SSAS Community</a></li>
            <li><a class="text-muted" href="#">Supported Foundation - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
            <li><a class="text-muted" href="#">Job Offers - <span style="font-size:10px; color:orange;">Coming Soon</span></a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Sponsor</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="http://siargao-web-protocol.000webhostapp.com/">Siargao Web Protocol</a></li>
          </ul>
        </div>
        <div class="col-6 col-md">
          <h5>Siargao Surf and Shops</h5>
          <ul class="list-unstyled text-small">
            <li><a class="text-muted" href="sisaph-users/sisaph-about.php">About</a></li>
            <li><a class="text-muted" href="sisaph-users/sisaph-history.php">History</a></li>
            <li><a class="text-muted" href="sisaph-users/sisaph-privacy-policy.php">Privacy Policy</a></li>
            <li><a class="text-muted" href="sisaph-users/sisaph-conditions.php">Terms and Conditions</a></li>
            <li><a class="text-muted" href="#">Terms of Service</a></li>
            <li><a class="text-muted" href="#">Return and Refund</a></li>
            <li><a class="text-muted" href="#">Cookies Policy</a></li>
            <li><a class="text-muted" href="#">Disclaimer</a></li>
          </ul>
        </div>
      </div>
    </footer>
  </main>
</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

<script>
  //showing data from  logo when focus
  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
  });

  //avoid accepting special characters in the input box
  $(document).ready(function(){
    $("#textbox").keypress(function (e) {
      var key = e.keyCode || e.which;       
      $("#error_msg").html("");
        //Regular Expression
        var reg_exp = /^[A-Za-z0-9 ]+$/;
        //Validate Text Field value against the Regex.
        var is_valid = reg_exp.test(String.fromCharCode(key));
        if (!is_valid) {
          $("#error_msg").html("No special characters Please!");
        }
        return is_valid;
      });
  });

    //Avoid resubmitting the form confirmation
    if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
    }
  </script> 
  
  <?php 
  //Set a cookies when checked the remember me checkbox
  if(isset($_COOKIE['cname'])){
    $cname = $_COOKIE['cname'];
    echo "
    <script>
    document.getElementById('cname').value = '$cname';
    </script>
    ";
  }

  mysqli_close($conn);
  ?>
</main>
</div>
</body>
</html>
